"""Live services of ALIEF FEA MODELER (Rhino 8):

* 3D View  - plate thickness and profile sections drawn by a display conduit from cached meshes.
             No objects are added to the model, so the file stays small and Rhino stays light;
             the display follows every change automatically (move, edit, assign, flip, delete, undo).
* Index    - floating property index (legend) at the top left of the viewport: colour, property /
             section, count, area / length and weight, active property, 3D / team status.
* Hooks    - document events (objects, layers, open / save) and the team-sync watcher.

All work is done on Rhino's Idle event (never inside a running command), and only the members
that changed are rebuilt.
"""
import time
import uuid

import System
import System.Drawing as SD
import Rhino
import Rhino.Geometry as rg
import scriptcontext as sc

from . import core as C
from . import rhinoio as io

STICKY = "ALIEF_FEA_LIVE"
_TAG = uuid.uuid4().hex          # new value each time the module is (re)loaded


def _doc():
    d = Rhino.RhinoDoc.ActiveDoc
    if d is not None and sc.doc is not d:
        sc.doc = d
    return d


def _in_command():
    try:
        return bool(Rhino.Commands.Command.InCommand())
    except Exception:
        return False


def _col(hexcol, alpha=255):
    r, g, b = C.hex2rgb(hexcol)
    return SD.Color.FromArgb(alpha, r, g, b)


def _darker(hexcol, f=0.55):
    r, g, b = C.hex2rgb(hexcol)
    return SD.Color.FromArgb(255, int(r * f), int(g * f), int(b * f))


def _meshing_parameters():
    try:
        mp = rg.MeshingParameters.FastRenderMesh
    except Exception:
        mp = rg.MeshingParameters()
    try:
        mp.SimplePlanes = True
    except Exception:
        pass
    return mp


def _to_mesh(V, F):
    m = rg.Mesh()
    for v in V:
        m.Vertices.Add(v[0], v[1], v[2])
    for f in F:
        if len(f) == 4:
            m.Faces.AddFace(int(f[0]), int(f[1]), int(f[2]), int(f[3]))
        else:
            m.Faces.AddFace(int(f[0]), int(f[1]), int(f[2]))
    m.Normals.ComputeNormals()
    return m


def _layer_visible(doc, idx):
    try:
        L = doc.Layers[idx]
        guard = 0
        while L is not None and guard < 32:
            if not L.IsVisible:
                return False
            pid = L.ParentLayerId
            if pid == System.Guid.Empty:
                return True
            L = doc.Layers.FindId(pid)
            guard += 1
    except Exception:
        return True
    return True


def _boxes_touch(a, b):
    return not (a.Max.X < b.Min.X or a.Min.X > b.Max.X or a.Max.Y < b.Min.Y or a.Min.Y > b.Max.Y
                or a.Max.Z < b.Min.Z or a.Min.Z > b.Max.Z)


class Member(object):
    def __init__(self, kind, name, qty, color, layer):
        self.kind, self.name, self.qty, self.color, self.layer = kind, name, qty, color, layer
        self.mesh, self.lines, self.bbox = None, [], None


class Live(object):
    def __init__(self):
        self.tag = _TAG
        self.alive = False
        self.doc_sn = None
        self.members = {}
        self.dirty = set()
        self.all_dirty = True
        self.rebatch = True
        self.hosts = None
        self.batches = []
        self.bbox = rg.BoundingBox.Empty
        self.settings = dict(C.DEFAULT_SETTINGS)
        self.lib = None
        self.legend = None
        self.legend_dirty = True
        self.last_change = 0.0
        self._last_idle = 0.0
        self._last_settings = 0.0
        self._last_sync = 0.0
        self._errors = set()
        self.conduit = None
        self._h = {}

    # ------------------------------------------------------------------ start / stop
    def start(self):
        self.alive = True
        try:
            self.conduit = _make_conduit(self)
            self.conduit.Enabled = True
        except Exception as ex:          # no 3D view / index, but sync and the commands keep working
            self.conduit = None
            self._err("conduit", ex)
        h = self._h
        h["add"] = self._on_add
        h["del"] = self._on_delete
        h["rep"] = self._on_replace
        h["und"] = self._on_add
        h["att"] = self._on_attr
        h["lay"] = self._on_layer
        h["open"] = self._on_open
        h["new"] = self._on_open
        h["save"] = self._on_saved
        h["sel"] = self._on_select
        h["idle"] = self._on_idle
        Rhino.RhinoDoc.AddRhinoObject += h["add"]
        Rhino.RhinoDoc.DeleteRhinoObject += h["del"]
        Rhino.RhinoDoc.ReplaceRhinoObject += h["rep"]
        Rhino.RhinoDoc.UndeleteRhinoObject += h["und"]
        Rhino.RhinoDoc.ModifyObjectAttributes += h["att"]
        Rhino.RhinoDoc.LayerTableEvent += h["lay"]
        Rhino.RhinoDoc.EndOpenDocument += h["open"]
        Rhino.RhinoDoc.NewDocument += h["new"]
        Rhino.RhinoDoc.EndSaveDocument += h["save"]
        for name in ("SelectObjects", "DeselectObjects", "DeselectAllObjects"):
            try:
                ev = getattr(Rhino.RhinoDoc, name)
                ev += h["sel"]
            except Exception:
                pass
        Rhino.RhinoApp.Idle += h["idle"]
        self.alive = True
        self._read_settings(force=True)

    def stop(self):
        self.alive = False
        try:
            if self.conduit is not None:
                self.conduit.Enabled = False
        except Exception:
            pass
        h = self._h
        pairs = [("AddRhinoObject", "add"), ("DeleteRhinoObject", "del"), ("ReplaceRhinoObject", "rep"),
                 ("UndeleteRhinoObject", "und"), ("ModifyObjectAttributes", "att"), ("LayerTableEvent", "lay"),
                 ("EndOpenDocument", "open"), ("NewDocument", "new"), ("EndSaveDocument", "save"),
                 ("SelectObjects", "sel"), ("DeselectObjects", "sel"), ("DeselectAllObjects", "sel")]
        failed = []
        for name, key in pairs:
            try:
                ev = getattr(Rhino.RhinoDoc, name)
                ev -= h[key]
            except Exception:
                failed.append(name)
        try:
            Rhino.RhinoApp.Idle -= h["idle"]
        except Exception:
            failed.append("Idle")
        if failed:   # the handlers check self.alive, so a left-over subscription does nothing
            try:
                Rhino.RhinoApp.WriteLine("ALIEF FEA live display: could not unsubscribe %s (inactive now)" % ", ".join(failed))
            except Exception:
                pass

    def _err(self, where, ex):
        key = "%s:%s" % (where, type(ex).__name__)
        if key not in self._errors:
            self._errors.add(key)
            try:
                Rhino.RhinoApp.WriteLine("ALIEF FEA live display (%s): %s" % (where, ex))
            except Exception:
                pass

    # ------------------------------------------------------------------ settings / state
    def _read_settings(self, force=False):
        now = time.time()
        if not force and now - self._last_settings < 1.0:
            return
        self._last_settings = now
        try:
            st = io.load_settings()
        except Exception:
            return
        old = self.settings
        self.settings = st
        if (old.get("color_by") != st.get("color_by") or old.get("show_3d") != st.get("show_3d")
                or old.get("view3d_alpha") != st.get("view3d_alpha")):
            self.all_dirty = True
        if (old.get("active_prop") != st.get("active_prop") or old.get("active_section") != st.get("active_section")
                or old.get("legend") != st.get("legend") or old.get("color_by") != st.get("color_by")):
            self.legend_dirty = True

    def invalidate_all(self):
        """Library / colour changes: rebuild everything on the next idle."""
        self.all_dirty = True
        self.hosts = None
        self.legend_dirty = True
        self._read_settings(force=True)
        self.last_change = 0.0

    def settings_changed(self):
        self._read_settings(force=True)
        self.legend_dirty = True
        self.rebatch = True
        d = _doc()
        if d is not None:
            d.Views.Redraw()

    def reset(self, doc):
        self.doc_sn = doc.RuntimeSerialNumber if doc is not None else None
        self.members = {}
        self.dirty = set()
        self.hosts = None
        self.all_dirty = True
        self.legend_dirty = True
        self.batches = []
        self.bbox = rg.BoundingBox.Empty
        self._read_settings(force=True)

    # ------------------------------------------------------------------ events
    @staticmethod
    def _is_member_attr(attr):
        try:
            return bool(attr.GetUserString(io.K_KIND)) and not attr.GetUserString(io.K_PREVIEW)
        except Exception:
            return False

    def _touch(self, oid):
        self.dirty.add(str(oid))
        self.last_change = time.time()

    def _on_select(self, sender, e):
        if self.alive:
            self.rebatch = True      # selected members are drawn by Rhino only, so the highlight stays visible

    def _on_add(self, sender, e):
        if not self.alive:
            return
        try:
            if self._is_member_attr(e.TheObject.Attributes):
                self._touch(e.ObjectId)
        except Exception as ex:
            self._err("add", ex)

    def _on_delete(self, sender, e):
        if not self.alive:
            return
        try:
            if str(e.ObjectId) in self.members:
                self._touch(e.ObjectId)
        except Exception as ex:
            self._err("delete", ex)

    def _on_replace(self, sender, e):
        if not self.alive:
            return
        try:
            if str(e.ObjectId) in self.members or self._is_member_attr(e.NewRhinoObject.Attributes):
                self._touch(e.ObjectId)
        except Exception as ex:
            self._err("replace", ex)

    def _on_attr(self, sender, e):
        if not self.alive:
            return
        try:
            if self._is_member_attr(e.NewAttributes) or self._is_member_attr(e.OldAttributes):
                self._touch(e.RhinoObject.Id)
        except Exception as ex:
            self._err("attributes", ex)

    def _on_layer(self, sender, e):
        if not self.alive:
            return
        self.rebatch = True
        if self.settings.get("color_by") == "Layer":
            self.all_dirty = True     # layer colours are the member colours
        self.last_change = time.time()

    def _on_open(self, sender, e):
        if not self.alive:
            return
        try:
            self.reset(e.Document)
        except Exception as ex:
            self._err("open", ex)

    def _on_saved(self, sender, e):
        if not self.alive:
            return
        try:
            from . import sync
            sync.on_saved(e)
        except Exception as ex:
            self._err("save", ex)

    def _on_idle(self, sender, e):
        if not self.alive:
            return
        try:
            doc = _doc()
            if doc is None:
                return
            if doc.RuntimeSerialNumber != self.doc_sn:
                self.reset(doc)
            if _in_command():
                return
            if self.dirty or self.all_dirty:
                self.update(doc)
                doc.Views.Redraw()
            elif self.rebatch:
                self._batch(doc)
                doc.Views.Redraw()
            now = time.time()
            if now - self._last_idle >= 0.5:
                self._last_idle = now
                self._read_settings()
                from . import sync
                sync.idle(now)
        except Exception as ex:
            self._err("idle", ex)

    # ------------------------------------------------------------------ cache
    def update(self, doc):
        lib = io.load_library()
        self.lib = lib
        st = self.settings
        s = io.scale()
        show3d = bool(st.get("show_3d", True))
        if self.all_dirty:
            objs = io.af_objects()
            self.members = {}
            self.hosts = None
            targets = [(str(o.Id), o) for o in objs]
        else:
            targets = []
            for g in list(self.dirty):
                o = None
                try:
                    o = doc.Objects.FindId(System.Guid(g))
                except Exception:
                    o = None
                if o is not None and (o.IsDeleted or not self._is_member_attr(o.Attributes)):
                    o = None
                targets.append((g, o))
            boxes = []
            for g, o in targets:
                old = self.members.get(g)
                if (o is not None and io.is_plate(o)) or (old is not None and old.kind == "plate"):
                    if old is not None and old.bbox is not None:
                        boxes.append(old.bbox)
                    if o is not None:
                        boxes.append(o.Geometry.GetBoundingBox(True))
            if boxes:
                self.hosts = None
                if show3d:   # profiles near a changed plate take their web direction / toe offset from it
                    grow = 60.0 / s
                    boxes = [rg.BoundingBox(bb.Min.X - grow, bb.Min.Y - grow, bb.Min.Z - grow,
                                            bb.Max.X + grow, bb.Max.Y + grow, bb.Max.Z + grow) for bb in boxes]
                    have = set(g for g, o in targets)
                    for g, m in list(self.members.items()):
                        if m.kind != "profile" or g in have:
                            continue
                        o = doc.Objects.FindId(System.Guid(g))
                        if o is None:
                            continue
                        pb = o.Geometry.GetBoundingBox(True)
                        if len(boxes) > 200 or any(_boxes_touch(pb, bb) for bb in boxes):
                            targets.append((g, o))
        self.dirty = set()
        self.all_dirty = False
        if show3d and self.hosts is None and any(o is not None and io.is_profile(o) for g, o in targets):
            try:
                self.hosts = io._display_hosts(st)
            except Exception as ex:
                self._err("hosts", ex)
                self.hosts = None
        mats, props, secs = C.library_index(lib)
        for g, o in targets:
            if o is None:
                self.members.pop(g, None)
                continue
            try:
                self.members[g] = self._member(o, lib, st, s, show3d, props, secs)
            except Exception as ex:
                self._err("member", ex)
                self.members.pop(g, None)
        self.legend_dirty = True
        self._batch(doc)

    def _member(self, o, lib, st, s, show3d, props, secs):
        kind = io.af(o, io.K_KIND)
        mode = st.get("color_by", "Property")
        if mode == "Layer":
            col = io.hex_of(_doc().Layers[o.Attributes.LayerIndex].Color)
        else:
            col = io.member_color(lib, st, o)
        if kind == "plate":
            name = io.af(o, io.K_PROP)
            b = io.brep_of(o.Geometry)
            qty = 0.0
            if b is not None:
                try:
                    amp = rg.AreaMassProperties.Compute(b, True, False, False, False)
                except Exception:
                    amp = rg.AreaMassProperties.Compute(b)
                qty = (amp.Area if amp else 0.0) * s * s
            m = Member("plate", name, qty, col, o.Attributes.LayerIndex)
            if show3d and b is not None:
                pp = props.get(name)
                t = pp["thickness"] if pp else 10.0
                self._plate_mesh(m, b, t / s)
        else:
            name = io.af(o, io.K_SEC)
            crv = o.Geometry
            qty = crv.GetLength() * s if isinstance(crv, rg.Curve) else 0.0
            m = Member("profile", name, qty, col, o.Attributes.LayerIndex)
            if show3d and name in secs and self.hosts is not None:
                self._profile_mesh(m, o, secs[name], lib, st, s)
        return m

    def _plate_mesh(self, m, brep, t_mu):
        parts = rg.Mesh.CreateFromBrep(brep, _meshing_parameters())
        if not parts:
            return
        mid = rg.Mesh()
        for p in parts:
            mid.Append(p)
        try:
            mid.Vertices.CombineIdentical(True, True)
        except Exception:
            pass
        mid.Normals.ComputeNormals()
        V = [[v.X, v.Y, v.Z] for v in mid.Vertices]
        N = [[n.X, n.Y, n.Z] for n in mid.Normals]
        F = []
        for i in range(mid.Faces.Count):
            f = mid.Faces[i]
            F.append((f.A, f.B, f.C) if f.IsTriangle else (f.A, f.B, f.C, f.D))
        V2, F2, E2 = C.thicken_mesh(V, N, F, C.mesh_boundary(F), t_mu / 2.0)
        m.mesh = _to_mesh(V2, F2)
        m.lines = [rg.Line(rg.Point3d(a[0], a[1], a[2]), rg.Point3d(b[0], b[1], b[2])) for a, b in E2]
        m.bbox = m.mesh.GetBoundingBox(False)

    def _profile_mesh(self, m, o, sec, lib, st, s):
        flange = int(float(io.af(o, io.K_FLANGE, "1") or 1))
        offset = io.af(o, io.K_OFFSET) or C.default_offset(sec["stype"])
        V, F, E = [], [], []
        for a, b, ov, tp in io.profile_pieces(o, self.hosts, lib, st):
            v, f, e = C.prism_mesh(sec["stype"], sec["dims"], a, b, ov, flange, offset, tp, 12)
            k = len(V)
            V += [[x / s for x in p] for p in v]
            F += [tuple(i + k for i in ff) for ff in f]
            E += [([x / s for x in p], [x / s for x in q]) for p, q in e]
        if not V:
            return
        m.mesh = _to_mesh(V, F)
        m.lines = [rg.Line(rg.Point3d(p[0], p[1], p[2]), rg.Point3d(q[0], q[1], q[2])) for p, q in E]
        m.bbox = m.mesh.GetBoundingBox(False)

    def _batch(self, doc):
        """Merge the visible members' meshes per colour (a few draw calls per frame)."""
        self.rebatch = False
        groups = {}
        bbox = rg.BoundingBox.Empty
        if self.settings.get("show_3d", True):
            vis = {}
            for g, m in self.members.items():
                if m.mesh is None:
                    continue
                if m.layer not in vis:
                    vis[m.layer] = _layer_visible(doc, m.layer)
                if not vis[m.layer]:
                    continue
                try:
                    o = doc.Objects.FindId(System.Guid(g))
                    if o is None or o.IsHidden or o.IsSelected(False):
                        continue
                except Exception:
                    pass
                grp = groups.get(m.color)
                if grp is None:
                    grp = groups[m.color] = [rg.Mesh(), []]
                grp[0].Append(m.mesh)
                grp[1].extend(m.lines)
                bbox = rg.BoundingBox.Union(bbox, m.bbox) if bbox.IsValid else m.bbox
        alpha = float(self.settings.get("view3d_alpha", 0.0) or 0.0)
        out = []
        for col, (mesh, lines) in groups.items():
            try:
                mat = Rhino.Display.DisplayMaterial(_col(col), max(0.0, min(alpha, 0.9)))
            except Exception:
                mat = Rhino.Display.DisplayMaterial(_col(col))
            arr = System.Array[rg.Line](lines) if lines else None
            out.append((mesh, mat, arr, _darker(col)))
        self.batches = out
        self.bbox = bbox

    # ------------------------------------------------------------------ drawing
    def cb_bbox(self, e):
        if self.batches and self.bbox.IsValid:
            e.IncludeBoundingBox(self.bbox)

    def cb_draw(self, e):
        for mesh, mat, lines, lcol in self.batches:
            e.Display.DrawMeshShaded(mesh, mat)
            if lines is not None:
                e.Display.DrawLines(lines, lcol, 1)

    def cb_foreground(self, e):
        if not self.settings.get("legend", True):
            return
        doc = _doc()
        if doc is None:
            return
        if not self.settings.get("legend_all_views", False):
            try:
                if e.Viewport.Id != doc.Views.ActiveView.ActiveViewportID:
                    return
            except Exception:
                pass
        if self.legend_dirty or self.legend is None:
            self._layout(e.Display)
        if not self.legend:
            return
        b = e.Viewport.Bounds
        x0, y0 = b.Left + 12, b.Top + 12
        for item in self.legend:
            kind = item[0]
            if kind == "rect":
                _, x, y, w, h, stroke, fill = item
                e.Display.Draw2dRectangle(SD.Rectangle(int(x0 + x), int(y0 + y), int(w), int(h)), stroke, 1, fill)
            else:
                _, x, y, text, col, size, font = item
                e.Display.Draw2dText(text, col, rg.Point2d(x0 + x, y0 + y), False, int(size), font)

    def _layout(self, display):
        """Pre-computed drawing list of the property index (recomputed only when the model changes)."""
        st = self.settings
        lib = self.lib or io.load_library()
        try:
            f = float(getattr(display, "DpiScale", 1.0) or 1.0)
        except Exception:
            f = 1.0
        f = max(1.0, min(f, 3.0))
        F_REG, F_BOLD = "Segoe UI", "Segoe UI Semibold"
        h_head, h_row, h_small = int(13 * f), int(12 * f), int(11 * f)
        pad, sw, gap, rh = 10 * f, 12 * f, 8 * f, 19 * f
        members = [dict(kind=m.kind, name=m.name, qty=m.qty) for m in self.members.values()]
        mode = st.get("color_by", "Property")
        L = C.legend_rows(members, lib, mode, st.get("active_prop", ""), st.get("active_section", ""))

        def tw(text, size, font):
            try:
                r = display.Measure2dText(text, rg.Point2d(0, 0), False, 0.0, int(size), font)
                return float(r.Width)
            except Exception:
                return len(text) * size * 0.55

        def dy(size, font):
            """Measure2dText is relative to the anchor; shift so the text top sits at the row top."""
            try:
                r = display.Measure2dText("Ag", rg.Point2d(0, 0), False, 0.0, int(size), font)
                return float(-r.Top) if r.Top < 0 else 0.0
            except Exception:
                return 0.0
        try:
            from . import sync
            team = sync.status_text()
        except Exception:
            team = ""
        title = "ALIEF FEA  |  PROPERTY INDEX"
        sub = "colour by %s   |   %d plates  %d profiles" % (mode, L["counts"][0], L["counts"][1])
        foot = "Total %s   |   3D view %s%s" % (L["total_text"], "ON" if st.get("show_3d", True) else "OFF",
                                                ("   |   " + team) if team else "")
        MAXR = 14
        rows = []
        for gname, grows in L["groups"]:
            if not grows:
                continue
            rows.append(("group", gname))
            for r in grows[:MAXR]:
                rows.append(("row", r))
            if len(grows) > MAXR:
                rows.append(("more", "+ %d more" % (len(grows) - MAXR)))
        if not members:
            rows.append(("more", "No FEA members yet - use Plate / Profile / Assign"))
        wl = max([tw(r[1][1], h_row, F_REG) for r in rows if r[0] == "row"] + [0.0])
        wd = max([tw(r[1][2], h_small, F_REG) for r in rows if r[0] == "row"] + [0.0])
        W = max(pad * 2 + sw + gap + wl + 3 * gap + wd, tw(title, h_head, F_BOLD) + 2 * pad,
                tw(sub, h_small, F_REG) + 2 * pad, tw(foot, h_small, F_REG) + 2 * pad, 220 * f)
        head_h = 42 * f
        H = head_h + pad + sum(rh if k == "row" else 17 * f for k, _ in rows) + 24 * f
        NAVY, GOLD = SD.Color.FromArgb(255, 20, 54, 93), SD.Color.FromArgb(255, 201, 162, 39)
        WHITE, TXT, GREY = SD.Color.FromArgb(255, 255, 255, 255), SD.Color.FromArgb(255, 25, 35, 45), SD.Color.FromArgb(255, 105, 115, 125)
        items = [("rect", 0, 0, W, H, SD.Color.FromArgb(255, 150, 160, 170), SD.Color.FromArgb(232, 255, 255, 255)),
                 ("rect", 0, 0, W, head_h, NAVY, NAVY),
                 ("rect", 0, head_h - 3 * f, W, 3 * f, GOLD, GOLD),
                 ("text", pad, 5 * f, title, WHITE, h_head, F_BOLD),
                 ("text", pad, 23 * f, sub, SD.Color.FromArgb(255, 210, 222, 235), h_small, F_REG)]
        y = head_h + pad * 0.6
        for i, it in enumerate(items):
            if it[0] == "text":
                items[i] = it[:2] + (it[2] + dy(it[5], it[6]),) + it[3:]
        start = len(items)
        for k, r in rows:
            if k == "group":
                items.append(("text", pad, y, r, GREY, h_small, F_BOLD))
                y += 17 * f
            elif k == "more":
                items.append(("text", pad + sw + gap, y, r, GREY, h_small, F_REG))
                y += 17 * f
            else:
                col, lab, det, active = r
                if active:
                    items.append(("rect", 2 * f, y - 1 * f, 4 * f, rh - 3 * f, GOLD, GOLD))
                items.append(("rect", pad, y + 2 * f, sw, sw, _darker(col, 0.6), _col(col)))
                items.append(("text", pad + sw + gap, y, lab, TXT, h_row, F_BOLD if active else F_REG))
                items.append(("text", W - pad - tw(det, h_small, F_REG), y + 1 * f, det, GREY, h_small, F_REG))
                y += rh
        items.append(("rect", 0, H - 22 * f, W, 1, SD.Color.FromArgb(255, 210, 215, 220), SD.Color.FromArgb(255, 210, 215, 220)))
        items.append(("text", pad, H - 19 * f, foot, NAVY, h_small, F_REG))
        for i in range(start, len(items)):
            it = items[i]
            if it[0] == "text":
                items[i] = it[:2] + (it[2] + dy(it[5], it[6]),) + it[3:]
        self.legend = items
        self.legend_dirty = False


CONDUIT_CLASS = "ALIEF_FEA_CONDUIT_CLASS"


def _current():
    lv = sc.sticky.get(STICKY)
    return lv if lv is not None and getattr(lv, "alive", False) else None


def _conduit_class():
    """One DisplayConduit subclass per Rhino session (ordinary class statement - Rhino 8's Python needs the
    class body to carry __module__; defining it again after a reload is avoided by keeping it in sticky).
    The methods always talk to the CURRENT live service, so a reloaded plugin keeps using the same class."""
    cls = sc.sticky.get(CONDUIT_CLASS)
    if cls is not None:
        return cls

    class AliefFeaConduit(Rhino.Display.DisplayConduit):
        def CalculateBoundingBox(self, e):
            lv = _current()
            if lv is not None:
                try:
                    lv.cb_bbox(e)
                except Exception as ex:
                    lv._err("bbox", ex)

        def PostDrawObjects(self, e):
            lv = _current()
            if lv is not None:
                try:
                    lv.cb_draw(e)
                except Exception as ex:
                    lv._err("draw", ex)

        def DrawForeground(self, e):
            lv = _current()
            if lv is not None:
                try:
                    lv.cb_foreground(e)
                except Exception as ex:
                    lv._err("index", ex)
    sc.sticky[CONDUIT_CLASS] = AliefFeaConduit
    return AliefFeaConduit


def _make_conduit(live):
    return _conduit_class()()


# =========================================================================== public
def ensure():
    """Start the live services once per Rhino session (restarted after AF_Reload)."""
    try:
        from . import updater
        updater.auto_check()            # once per session, in the background
    except Exception:
        pass
    lv = sc.sticky.get(STICKY)
    if lv is not None and getattr(lv, "tag", None) == _TAG and getattr(lv, "alive", False):
        return lv
    if lv is not None:
        try:
            lv.stop()
        except Exception:
            pass
    lv = Live()
    try:
        lv.start()
    except Exception as ex:
        Rhino.RhinoApp.WriteLine("ALIEF FEA: live display could not start (%s)" % ex)
    sc.sticky[STICKY] = lv
    return lv


def get():
    lv = sc.sticky.get(STICKY)
    return lv if lv is not None and getattr(lv, "alive", False) else None


def invalidate_all():
    lv = get()
    if lv is not None:
        lv.invalidate_all()


def settings_changed():
    lv = get()
    if lv is not None:
        lv.settings_changed()


def refresh_now():
    """Rebuild immediately (used by the toggle commands, outside other commands)."""
    lv = ensure()
    d = _doc()
    if d is not None:
        lv._read_settings(force=True)
        lv.update(d)
        d.Views.Redraw()
    return lv
