"""Rhino side of ALIEF FEA MODELER: document data, object tags, geometry conversion,
export to / import from ALIEF FEAPRO (.alfea).

Every structural member is an ordinary Rhino object carrying user text:
    AF_KIND    plate | profile
    AF_PROP    plate property name                  (plates)
    AF_SECTION section name                         (profiles)
    AF_SIDE    +N / -N (side of the plate normal) or +X..-Z or V (vector in AF_ORIENT)
    AF_ORIENT  web direction vector "x,y,z"         (AF_SIDE = V)
    AF_FLANGE  +1 / -1                              (mirror of L / BP / C flange)
    AF_OFFSET  auto | centroid | none
    AF_MESH    local mesh size in mm (0 = global)
    AF_ROLE    Plate, Web, Face plate, Bracket, Stiffener, Profile ... (information)
The library (materials, plate properties, sections) and the settings are kept in the
document (Document User Text, section ALIEF_FEA) so they travel with the .3dm file.
"""
import json
import math
import time

import System
import System.Drawing
import Rhino
import Rhino.Geometry as rg
import scriptcontext as sc
import rhinoscriptsyntax as rs

from . import core as C

SECTION = "ALIEF_FEA"
K_KIND, K_PROP, K_SEC, K_SIDE, K_ORIENT = "AF_KIND", "AF_PROP", "AF_SECTION", "AF_SIDE", "AF_ORIENT"
K_FLANGE, K_OFFSET, K_MESH, K_ROLE, K_PREVIEW = "AF_FLANGE", "AF_OFFSET", "AF_MESH", "AF_ROLE", "AF_PREVIEW"
PREVIEW_LAYER = "ALIEF_FEA_PREVIEW"
K_UID = "AF_UID"     # stable id of a member that came from another file (team sync)


# =========================================================================== document
def doc():
    return sc.doc


def scale():
    """Model units -> mm."""
    return Rhino.RhinoMath.UnitScale(sc.doc.ModelUnitSystem, Rhino.UnitSystem.Millimeters)


def tol():
    return sc.doc.ModelAbsoluteTolerance


def atol():
    return sc.doc.ModelAngleToleranceRadians


def P2L(pt, s=None):
    s = scale() if s is None else s
    return [pt.X * s, pt.Y * s, pt.Z * s]


def L2P(p, s=None):
    s = scale() if s is None else s
    return rg.Point3d(p[0] / s, p[1] / s, p[2] / s)


def V(v):
    return rg.Vector3d(v[0], v[1], v[2])


def vlist(v):
    return [v.X, v.Y, v.Z]


def _data(entry):
    try:
        return rs.GetDocumentData(SECTION, entry)
    except Exception:
        return None


def _set_data(entry, text):
    rs.SetDocumentData(SECTION, entry, text)


def load_library():
    lib = C.library_from_json(_data("library"))
    if not _data("library"):
        save_library(lib)
    return lib


def save_library(lib):
    _set_data("library", C.library_to_json(lib))


def load_settings():
    return C.settings_from_json(_data("settings"))


def save_settings(s):
    _set_data("settings", json.dumps(s))


def load_registry():
    return C.IdRegistry(_data("ids"))


def save_registry(reg):
    _set_data("ids", reg.to_json())


# =========================================================================== tags / colours
def sys_color(hexcol):
    r, g, b = C.hex2rgb(hexcol)
    return System.Drawing.Color.FromArgb(r, g, b)


def hex_of(color):
    return C.rgb2hex((color.R, color.G, color.B))


def find(oid):
    gid = rs.coerceguid(oid)
    return sc.doc.Objects.FindId(gid) if gid else None


def af(obj, key, default=""):
    v = obj.Attributes.GetUserString(key)
    return v if v else default


def set_af(obj, values, color=None, name=None, light=False):
    attr = obj.Attributes.Duplicate()
    if light:
        light_display(attr)
    for k, v in values.items():
        if v is None:
            attr.DeleteUserString(k)
        else:
            attr.SetUserString(k, str(v))
    if color is not None:
        attr.ColorSource = Rhino.DocObjects.ObjectColorSource.ColorFromObject
        attr.ObjectColor = sys_color(color)
    if name is not None:
        attr.Name = name
    sc.doc.Objects.ModifyAttributes(obj, attr, True)


def plate_color(lib, prop):
    mats, props, secs = C.library_index(lib)
    pp = props.get(prop)
    if pp is None:
        return "#B0B0B0"
    if pp.get("color"):
        return pp["color"]
    return C.thickness_color(pp["thickness"])


def section_color(lib, sec):
    mats, props, secs = C.library_index(lib)
    s = secs.get(sec)
    return s.get("color", "#C9A227") if s else "#808080"


def member_color(lib, settings, obj):
    """Display colour of a member for the chosen 'colour by' mode."""
    mode = settings.get("color_by", "Property")
    mats, props, secs = C.library_index(lib)
    if af(obj, K_KIND) == "plate":
        pp = props.get(af(obj, K_PROP))
        if mode == "Material" and pp and pp["material"] in mats:
            return mats[pp["material"]].get("color", "#7FA7C9")
        if mode == "Thickness" and pp:
            return C.thickness_color(pp["thickness"])
        return plate_color(lib, af(obj, K_PROP))
    s = secs.get(af(obj, K_SEC))
    if mode == "Material" and s and s["material"] in mats:
        return mats[s["material"]].get("color", "#C9A227")
    return section_color(lib, af(obj, K_SEC))


def ensure_layer(path, color=None):
    idx = sc.doc.Layers.FindByFullPath(path, -1)
    if idx >= 0:
        return idx
    parent = System.Guid.Empty
    cur = ""
    parts = [p for p in path.split("::") if p]
    for i, nm in enumerate(parts):
        cur = nm if i == 0 else cur + "::" + nm
        idx = sc.doc.Layers.FindByFullPath(cur, -1)
        if idx < 0:
            L = Rhino.DocObjects.Layer()
            L.Name = nm
            if color and i == len(parts) - 1:
                L.Color = sys_color(color)
            if parent != System.Guid.Empty:
                L.ParentLayerId = parent
            idx = sc.doc.Layers.Add(L)
        parent = sc.doc.Layers[idx].Id
    return idx


def layer_group(obj):
    return sc.doc.Layers[obj.Attributes.LayerIndex].FullPath.replace("::", " / ")


def af_objects(kind=None):
    st = Rhino.DocObjects.ObjectEnumeratorSettings()
    st.HiddenObjects = True
    st.LockedObjects = True
    st.DeletedObjects = False
    st.IncludeLights = False
    st.IncludeGrips = False
    out = []
    for obj in sc.doc.Objects.GetObjectList(st):
        k = obj.Attributes.GetUserString(K_KIND)
        if not k or obj.Attributes.GetUserString(K_PREVIEW):
            continue
        if kind is None or k == kind:
            out.append(obj)
    return out


def uid_of(obj, seen=None):
    """Stable member id for the ALIEF FEAPRO id registry: the AF_UID a member brought from its owner's
    file (team sync), otherwise the Rhino object id. Duplicates (copied objects) fall back to the object id."""
    u = obj.Attributes.GetUserString(K_UID) or ""
    if not u or (seen is not None and u in seen):
        u = str(obj.Id)
    if seen is not None:
        seen.add(u)
    return u


def light_display(attr, settings=None):
    """Plates are drawn with their boundary only (no isocurve grid) - lighter and clearer on big models."""
    try:
        if settings is None or settings.get("plate_light", True):
            attr.WireDensity = -1
    except Exception:
        pass


def is_plate(obj):
    return obj is not None and af(obj, K_KIND) == "plate"


def is_profile(obj):
    return obj is not None and af(obj, K_KIND) == "profile"


def brep_of(geo):
    if isinstance(geo, rg.Brep):
        return geo
    if isinstance(geo, rg.Extrusion):
        return geo.ToBrep()
    if isinstance(geo, rg.Surface):
        return rg.Brep.CreateFromSurface(geo)
    return None


def add_plate(brep, prop, lib, settings=None, name="", role="Plate", layer_index=None, mesh_size=0.0):
    attr = Rhino.DocObjects.ObjectAttributes()
    attr.LayerIndex = sc.doc.Layers.CurrentLayerIndex if layer_index is None else layer_index
    attr.ColorSource = Rhino.DocObjects.ObjectColorSource.ColorFromObject
    attr.ObjectColor = sys_color(plate_color(lib, prop))
    if name:
        attr.Name = name
    attr.SetUserString(K_KIND, "plate")
    attr.SetUserString(K_PROP, prop)
    attr.SetUserString(K_ROLE, role)
    light_display(attr, settings)
    if mesh_size:
        attr.SetUserString(K_MESH, "%g" % mesh_size)
    return sc.doc.Objects.AddBrep(brep, attr)


def add_curve(crv, layer_index=None, name=""):
    attr = Rhino.DocObjects.ObjectAttributes()
    attr.LayerIndex = sc.doc.Layers.CurrentLayerIndex if layer_index is None else layer_index
    if name:
        attr.Name = name
    return sc.doc.Objects.AddCurve(crv, attr)


def tag_profile(oid, lib, section, side="+N", flange=1, offset=None, role="Profile", orient=None, name=None):
    obj = find(oid)
    if obj is None:
        return False
    secs = C.library_index(lib)[2]
    if offset is None:
        offset = C.default_offset(secs[section]["stype"]) if section in secs else "auto"
    vals = {K_KIND: "profile", K_SEC: section, K_SIDE: side, K_FLANGE: int(flange), K_OFFSET: offset, K_ROLE: role,
            K_ORIENT: ("%.9g,%.9g,%.9g" % tuple(orient)) if orient is not None else None}
    set_af(obj, vals, color=section_color(lib, section), name=name)
    return True


def tag_plate(oid, lib, prop, role=None, name=None):
    obj = find(oid)
    if obj is None:
        return False
    vals = {K_KIND: "plate", K_PROP: prop}
    if role:
        vals[K_ROLE] = role
    set_af(obj, vals, color=plate_color(lib, prop), name=name, light=True)
    return True


def recolor_all(lib, settings):
    mode = settings.get("color_by", "Property")
    n = 0
    for obj in af_objects():
        attr = obj.Attributes.Duplicate()
        if mode == "Layer":
            attr.ColorSource = Rhino.DocObjects.ObjectColorSource.ColorFromLayer
        else:
            attr.ColorSource = Rhino.DocObjects.ObjectColorSource.ColorFromObject
            attr.ObjectColor = sys_color(member_color(lib, settings, obj))
        sc.doc.Objects.ModifyAttributes(obj, attr, True)
        n += 1
    sc.doc.Views.Redraw()
    return n


# =========================================================================== geometry helpers
def face_normal(face, pt):
    rc, u, v = face.ClosestPoint(pt)
    n = face.NormalAt(u, v)
    out = [n.X, n.Y, n.Z]
    if face.OrientationIsReversed:
        out = [-out[0], -out[1], -out[2]]
    return C.v_unit(out, [0, 0, 1])


def curve_points(crv, chord_mu, maxlen_mu=0.0):
    """Points of a curve (model units): polyline vertices, or a chord polyline for arcs / splines."""
    rc, pl = crv.TryGetPolyline()
    if rc:
        pts = [pl[i] for i in range(pl.Count)]
    else:
        plc = crv.ToPolyline(chord_mu, math.radians(5.0), 0.0, maxlen_mu)
        pts = None
        if plc is not None:
            rc2, pl2 = plc.TryGetPolyline()
            if rc2:
                pts = [pl2[i] for i in range(pl2.Count)]
        if pts is None:
            n = 64
            dom = crv.Domain
            pts = [crv.PointAt(dom.ParameterAt(float(i) / n)) for i in range(n + 1)]
    if crv.IsClosed and len(pts) > 1 and pts[0].DistanceTo(pts[-1]) < 1e-9:
        pts = pts[:-1]
    return pts


def dense_points(crv, step_mu):
    L = crv.GetLength()
    n = max(2, int(math.ceil(L / max(step_mu, 1e-9))))
    pts = []
    for i in range(n + 1):
        rc, t = crv.LengthParameter(L * i / n)
        pts.append(crv.PointAt(t) if rc else crv.PointAt(crv.Domain.ParameterAt(float(i) / n)))
    return pts


def plate_faces(obj):
    b = brep_of(obj.Geometry)
    if b is None:
        return []
    return [b.Faces[i] for i in range(b.Faces.Count)]


def planar_face_data(face, s, chord_mu, t):
    """(outer pts mm, [hole dicts], normal) of a planar face."""
    outer, holes = None, []
    for li in range(face.Loops.Count):
        loop = face.Loops[li]
        crv = loop.To3dCurve()
        if crv is None:
            continue
        if loop.LoopType == rg.BrepLoopType.Outer:
            outer = [P2L(p, s) for p in curve_points(crv, chord_mu)]
        elif loop.LoopType == rg.BrepLoopType.Inner:
            rc, circ = crv.TryGetCircle(t)
            if rc:
                holes.append(dict(circle=(P2L(circ.Center, s), 2.0 * circ.Radius * s)))
            else:
                holes.append(dict(pts=[P2L(p, s) for p in curve_points(crv, chord_mu)]))
    mid = face.Domain(0).Mid, face.Domain(1).Mid
    n = face_normal(face, face.PointAt(mid[0], mid[1]))
    return outer, holes, n


# =========================================================================== host plates
class PlanarIndex(object):
    """Planar plate polygons (mm) for finding the plate a profile lies on (grid index - fast on big models)."""

    def __init__(self, items, tol_mm):
        self.items = []
        self.tol = max(tol_mm, 0.01)
        for it in items:
            P = it["points"]
            if len(P) < 3:
                continue
            fr = C.plate_frame(P)
            lo = [min(q[k] for q in P) - self.tol for k in range(3)]
            hi = [max(q[k] for q in P) + self.tol for k in range(3)]
            holes = [C.to_local(h, fr) for h in it.get("hole_outlines", [])]
            self.items.append(dict(it, fr=fr, loc=C.to_local(P, fr), lo=lo, hi=hi, holes_loc=holes))
        sizes = sorted(max(it["hi"][k] - it["lo"][k] for k in range(3)) for it in self.items) or [1000.0]
        self.grid = C.GridIndex(max(sizes[len(sizes) // 2], 50.0))
        for i, it in enumerate(self.items):
            self.grid.add(i, it["lo"], it["hi"])

    def host(self, a, b):
        mid = C.v_lerp(a, b, 0.5)
        best = None
        for i in sorted(self.grid.query(mid, mid)):
            it = self.items[i]
            if any(mid[k] < it["lo"][k] or mid[k] > it["hi"][k] for k in range(3)):
                continue
            o, u, v, n = it["fr"]
            if abs(C.v_dot(C.v_sub(a, o), n)) > self.tol or abs(C.v_dot(C.v_sub(b, o), n)) > self.tol:
                continue
            uv = C.to_local([mid], it["fr"])[0]
            if C.point_in_poly(uv, it["loc"]) or C.poly_boundary_dist2d(uv, it["loc"]) <= self.tol:
                if best is None or C.point_in_poly(uv, it["loc"]):
                    best = it
                    if C.point_in_poly(uv, it["loc"]):
                        break
        return best


def side_vector(side, orient_text, host_normal):
    if side in ("+N", "-N"):
        if host_normal is None:
            return None
        return C.v_mul(host_normal, 1.0 if side == "+N" else -1.0)
    if side in C.AXES:
        return list(C.AXES[side])
    try:
        v = [float(x) for x in orient_text.split(",")]
        if len(v) == 3 and C.v_len(v) > 1e-9:
            return C.v_unit(v)
    except Exception:
        pass
    return None


# =========================================================================== export
class Cancelled(Exception):
    """The user pressed Esc (or declined the facet-count warning) during the export."""


class Job(object):
    """Progress meter in Rhino's status bar, Esc to cancel, and the time of every stage for the report."""

    def __init__(self, say=None):
        self.say = say
        self.lines = []
        self.t0 = time.time()
        self.t_stage = self.t0
        self.escaped = False
        self._last = 0.0
        self._meter = False
        self._hook = None
        try:
            def on_escape(sender, e):
                self.escaped = True
            Rhino.RhinoApp.EscapeKeyPressed += on_escape
            self._hook = on_escape
        except Exception:
            self._hook = None

    def stage(self, label, total=0):
        self._hide()
        self.t_stage = time.time()
        if total and total > 1:
            try:
                Rhino.UI.StatusBar.ShowProgressMeter(0, int(total), label, True, True)
                self._meter = True
            except Exception:
                self._meter = False
        try:
            Rhino.RhinoApp.SetCommandPrompt("ALIEF FEA export: %s ... (Esc = cancel)" % label)
        except Exception:
            pass
        self.poll()

    def tick(self, i):
        now = time.time()
        if now - self._last < 0.25:
            return
        self._last = now
        if self._meter:
            try:
                Rhino.UI.StatusBar.UpdateProgressMeter(int(i), True)
            except Exception:
                pass
        self.poll()

    def poll(self):
        try:
            Rhino.RhinoApp.Wait()
        except Exception:
            pass
        esc = getattr(sc, "escape_test", None)
        if esc is not None:
            try:
                if esc(False):
                    self.escaped = True
            except Exception:
                pass
        if self.escaped:
            raise Cancelled("cancelled with Esc")

    def done(self, text):
        msg = "%s  [%.1f s]" % (text, time.time() - self.t_stage)
        self.lines.append(msg)
        self._hide()
        if self.say:
            self.say(msg)

    def note(self, text):
        self.lines.append(text)
        if self.say:
            self.say(text)

    def total(self):
        return time.time() - self.t0

    def _hide(self):
        if self._meter:
            try:
                Rhino.UI.StatusBar.HideProgressMeter()
            except Exception:
                pass
            self._meter = False

    def close(self):
        self._hide()
        if self._hook is not None:
            try:
                Rhino.RhinoApp.EscapeKeyPressed -= self._hook
            except Exception:
                pass
            self._hook = None


class Coarsen(Exception):
    """Too many facets: run the export again with a larger facet size."""

    def __init__(self, facet, n):
        Exception.__init__(self, "coarsen to %g" % facet)
        self.facet, self.n = facet, n


AXES_XYZ = (("limit_x", 0, "X"), ("limit_y", 1, "Y"), ("limit_z", 2, "Z"))


def export_limits(settings):
    """[(axis, (lo, hi)) ...] of the export limits in mm."""
    out = []
    for key, axis, name in AXES_XYZ:
        lim = C.parse_limits(settings.get(key, ""))
        if lim:
            out.append((axis, lim))
    return out


def limits_text(settings):
    out = []
    for key, axis, name in AXES_XYZ:
        lim = C.parse_limits(settings.get(key, ""))
        if lim:
            out.append("%s %s..%g" % (name, ("%g" % lim[0]) if lim[0] > -1e29 else "", lim[1]))
    return ", ".join(out)


class ExportResult(object):
    def __init__(self):
        self.plates, self.beams, self.layers, self.messages = [], [], [], []
        self.n_curved = 0
        self.n_facets = 0
        self.n_triangles = 0
        self.n_skipped = 0
        self.method = ""
        self.scope = ""


SCOPES = ["All AF members", "Visible members only", "Selected members only"]
CURVED_METHODS = ["Fast", "Classic"]
CURVED_LABELS = {"Fast": "Fast - light shell mesh, local cuts (v1.2, recommended)",
                 "Classic": "Classic - split the NURBS surfaces (v1.1, slow on big models)"}


def scope_filter(scope):
    scope = scope or SCOPES[0]
    if scope.startswith("Visible"):
        def f(obj):
            try:
                if obj.IsHidden or not obj.Visible:
                    return False
                return sc.doc.Layers[obj.Attributes.LayerIndex].IsVisible
            except Exception:
                return True
        return f
    if scope.startswith("Selected"):
        def g(obj):
            try:
                return obj.IsSelected(False) > 0
            except Exception:
                return False
        return g
    return lambda obj: True


# --------------------------------------------------------------------------- light copies of dense faces
def _uv_box(face):
    """Parameter box of the face's trims (the used part of a big, untrimmed underlying surface)."""
    du, dv = face.Domain(0), face.Domain(1)
    u0, u1, v0, v1 = du.Min, du.Max, dv.Min, dv.Max
    bb = None
    for li in range(face.Loops.Count):
        try:
            c2 = face.Loops[li].To2dCurve()
        except Exception:
            c2 = None
        if c2 is None:
            continue
        b = c2.GetBoundingBox(True)
        bb = b if bb is None else rg.BoundingBox.Union(bb, b)
    if bb is not None and bb.IsValid:
        pu, pv = 1e-9 * max(1.0, u1 - u0), 1e-9 * max(1.0, v1 - v0)
        a0, a1 = max(u0, bb.Min.X - pu), min(u1, bb.Max.X + pu)
        b0, b1 = max(v0, bb.Min.Y - pv), min(v1, bb.Max.Y + pv)
        if a1 - a0 > 1e-12 and b1 - b0 > 1e-12:
            u0, u1, v0, v1 = a0, a1, b0, b1
    return u0, u1, v0, v1


def _trimmed(face, ns, tol_mu):
    if ns is None or not ns.IsValid:
        return None
    try:
        b = rg.Brep.CreateTrimmedSurface(face, ns, tol_mu)
    except Exception:
        b = rg.Brep.CreateTrimmedSurface(face, ns)
    if b is None or b.Faces.Count != 1:
        return None
    return b


def light_face_cubic(face, s, facet_mm, shape_mm, tol_mu):
    """Light bicubic copy of a dense trimmed face in the face's own uv space (so its own trims still fit),
    with long spans that the mesher then refines locally to the facet size. Returns (brep, fit error mm)."""
    box = _uv_box(face)
    if box[1] - box[0] <= 0.0 or box[3] - box[2] <= 0.0:
        return None, 0.0
    fit = C.fit_cubic_light(lambda u, v: P2L(face.PointAt(u, v), s), box, max(2.0 * facet_mm, 600.0), 0.5 * shape_mm)
    cp = fit["cp"]
    nu, nv = len(cp), len(cp[0])
    ns = rg.NurbsSurface.Create(3, False, 4, 4, nu, nv)
    if ns is None:
        return None, 0.0
    for i, k in enumerate(fit["ku"]):
        ns.KnotsU[i] = k
    for j, k in enumerate(fit["kv"]):
        ns.KnotsV[j] = k
    for i in range(nu):
        for j in range(nv):
            q = cp[i][j]
            pt = rg.Point3d(q[0] / s, q[1] / s, q[2] / s)
            try:
                ns.Points.SetPoint(i, j, pt)
            except Exception:
                ns.Points.SetControlPoint(i, j, rg.ControlPoint(pt))
    return _trimmed(face, ns, tol_mu), fit["err"]


def light_face(face, s, step_mm, shape_mm, tol_mu, max_samples=10000):
    """Light copy of a (dense) trimmed face: a degree-1 surface through points of the face, spaced about one
    facet apart (closer where the plating bends, so the chord stays within shape_mm), in the face's own uv
    space, trimmed with the face's own trims. Meshing it gives about one facet per span instead of one per
    knot span of the original NURBS (a 148 x 649 point hull surface gives 94 000 facets otherwise).
    Fallback of light_face_cubic."""
    u0, u1, v0, v1 = _uv_box(face)
    if u1 - u0 <= 0.0 or v1 - v0 <= 0.0:
        return None

    def sample(nu, nv):
        us = [u0 + (u1 - u0) * i / (nu - 1.0) for i in range(nu)]
        vs = [v0 + (v1 - v0) * j / (nv - 1.0) for j in range(nv)]
        P = [[P2L(face.PointAt(u, v), s) for v in vs] for u in us]
        return us, vs, P
    us, vs, P = sample(9, 9)
    lu, lv, _, _ = C.grid_lengths(P)
    h = max(step_mm / 2.0, 1.0)
    nu = int(min(max(sum(lu) / h, 4.0), 300.0)) + 1
    nv = int(min(max(sum(lv) / h, 4.0), 300.0)) + 1
    if nu * nv > max_samples:
        f = math.sqrt(float(max_samples) / (nu * nv))
        nu, nv = max(5, int(nu * f)), max(5, int(nv * f))
    us, vs, P = sample(nu, nv)
    lu, lv, bu, bv = C.grid_lengths(P)
    nus = C.iso_params(us, lu, step_mm, bu, shape_mm)
    nvs = C.iso_params(vs, lv, step_mm, bv, shape_mm)
    ns = rg.NurbsSurface.Create(3, False, 2, 2, len(nus), len(nvs))
    if ns is None:
        return None
    for i, u in enumerate(nus):
        ns.KnotsU[i] = u
    for j, v in enumerate(nvs):
        ns.KnotsV[j] = v
    for i, u in enumerate(nus):
        for j, v in enumerate(nvs):
            pt = face.PointAt(u, v)
            try:
                ns.Points.SetPoint(i, j, pt)
            except Exception:
                ns.Points.SetControlPoint(i, j, rg.ControlPoint(pt))
    return _trimmed(face, ns, tol_mu)


def _mesh_tris(m):
    """(points, triangles) of a Rhino mesh."""
    try:
        pts = list(m.Vertices.ToPoint3dArray())
    except Exception:
        pts = [rg.Point3d(m.Vertices[i]) for i in range(m.Vertices.Count)]
    tris = []
    try:
        ia = list(m.Faces.ToIntArray(True))
        tris = [(ia[k], ia[k + 1], ia[k + 2]) for k in range(0, len(ia) - 2, 3)]
    except Exception:
        for fi in range(m.Faces.Count):
            f = m.Faces[fi]
            if f.IsQuad:
                if pts[f.A].DistanceTo(pts[f.C]) <= pts[f.B].DistanceTo(pts[f.D]):
                    tris += [(f.A, f.B, f.C), (f.A, f.C, f.D)]
                else:
                    tris += [(f.A, f.B, f.D), (f.B, f.C, f.D)]
            else:
                tris.append((f.A, f.B, f.C))
    return pts, tris


def _curved_fast(curved, planar, settings, s, t, job, confirm, res):
    """Curved plating -> conforming planar facets, cut locally along the webs / decks that land on it."""
    tol_mm = t * s
    facet_mm = float(settings.get("facet_size", 300.0) or 300.0)
    chord_mm = float(settings.get("chord_tol", 1.0) or 1.0)
    shape_mm = max(float(settings.get("shell_tol", 2.0) or 2.0), 0.05)
    touch_mm = max(2.0 * chord_mm, 2.5 * shape_mm + 0.5, 4.0 * tol_mm, 0.5)
    join_mu = max(2.0 * t, (shape_mm + chord_mm) / s)
    # 1. light copies
    job.stage("Light copies of %d curved faces" % len(curved), len(curved))
    lights, n_heavy, n_lin, fit_err = [], 0, 0, 0.0
    for ci, c in enumerate(curved):
        job.tick(ci)
        b = None
        try:
            b, e = light_face_cubic(c["face"], s, facet_mm, shape_mm, t)
            if b is not None:
                fit_err = max(fit_err, e)
        except Cancelled:
            raise
        except Exception:
            b = None
        if b is None:
            try:
                b = light_face(c["face"], s, facet_mm, shape_mm, t)
                if b is not None:
                    n_lin += 1
            except Exception:
                b = None
        if b is None:
            b = c["face"].DuplicateFace(False)
            n_heavy += 1
        lights.append(b)
    job.done("Curved faces: %d light copies (largest shape difference %.1f mm)%s%s"
             % (len(curved) - n_heavy, fit_err, (", %d linear" % n_lin) if n_lin else "",
                (", %d kept as they are (could not be simplified)" % n_heavy) if n_heavy else ""))
    if n_heavy:
        res.messages.append("%d curved face(s) could not be simplified and were meshed as they are (slower) - "
                            "check them with _ShowEdges / _SelBadObjects" % n_heavy)
    # 2. join + mesh
    joined = list(rg.Brep.JoinBreps(lights, join_mu) or lights)
    mp = rg.MeshingParameters()
    mp.MaximumEdgeLength = facet_mm / s
    mp.MinimumEdgeLength = 0.01 * facet_mm / s
    mp.Tolerance = shape_mm / s
    mp.RefineGrid = True
    mp.JaggedSeams = False
    mp.SimplePlanes = False
    try:
        mp.GridAspectRatio = 0.0
        mp.ComputeCurvature = False
        mp.ClosedObjectPostProcess = False
    except Exception:
        pass
    boxes = []
    g = join_mu * 2.0
    for b in lights:
        bb = b.GetBoundingBox(True)
        boxes.append(rg.BoundingBox(bb.Min.X - g, bb.Min.Y - g, bb.Min.Z - g, bb.Max.X + g, bb.Max.Y + g, bb.Max.Z + g))
    qk = 1e4 * s                    # vertex merge key: 0.1 micron
    vmap, V, T, owners = {}, [], [], []
    job.stage("Meshing %d curved shell part(s)" % len(joined), len(joined))
    for bi, jb in enumerate(joined):
        job.tick(bi)
        ms = rg.Mesh.CreateFromBrep(jb, mp)
        for m in (ms or []):
            if m is None or m.Faces.Count == 0:
                continue
            pts, tris = _mesh_tris(m)
            if not tris:
                continue
            def centre(tri):
                a, b, c = tri
                return rg.Point3d((pts[a].X + pts[b].X + pts[c].X) / 3.0, (pts[a].Y + pts[b].Y + pts[c].Y) / 3.0,
                                  (pts[a].Z + pts[b].Z + pts[c].Z) / 3.0)

            def owner_of(cen):
                cand = [ci for ci, bb in enumerate(boxes) if bb.Contains(cen)]
                if len(cand) == 1:
                    return cand[0]
                best, bd = 0, 1e30
                for ci in (cand or range(len(lights))):
                    d = lights[ci].ClosestPoint(cen).DistanceTo(cen)
                    if d < bd:
                        best, bd = ci, d
                return best

            def flipped(tri, owner, cen):
                nf = face_normal(curved[owner]["face"], cen)
                tn = C.newell_normal([P2L(pts[k], s) for k in tri])
                return C.v_dot(tn, nf) < 0.0
            probes = [tris[0], tris[len(tris) // 2], tris[-1]]
            pc = [centre(x) for x in probes]
            po = [owner_of(c) for c in pc]
            one = po[0] if po[0] == po[1] == po[2] else None    # normally one mesh per face
            if one is not None:
                flip_all = flipped(probes[0], one, pc[0])
            loc = []
            for p in pts:
                key = (int(round(p.X * qk)), int(round(p.Y * qk)), int(round(p.Z * qk)))
                vi = vmap.get(key)
                if vi is None:
                    vi = len(V)
                    vmap[key] = vi
                    V.append(P2L(p, s))
                loc.append(vi)
            for tr in tris:
                if one is not None:
                    owner, flip = one, flip_all
                else:
                    cen = centre(tr)
                    owner = owner_of(cen)
                    flip = flipped(tr, owner, cen)
                a, b, c = tr
                tri = (loc[a], loc[c], loc[b]) if flip else (loc[a], loc[b], loc[c])
                if len(set(tri)) == 3:
                    T.append(tri)
                    owners.append(owner)
    res.n_triangles = len(T)
    job.done("Curved plating meshed: %d triangles (facet %g mm, shape tolerance %g mm)" % (len(T), facet_mm, shape_mm))
    limit = int(float(settings.get("max_facets", 5000) or 0))
    asked = [False]

    def check_count(n, early=False):
        # more facets than ALIEF FEAPRO can open: coarsen automatically (or ask, when a dialog is available)
        if not limit or n <= limit * (5 if early else 1):
            return
        f_new = 50.0 * math.ceil(facet_mm * min(4.0, max(1.25, math.sqrt(float(n) / limit))) / 50.0)
        if settings.get("_tries", 0) >= 4:
            if not asked[0]:
                asked[0] = True
                res.messages.append("STILL %d facets (limit %d) at facet size %g mm / shape tolerance %g mm - export a smaller "
                                    "part: Limit X / Y / Z or Export: Selected members only" % (n, limit, facet_mm, shape_mm))
            return
        if settings.get("auto_coarsen", True):
            raise Coarsen(f_new, n)
        if confirm is not None and not confirm(n, f_new):
            raise Cancelled("too many facets: %d" % n)
        asked[0] = True                 # export as it is
        limit_off[0] = True
    limit_off = [False]
    # 3. shell index, plates landing on it, local cuts
    job.stage("Indexing the shell")
    sm = C.ShellMesh(V, T, owners, max(facet_mm, 10.0))
    job.done("Shell index ready")
    lims = export_limits(settings)
    if lims:
        job.stage("Cutting the curved plating at the export limits")
        for axis, (lo, hi) in lims:         # rough first (keeps a margin), exact after the shape check
            C.shell_clip_slab(sm, axis, lo - 2.0 * facet_mm, hi + 2.0 * facet_mm)
        job.done("Curved plating outside the export limits removed: %d triangles left" % sm.count())
        if sm.count() == 0:
            return [], {}
    check_count(sm.count(), early=True)
    # the facets must follow the real plating within the shape tolerance, whatever the mesher did
    job.stage("Checking the facets against the real surfaces", len(T))

    def project(owner, p):
        try:
            face = curved[owner]["face"]
            rc, u, v = face.ClosestPoint(L2P(p, s))
            if not rc:
                return None
            return P2L(face.PointAt(u, v), s)
        except Exception:
            return None
    n_ref = sm.refine(project, shape_mm, job=job)
    job.done("Facets checked against the real surfaces: %d nodes added where the plating bends more" % n_ref)
    if settings.get("decimate", True):
        n_before = sm.count()
        job.stage("Coarsening the shell where it is denser than the facet size", n_before)
        n_rem = sm.decimate(0.7 * facet_mm, 1.5 * facet_mm, shape_mm, job=job)
        job.done("Shell coarsened: %d -> %d triangles (%d nodes removed, shape kept within %g mm)"
                 % (n_before, sm.count(), n_rem, shape_mm))
    if lims:
        for axis, (lo, hi) in lims:
            C.shell_clip_slab(sm, axis, lo, hi)
        if sm.count() == 0:
            return [], {}
    slo, shi = sm.bbox()
    slo = [x - touch_mm for x in slo]
    shi = [x + touch_mm for x in shi]
    job.stage("Finding webs / decks on the curved plating", len(planar))
    touch = []
    for k, p in enumerate(planar):
        job.tick(k)
        P = p["points"]
        plo, phi = C.bbox_of(P)
        if any(phi[m] < slo[m] or plo[m] > shi[m] for m in range(3)):
            continue
        near = [sm.closest(qq, touch_mm)[0] is not None for qq in P]
        if sum(near) >= 2:
            touch.append((k, near))
    job.done("%d planar plates land on the curved plating" % len(touch))
    job.stage("Cutting the shell along %d plates" % len(touch), len(touch))
    cboxes = []
    for pid, (k, near) in enumerate(touch):
        job.tick(pid)
        P = planar[k]["points"]
        fr = C.plate_frame(P)
        lo, hi = C.bbox_of([qq for qq, f in zip(P, near) if f], max(2.0 * touch_mm, 0.5 * facet_mm))
        cboxes.append((lo, hi))
        sm.cut_plane(pid, fr[0], fr[3], lo, hi, touch_mm)
    conform = {}
    for pid, (k, near) in enumerate(touch):
        p = planar[k]
        lo, hi = cboxes[pid]
        newp, nruns = C.conform_edges_to_facets(p["points"], near, sm.plane_points(pid, lo, hi),
                                                run_tol=touch_mm * 2, snap_tol=touch_mm * 2)
        if nruns:
            p["points"] = newp
            conform[k] = nruns
    job.done("Shell cut along %d plates (%d new nodes, %d nodes moved onto the lines), %d plates re-edged"
             % (len(touch), sm.n_cut, sm.n_slid, len(conform)))
    facets = sm.facets()
    if settings.get("merge_flat", True):
        job.stage("Merging flat facets")
        n0 = len(facets)
        facets = C.merge_flat_facets(facets, locked=sm.locked_keys())
        job.done("Flat / ruled parts: %d triangles -> %d planar facets" % (n0, len(facets)))
    if not limit_off[0]:
        check_count(len(facets))
    return facets, conform


def _curved_classic(curved, planar, settings, s, t, job, res):
    """v1.1 method: split the NURBS surfaces with full planes and mesh them (slow on dense hull surfaces)."""
    tol_mm = t * s
    chord_mm = float(settings.get("chord_tol", 1.0) or 1.0)
    chord_mu = chord_mm / s
    facet_mm = float(settings.get("facet_size", 300.0) or 300.0)
    touch_mm = max(2.0 * chord_mm, 4.0 * tol_mm, 0.5)
    facets = []
    conform = {}
    face_breps = [c["face"].DuplicateFace(False) for c in curved]
    bb = face_breps[0].GetBoundingBox(True)
    for b in face_breps[1:]:
        bb = rg.BoundingBox.Union(bb, b.GetBoundingBox(True))
    R = bb.Diagonal.Length * 1.5 + 1.0
    job.stage("Classic: plates touching the curved plating", len(planar))
    touch_planes = []
    for k, p in enumerate(planar):
        job.tick(k)
        pts_mu = [L2P(q, s) for q in p["points"]]
        near = [False] * len(pts_mu)
        interior = False
        for j, pt in enumerate(pts_mu):
            if not bb.Contains(pt) and bb.ClosestPoint(pt).DistanceTo(pt) > touch_mm / s:
                continue
            for b in face_breps:
                cp = b.ClosestPoint(pt)
                if cp.DistanceTo(pt) * s <= touch_mm:
                    near[j] = True
                    dmin = 1e30
                    for ei in range(b.Edges.Count):
                        rc, tt = b.Edges[ei].ClosestPoint(pt)
                        if rc:
                            dmin = min(dmin, b.Edges[ei].PointAt(tt).DistanceTo(pt) * s)
                    if dmin > touch_mm * 2:
                        interior = True
                    break
        if sum(near) >= 2:
            fr = C.plate_frame(p["points"])
            touch_planes.append(dict(k=k, near=near, interior=interior, o=fr[0], n=fr[3]))
    job.done("Classic: %d plates touch the curved plating" % len(touch_planes))
    pieces = list(rg.Brep.JoinBreps(face_breps, t) or face_breps)
    job.stage("Classic: splitting the curved plating", len(touch_planes))
    for ti, tp in enumerate(touch_planes):
        job.tick(ti)
        if not tp["interior"]:
            continue
        o = L2P(tp["o"], s)
        pl = rg.Plane(o, V(tp["n"]))
        cutter = rg.PlaneSurface(pl, rg.Interval(-R, R), rg.Interval(-R, R)).ToBrep()
        nxt = []
        for b in pieces:
            parts = b.Split(cutter, t)
            if parts and len(parts) > 0:
                nxt.extend(list(parts))
            else:
                nxt.append(b)
        pieces = nxt
    job.done("Classic: curved plating split into %d pieces" % len(pieces))
    joined = list(rg.Brep.JoinBreps(pieces, t) or pieces)
    mp = rg.MeshingParameters()
    mp.MaximumEdgeLength = facet_mm / s
    mp.MinimumEdgeLength = 0.02 * facet_mm / s
    mp.Tolerance = chord_mu
    mp.RefineGrid = True
    mp.JaggedSeams = False
    mp.SimplePlanes = False
    job.stage("Classic: meshing", len(joined))
    mesh = rg.Mesh()
    for bi, b in enumerate(joined):
        job.tick(bi)
        ms = rg.Mesh.CreateFromBrep(b, mp)
        if ms:
            for m in ms:
                mesh.Append(m)
    mesh.Vertices.CombineIdentical(True, True)
    mesh.Compact()
    V3 = [P2L(rg.Point3d(mesh.Vertices[i]), s) for i in range(mesh.Vertices.Count)]
    boxes = [b.GetBoundingBox(True) for b in face_breps]
    job.done("Classic: %d mesh faces" % mesh.Faces.Count)
    job.stage("Classic: facets", mesh.Faces.Count)
    for fi in range(mesh.Faces.Count):
        job.tick(fi)
        f = mesh.Faces[fi]
        idx = [f.A, f.B, f.C, f.D] if f.IsQuad else [f.A, f.B, f.C]
        quad = [V3[i] for i in idx]
        cen = L2P(C.centroid(quad), s)
        owner, bd = 0, 1e30
        for ci, b in enumerate(face_breps):
            if len(face_breps) > 1 and boxes[ci].ClosestPoint(cen).DistanceTo(cen) > bd:
                continue
            d = b.ClosestPoint(cen).DistanceTo(cen)
            if d < bd:
                owner, bd = ci, d
        nf = face_normal(curved[owner]["face"], cen)
        for tri in C.triangulate_facet(quad):
            if C.v_dot(C.newell_normal(tri), nf) < 0:
                tri = tri[::-1]
            if C.polygon_area3d(tri) > 1e-6:
                facets.append(dict(pts=tri, owner=owner))
    res.n_triangles = len(facets)
    planes = [(tp["o"], tp["n"]) for tp in touch_planes]
    on_plane = C.snap_vertices_to_planes(facets, planes, max(2.0 * tol_mm, 0.01)) if planes else {}
    for i, tp in enumerate(touch_planes):
        p = planar[tp["k"]]
        newp, nruns = C.conform_edges_to_facets(p["points"], tp["near"], on_plane.get(i, []),
                                                run_tol=touch_mm * 2, snap_tol=touch_mm * 2)
        if nruns:
            p["points"] = newp
            conform[tp["k"]] = nruns
    job.done("Classic: %d facets, %d plates re-edged" % (len(facets), len(conform)))
    return facets, conform


def collect_model(lib, settings, progress=None, job=None, confirm=None):
    """Read the AF members of the document and convert them to ALIEF FEAPRO plates / beams (mm).

    job     : Job (progress meter, Esc, timings) - made here when not given
    confirm : f(n_facets, suggested_facet_mm) -> bool, asked when the curved plating gives more facets than
              settings['facet_warn']; False cancels the export (raises Cancelled)."""
    own = job is None
    if own:
        job = Job(progress)
    st = dict(settings)
    notes = []
    try:
        while True:
            try:
                res = _collect(lib, st, job, confirm)
                break
            except Coarsen as ex:
                tries = st.get("_tries", 0) + 1
                shape = float(st.get("shell_tol", 2.0) or 2.0)
                if tries >= 2:              # the bends, not the facet size, set the count: loosen the shape too
                    shape = min(shape * 1.5, 25.0)
                note = ("%d facets are more than ALIEF FEAPRO opens comfortably (limit %d): trying facet size %g mm, shape "
                        "tolerance %g mm" % (ex.n, int(float(st.get("max_facets", 5000))), ex.facet, shape))
                notes.append(note)
                job.note(note)
                st.update(facet_size=ex.facet, shell_tol=shape, _tries=tries, _auto=True)
        res.messages = notes + res.messages
        res.facet_used = float(st.get("facet_size", 300.0))
        res.shape_used = float(st.get("shell_tol", 2.0))
        return res
    finally:
        if own:
            job.close()


def _collect(lib, settings, job, confirm):
    res = ExportResult()
    s = scale()
    t = tol()
    tol_mm = t * s
    chord_mm = float(settings.get("chord_tol", 1.0) or 1.0)
    chord_mu = chord_mm / s
    facet_mm = float(settings.get("facet_size", 300.0) or 300.0)
    shape_mm = max(float(settings.get("shell_tol", 2.0) or 2.0), 0.05)
    method = "Classic" if str(settings.get("curved_method", "Fast")).startswith("Classic") else "Fast"
    touch_mm = (max(2.0 * chord_mm, 2.5 * shape_mm + 0.5, 4.0 * tol_mm, 0.5) if method == "Fast"
                else max(2.0 * chord_mm, 4.0 * tol_mm, 0.5))
    min_area = float(settings.get("min_plate_area", 100.0) or 0.0)
    res.method = method
    res.scope = settings.get("export_scope", SCOPES[0]) or SCOPES[0]
    inscope = scope_filter(res.scope)
    reg = load_registry()
    mats, props, secs = C.library_index(lib)
    layer_cols = {}

    def group_of(obj):
        g = layer_group(obj)
        if g not in layer_cols:
            layer_cols[g] = hex_of(sc.doc.Layers[obj.Attributes.LayerIndex].Color)
        return g

    # ------------------------------------------------------------------ plates
    plate_objs = [o for o in af_objects("plate") if inscope(o)]
    job.stage("Reading %d plates" % len(plate_objs), len(plate_objs))
    planar, curved = [], []
    seen_uid = set()
    tiny = []
    lims = export_limits(settings)
    n_outside = n_clipped = 0
    for oi, obj in enumerate(plate_objs):
        job.tick(oi)
        faces = plate_faces(obj)
        uid = uid_of(obj, seen_uid)
        for fi, face in enumerate(faces):
            base = dict(obj=obj, face=face, fi=fi, guid=str(obj.Id), uid=uid, prop=af(obj, K_PROP), group=group_of(obj),
                        name=obj.Attributes.Name or "", mesh=float(af(obj, K_MESH, "0") or 0.0))
            if face.IsPlanar(t):
                outer, holes, n = planar_face_data(face, s, chord_mu, t)
                if not outer or len(outer) < 3:
                    res.messages.append("Plate %s: outline could not be read - skipped" % (base["name"] or base["guid"][:8]))
                    continue
                if lims:
                    was_cut = False
                    for axis, (lo, hi) in lims:
                        if outer:
                            outer, c = C.clip_polygon_slab(outer, axis, lo, hi)
                            was_cut = was_cut or c
                    if not outer:
                        n_outside += 1
                        continue
                    if was_cut:
                        n_clipped += 1
                        keep = []
                        for h in holes:
                            hp = [h["circle"][0]] if "circle" in h else h["pts"]
                            rad = 0.5 * h["circle"][1] if "circle" in h else 0.0
                            inside = all(lo + rad <= q[axis] <= hi - rad for axis, (lo, hi) in lims for q in hp)
                            outside = any(all(q[axis] > hi + rad for q in hp) or all(q[axis] < lo - rad for q in hp)
                                          for axis, (lo, hi) in lims)
                            if inside:
                                keep.append(h)
                            elif not outside:
                                res.messages.append("Plate %s: an opening crosses the export limit - left out (closed plate)"
                                                    % (base["name"] or base["guid"][:8]))
                        holes = keep
                if min_area > 0.0 and C.polygon_area3d(outer) < min_area:
                    tiny.append(base["guid"])
                    continue
                base.update(points=outer, holes=holes, n=n)
                planar.append(base)
            else:
                if lims:
                    try:
                        fb = face.GetBoundingBox(True)
                        blo, bhi = P2L(fb.Min, s), P2L(fb.Max, s)
                        if any(bhi[axis] < lo or blo[axis] > hi for axis, (lo, hi) in lims):
                            n_outside += 1
                            continue
                    except Exception:
                        pass
                curved.append(base)
    if tiny:
        res.n_skipped = len(tiny)
        res.messages.append("%d tiny plate face(s) smaller than %g mm2 skipped (e.g. hatch fills / slivers of a 2D drawing) - "
                            "first: %s" % (len(tiny), min_area, tiny[0]))
    job.done("Plates read: %d planar, %d curved faces%s" % (len(planar), len(curved),
                                                             (", %d tiny skipped" % len(tiny)) if tiny else ""))
    if lims:
        res.messages.append("Export limits %s: %d planar plates cut at the limit, %d outside left out"
                            % (limits_text(settings), n_clipped, n_outside))

    # ------------------------------------------------------------------ curved plating -> facets
    facets = []
    fm = None
    conform = {}
    if curved:
        res.n_curved = len(curved)
        if method == "Classic":
            facets, conform = _curved_classic(curved, planar, settings, s, t, job, res)
        else:
            facets, conform = _curved_fast(curved, planar, settings, s, t, job, confirm, res)
        res.n_facets = len(facets)
        job.stage("Facet index for the profiles")
        fm = C.FacetMesh(facets) if facets else None
        job.done("Curved plating: %d faces -> %d facets, %d plates re-edged on the shell"
                 % (len(curved), len(facets), len(conform)))

    # ------------------------------------------------------------------ plates out
    job.stage("Writing %d planar plates" % len(planar), len(planar))
    per_guid = {}
    for p in planar:
        per_guid[p["guid"]] = per_guid.get(p["guid"], 0) + 1
    for pi, p in enumerate(planar):
        job.tick(pi)
        P = C.flatten_polygon(C.simplify_polygon(p["points"]))
        fr = C.plate_frame(P)
        ops, outlines = [], []
        for h in p["holes"]:
            if "circle" in h:
                op = C.make_opening(None, fr, circle=h["circle"])
            else:
                op = C.make_opening([C.project_to_plane(q, fr) for q in h["pts"]], fr, max(chord_mm, 0.5))
            ops.append(op)
            outlines.append(C.opening_outline_global(op, fr, 24))
        pid = reg.get("%s:f%d" % (p["uid"], p["fi"]))
        nm = p["name"] or ("%s-%d" % (p["obj"].Attributes.GetUserString(K_ROLE) or "PL", pid))
        if per_guid.get(p["guid"], 0) > 1:
            nm = "%s-%d" % (nm, p["fi"] + 1)
        res.plates.append(dict(id=pid, name=nm, points=P, prop=p["prop"], openings=ops, mesh_size=p["mesh"],
                               group=p["group"], hole_outlines=outlines, nface=p["n"], src=p["guid"]))
    n_planar_out = len(res.plates)
    counter = {}
    for f in facets:
        c = curved[f["owner"]]
        k = counter.get(f["owner"], 0) + 1
        counter[f["owner"]] = k
        pid = reg.get("%s:f%d:t%d" % (c["uid"], c["fi"], k))
        nm = (c["name"] or ("%s-%d" % (c["obj"].Attributes.GetUserString(K_ROLE) or "Shell", reg.get("%s:f%d" % (c["uid"], c["fi"]))))) + "-F%d" % k
        res.plates.append(dict(id=pid, name=nm, points=f["pts"], prop=c["prop"], openings=[], mesh_size=c["mesh"],
                               group=c["group"], hole_outlines=[], nface=C.v_unit(C.newell_normal(f["pts"]), [0, 0, 1]),
                               src=c["guid"]))
    job.done("Plates: %d planar + %d facets" % (n_planar_out, len(facets)))

    # ------------------------------------------------------------------ profiles
    prof_objs = [o for o in af_objects("profile") if inscope(o)]
    job.stage("Profiles: %d" % len(prof_objs), len(prof_objs))
    pidx = PlanarIndex(res.plates[:n_planar_out], tol_mm * 4 + 0.01)
    step_mm = max(facet_mm / 4.0, 10.0)
    cut_ends = []
    for oi, obj in enumerate(prof_objs):
        job.tick(oi)
        crv = obj.Geometry
        if not isinstance(crv, rg.Curve):
            continue
        uid = uid_of(obj, seen_uid)
        sec = af(obj, K_SEC)
        side = af(obj, K_SIDE, "+N")
        orient_txt = af(obj, K_ORIENT)
        flange = int(float(af(obj, K_FLANGE, "1") or 1))
        offset = af(obj, K_OFFSET) or (C.default_offset(secs[sec]["stype"]) if sec in secs else "auto")
        name = obj.Attributes.Name or ("%s" % (obj.Attributes.GetUserString(K_ROLE) or "PRF"))
        group = group_of(obj)
        pieces = []
        on_curved = False
        if fm is not None:
            dp = [P2L(q, s) for q in dense_points(crv, step_mm / s)]
            runs = C.clip_polyline_slabs(dp, lims) if lims else [dp]
            flat = [q for run in runs for q in run]
            if flat:
                probe = [flat[0], flat[len(flat) // 2], flat[-1]]
                if any(fm.near(q, touch_mm)[0] is not None for q in probe):
                    hits = sum(1 for q in flat if fm.near(q, touch_mm)[0] is not None)
                    on_curved = hits >= 0.9 * len(flat)
            elif lims:
                continue                    # the whole profile is outside the export limits
            if on_curved:
                for run in runs:
                    for a, b, fi in C.merge_collinear_segments(C.walk_polyline(fm, run, eps=max(tol_mm * 2, 0.02), snap=min(2.0, facet_mm / 20.0))):
                        nf = fm.facets[fi]["n"]
                        pieces.append((a, b, side_vector(side, orient_txt, nf)))
        if not on_curved:
            pts = [P2L(q, s) for q in curve_points(crv, chord_mu, 0.0)]
            for j in range(len(pts) - 1):
                a, b = pts[j], pts[j + 1]
                if C.v_dist(a, b) < 1e-3:
                    continue
                host = pidx.host(a, b)
                if host is not None:
                    fr = host["fr"]
                    nrm = host.get("nface") or fr[3]
                    ov = side_vector(side, orient_txt, nrm)
                    for aa, bb in C.cut_out_holes(a, b, fr, host["holes_loc"]):
                        pieces.append((aa, bb, ov))
                else:
                    nrm = None
                    if fm is not None:
                        fi, g, dd = fm.near(C.v_lerp(a, b, 0.5), 2.0 * touch_mm)
                        if fi is not None:
                            nrm = fm.facets[fi]["n"]
                    ov = side_vector(side, orient_txt, nrm)
                    if ov is None:
                        ov = [0.0, 0.0, 1.0]
                        res.messages.append("Profile %s is not on a plate - web direction set to +Z (use a fixed axis)" % name)
                    pieces.append((a, b, ov))
        if lims:
            cut = []
            for a, b, ov in pieces:
                seg = (a, b)
                for axis, (lo, hi) in lims:
                    if seg is not None:
                        seg = C.clip_segment_slab(seg[0], seg[1], axis, lo, hi)
                if seg is not None and C.v_dist(seg[0], seg[1]) > 1e-3:
                    cut.append((seg[0], seg[1], ov))
                    for q, q0 in ((seg[0], a), (seg[1], b)):
                        if C.v_dist(q, q0) > 1e-6:
                            cut_ends.append(q)
            pieces = cut
        for k, (a, b, ov) in enumerate(pieces):
            if ov is None:
                ov = [0.0, 0.0, 1.0]
            bid = reg.get("%s:%d" % (uid, k))
            res.beams.append(dict(id=bid, name=name if len(pieces) == 1 else "%s-%d" % (name, k + 1), p1=a, p2=b,
                                  section=sec, orient=ov, flange_side=flange, offset_mode=offset, group=group))
    # a profile cut at an export limit ends on the new plate edge: give that edge a node there
    for q in cut_ends:
        for i in sorted(pidx.grid.query(q, q)):
            it = pidx.items[i]
            o, u, v, n = it["fr"]
            if abs(C.v_dot(C.v_sub(q, o), n)) > pidx.tol:
                continue
            P = it["points"]
            for k in range(len(P)):
                a, b = P[k], P[(k + 1) % len(P)]
                cp, tt = C.seg_closest3d(q, a, b)
                if C.v_dist(cp, q) <= max(2.0 * touch_mm, 0.05):
                    q[:] = cp               # the beam end (same list) moves onto the edge
                    if C.v_dist(cp, a) > 0.01 and C.v_dist(cp, b) > 0.01:
                        P.insert(k + 1, list(cp))
                    elif C.v_dist(cp, a) <= 0.01:
                        q[:] = a
                    else:
                        q[:] = b
                    break
            else:
                continue
            break
    job.done("Profiles: %d curves -> %d beam pieces" % (len(prof_objs), len(res.beams)))
    res.layers = [dict(name=g, color=c) for g, c in sorted(layer_cols.items())]
    if res.scope == SCOPES[0] and not lims:
        reg.prune()          # a partial export keeps the ids of the members left out
    save_registry(reg)
    used_p = set(p["prop"] for p in res.plates)
    used_s = set(b["section"] for b in res.beams)
    for m in C.library_autofix(lib, used_p, used_s):
        res.messages.append(m)
    missing = sorted([x for x in used_p if x not in C.library_index(lib)[1]]) + sorted([x for x in used_s if x not in C.library_index(lib)[2]])
    for x in missing:
        res.messages.append("NOT IN LIBRARY: '%s' - add it in the panel before analysing in ALIEF FEAPRO" % x)
    return res


# =========================================================================== check / take-off
def gather_for_check(lib, settings):
    s = scale()
    t = tol()
    chord_mu = float(settings.get("chord_tol", 1.0)) / s
    plates, beams, planar_items = [], [], []
    curved_breps = []
    for obj in af_objects("plate"):
        for fi, face in enumerate(plate_faces(obj)):
            nm = obj.Attributes.Name or "%s %s" % (af(obj, K_ROLE, "Plate"), str(obj.Id)[:6])
            if face.IsPlanar(t):
                outer, holes, n = planar_face_data(face, s, chord_mu, t)
                plates.append(dict(key=str(obj.Id), name=nm, points=outer or [], prop=af(obj, K_PROP), curved=False))
                if outer:
                    planar_items.append(dict(points=outer))
            else:
                plates.append(dict(key=str(obj.Id), name=nm, points=[], prop=af(obj, K_PROP), curved=True))
                b = face.DuplicateFace(False)
                bb = b.GetBoundingBox(True)
                curved_breps.append((b, bb))
    pidx = PlanarIndex(planar_items, t * s * 4 + 0.01)
    for obj in af_objects("profile"):
        crv = obj.Geometry
        if not isinstance(crv, rg.Curve):
            continue
        pts = [P2L(q, s) for q in curve_points(crv, chord_mu)]
        host = False
        for j in range(len(pts) - 1):
            if pidx.host(pts[j], pts[j + 1]) is not None:
                host = True
                break
        if not host:
            mid = crv.PointAt(crv.Domain.Mid)
            lim = max(2 * float(settings.get("chord_tol", 1.0)), float(settings.get("shell_tol", 2.0)) * 2.5 + 0.5, 0.5)
            for b, bb in curved_breps:
                if bb.ClosestPoint(mid).DistanceTo(mid) * s > lim:
                    continue
                if b.ClosestPoint(mid).DistanceTo(mid) * s <= lim:
                    host = True
                    break
        beams.append(dict(key=str(obj.Id), name=obj.Attributes.Name or "%s %s" % (af(obj, K_ROLE, "Profile"), str(obj.Id)[:6]),
                          points=pts, section=af(obj, K_SEC), host=host))
    return plates, beams


def export_preflight(lib, settings):
    """Things that make an export slow or useless, for AF_Check: tiny plates (hatch fills of a 2D drawing),
    very dense curved surfaces, curved plating that will give many facets."""
    s = scale()
    t = tol()
    chord_mu = float(settings.get("chord_tol", 1.0)) / s
    min_area = float(settings.get("min_plate_area", 100.0) or 0.0)
    facet = float(settings.get("facet_size", 300.0) or 300.0)
    out = []
    tiny, dense, area_c = [], [], 0.0
    for obj in af_objects("plate"):
        for face in plate_faces(obj):
            if face.IsPlanar(t):
                if min_area > 0.0:
                    outer, holes, n = planar_face_data(face, s, chord_mu, t)
                    if outer and C.polygon_area3d(outer) < min_area:
                        tiny.append(str(obj.Id))
            else:
                try:
                    ns = face.ToNurbsSurface()
                    ncp = ns.Points.CountU * ns.Points.CountV
                    if ncp > 2500:
                        dense.append((str(obj.Id), ns.Points.CountU, ns.Points.CountV))
                except Exception:
                    pass
                try:
                    amp = rg.AreaMassProperties.Compute(face.DuplicateFace(False))
                    if amp is not None:
                        area_c += amp.Area * s * s
                except Exception:
                    pass
    if tiny:
        out.append(("WARNING", "%d tiny plate(s) smaller than %g mm2 (hatch fills / slivers of a 2D drawing?) - AF_Export "
                    "leaves them out; better remove their AF tags" % (len(tiny), min_area), tiny[:200]))
    for oid, nu, nv in dense:
        out.append(("INFO", "Dense curved surface (%d x %d control points) - AF_Export meshes a light copy of it" % (nu, nv), [oid]))
    if area_c > 0.0:
        est = C.estimate_facets(area_c, facet)
        lvl = "WARNING" if est > int(float(settings.get("max_facets", 5000) or 5000)) else "INFO"
        out.append((lvl, "Curved plating %.1f m2 -> about %d facets at facet size %g mm (each one a plate in ALIEF FEAPRO)%s"
                    % (area_c * 1e-6, est, facet, " - use a larger facet size or export part of the model (Export: Selected / "
                       "Visible members only)" if lvl == "WARNING" else ""), []))
    return out


def takeoff(lib):
    s = scale()
    plates, beams = [], []
    for obj in af_objects("plate"):
        b = brep_of(obj.Geometry)
        if b is None:
            continue
        amp = rg.AreaMassProperties.Compute(b)
        plates.append(dict(prop=af(obj, K_PROP), area=(amp.Area if amp else 0.0) * s * s))
    for obj in af_objects("profile"):
        if isinstance(obj.Geometry, rg.Curve):
            beams.append(dict(section=af(obj, K_SEC), length=obj.Geometry.GetLength() * s))
    return C.material_takeoff(plates, beams, lib)


# =========================================================================== 3D solids (profiles / preview)
SOLID_LAYER = "ALIEF_FEA_3D"
K_SRC = "AF_SRC"


def _all_objects():
    st = Rhino.DocObjects.ObjectEnumeratorSettings()
    st.HiddenObjects = True
    st.LockedObjects = True
    st.DeletedObjects = False
    st.IncludeLights = False
    st.IncludeGrips = False
    return list(sc.doc.Objects.GetObjectList(st))


def member_obj(oid):
    """The FEA member behind an id: a 3D profile / preview solid resolves to its source curve / plate."""
    obj = find(oid)
    if obj is None:
        return None
    if obj.Attributes.GetUserString(K_PREVIEW):
        src = obj.Attributes.GetUserString(K_SRC)
        return find(src) if src else None
    return obj


def delete_objects(objs):
    """Delete objects even when they (or their layer) are locked or hidden. Returns the number deleted."""
    n = 0
    for o in objs:
        if o is None:
            continue
        ok = False
        try:
            ok = bool(sc.doc.Objects.Delete(o, True, True))
        except Exception:
            try:
                sc.doc.Objects.Unlock(o.Id, True)
                ok = bool(sc.doc.Objects.Delete(o.Id, True))
            except Exception:
                ok = False
        if ok:
            n += 1
    return n


def _delete_ids(ids):
    delete_objects([find(i) for i in ids])


def delete_profile_solids(src_ids=None):
    """Delete the 3D profiles of the given source curves (None = all, plus orphans)."""
    want = None if src_ids is None else set(str(x) for x in src_ids)
    dead = []
    for obj in _all_objects():
        if obj.Attributes.GetUserString(K_PREVIEW) != "profile":
            continue
        src = obj.Attributes.GetUserString(K_SRC) or ""
        if want is None or src in want or find(src) is None:
            dead.append(obj.Id)
    _delete_ids(dead)
    return len(dead)


def clear_preview():
    """Delete all preview solids (plate thickness and 3D profiles)."""
    if rs.IsLayer(PREVIEW_LAYER):
        rs.LayerLocked(PREVIEW_LAYER, False)
    ids = [o.Id for o in _all_objects() if o.Attributes.GetUserString(K_PREVIEW)]
    _delete_ids(ids)
    return len(ids)


def _display_hosts(settings):
    """Planar AF plates (index, mm) and curved AF plate faces for orienting / offsetting profiles."""
    s = scale()
    t = tol()
    chord_mu = float(settings.get("chord_tol", 1.0) or 1.0) / s
    planar, curved = [], []
    for obj in af_objects("plate"):
        for face in plate_faces(obj):
            if face.IsPlanar(t):
                outer, holes, n = planar_face_data(face, s, chord_mu, t)
                if not outer or len(outer) < 3:
                    continue
                fr = C.plate_frame(outer)
                outl = []
                for h in holes:
                    if "circle" in h:
                        outl.append(C.opening_outline_global(C.make_opening(None, fr, circle=h["circle"]), fr, 24))
                    else:
                        outl.append(h["pts"])
                planar.append(dict(points=outer, prop=af(obj, K_PROP), nface=n, hole_outlines=outl))
            else:
                curved.append((face, face.DuplicateFace(False), af(obj, K_PROP)))
    return PlanarIndex(planar, t * s * 4 + 0.01), curved


def _thk(lib, prop):
    pp = C.library_index(lib)[1].get(prop)
    return pp["thickness"] if pp else 0.0


def profile_pieces(obj, hosts, lib, settings):
    """Straight pieces (a, b, web direction, plate thickness) of a profile curve, mm."""
    s = scale()
    pidx, curved = hosts
    crv = obj.Geometry
    if not isinstance(crv, rg.Curve):
        return []
    side = af(obj, K_SIDE, "+N")
    otxt = af(obj, K_ORIENT)
    chord_mm = float(settings.get("chord_tol", 1.0) or 1.0)
    touch_mm = max(2.0 * chord_mm, 0.5)
    pieces = []
    on_curved = None
    if curved:
        mid = crv.PointAt(crv.Domain.Mid)
        for face, fb, prop in curved:
            if fb.ClosestPoint(mid).DistanceTo(mid) * s <= touch_mm:
                on_curved = (face, fb, prop)
                break
    if on_curved is not None:
        face, fb, prop = on_curved
        step = max(min(float(settings.get("facet_size", 300.0)) / 4.0, 150.0), 10.0) / s
        pts = dense_points(crv, step)
        tp = _thk(lib, prop)
        for j in range(len(pts) - 1):
            m = rg.Point3d((pts[j].X + pts[j + 1].X) / 2, (pts[j].Y + pts[j + 1].Y) / 2, (pts[j].Z + pts[j + 1].Z) / 2)
            n = face_normal(face, fb.ClosestPoint(m))
            pieces.append((P2L(pts[j], s), P2L(pts[j + 1], s), side_vector(side, otxt, n) or [0, 0, 1], tp))
        return pieces
    pts = [P2L(q, s) for q in curve_points(crv, float(settings.get("chord_tol", 1.0) or 1.0) / s, 0.0)]
    for j in range(len(pts) - 1):
        a, b = pts[j], pts[j + 1]
        if C.v_dist(a, b) < 1e-3:
            continue
        host = pidx.host(a, b)
        if host is not None:
            ov = side_vector(side, otxt, host.get("nface") or host["fr"][3]) or [0, 0, 1]
            tp = _thk(lib, host["prop"]) if abs(C.v_dot(host["fr"][3], C.v_unit(ov))) > 0.9 else 0.0
            for aa, bb in C.cut_out_holes(a, b, host["fr"], host["holes_loc"]):
                pieces.append((aa, bb, ov, tp))
        else:
            pieces.append((a, b, side_vector(side, otxt, None) or [0, 0, 1], 0.0))
    return pieces


def section_solids(sec, a, b, orient, flange, offset, tp, s=None, t=None):
    """Breps (model units) of a profile section swept straight from a to b (mm), ALIEF FEAPRO axes and
    offsets: auto = toe on the plate face (t/2 from the mid-plane), centroid = centroid on the line."""
    s = scale() if s is None else s
    t = tol() if t is None else t
    ex = C.v_unit(C.v_sub(b, a))
    ez = C.v_sub(orient, C.v_mul(ex, C.v_dot(orient, ex)))
    ez = C.v_unit(ez, [0, 0, 1] if abs(ex[2]) < 0.9 else [1, 0, 0])
    ey = C.v_mul(C.v_cross(ez, ex), 1.0 if flange >= 0 else -1.0)
    d = sec["dims"]
    if offset == "auto":
        shift = C.v_mul(ez, tp / 2.0)
    else:
        # ALIEF FEAPRO: every mode other than 'auto' has no offset - the beam axis (centroid) is on the line
        pr = C.section_properties(sec["stype"], d)
        shift = C.v_add(C.v_mul(ez, -pr["zc"]), C.v_mul(ey, -pr.get("yc", 0.0)))
    o = C.v_add(a, shift)

    def W(y, z):
        return L2P(C.v_add(C.v_add(o, C.v_mul(ey, y)), C.v_mul(ez, z)), s)
    path = rg.LineCurve(L2P(o, s), L2P(C.v_add(o, C.v_sub(b, a)), s))
    out = []
    for sh in C.section_shapes(sec["stype"], d):
        if sh[0] == "R":
            _, y0, z0, w, h = sh
            q = [W(y0, z0), W(y0 + w, z0), W(y0 + w, z0 + h), W(y0, z0 + h)]
            crvs = [rg.PolylineCurve(q + [q[0]])]
        else:
            _, yc, zc, ro, ri = sh
            pl = rg.Plane(W(yc, zc), V(ey), V(ez))
            crvs = [rg.ArcCurve(rg.Circle(pl, ro / s))]
            if ri > 0:
                crvs.append(rg.ArcCurve(rg.Circle(pl, ri / s)))
        faces = rg.Brep.CreatePlanarBreps(crvs, t)
        if not faces:
            continue
        for fb in faces:
            solid = fb.Faces[0].CreateExtrusion(path, True)
            if solid is not None:
                out.append(solid)
    return out


def _add_solid(geo, lay, color, kind, src, name=""):
    attr = Rhino.DocObjects.ObjectAttributes()
    attr.LayerIndex = lay
    attr.ColorSource = Rhino.DocObjects.ObjectColorSource.ColorFromObject
    attr.ObjectColor = sys_color(color)
    attr.SetUserString(K_PREVIEW, kind)
    attr.SetUserString(K_SRC, str(src))
    if name:
        attr.Name = name
    g = sc.doc.Objects.AddBrep(geo, attr)
    return 1 if g != System.Guid.Empty else 0


def build_profile_solids(lib, settings, objs=None):
    """Create / refresh the 3D profiles of the given profile objects (None = all profiles)."""
    if not settings.get("show_3d", True):
        return 0
    if objs is None:
        targets = af_objects("profile")
        delete_profile_solids(None)
    else:
        targets = [o for o in objs if o is not None and is_profile(o)]
        delete_profile_solids([o.Id for o in targets])
    if not targets:
        return 0
    s = scale()
    t = tol()
    secs = C.library_index(lib)[2]
    hosts = _display_hosts(settings)
    lay = ensure_layer(SOLID_LAYER, "#C9A227")
    made = 0
    for obj in targets:
        sec = secs.get(af(obj, K_SEC))
        if sec is None:
            continue
        flange = int(float(af(obj, K_FLANGE, "1") or 1))
        offset = af(obj, K_OFFSET) or C.default_offset(sec["stype"])
        col = section_color(lib, sec["name"])
        for a, b, ov, tp in profile_pieces(obj, hosts, lib, settings):
            for br in section_solids(sec, a, b, ov, flange, offset, tp, s, t):
                made += _add_solid(br, lay, col, "profile", obj.Id, sec["name"])
    sc.doc.Views.Redraw()
    return made


def build_preview(lib, settings):
    """3D preview: plate thickness solids (locked layer) + 3D profiles of all profiles."""
    clear_preview()
    s = scale()
    t = tol()
    props = C.library_index(lib)[1]
    lay = ensure_layer(PREVIEW_LAYER, "#9E9E9E")
    made = 0
    res = collect_model(lib, settings)
    for p in res.plates:
        pp = props.get(p["prop"])
        th = pp["thickness"] if pp else 10.0
        P = [L2P(q, s) for q in p["points"]]
        crvs = [rg.PolylineCurve(P + [P[0]])]
        for h in p.get("hole_outlines", []):
            H = [L2P(q, s) for q in h]
            crvs.append(rg.PolylineCurve(H + [H[0]]))
        breps = rg.Brep.CreatePlanarBreps(crvs, t)
        if not breps:
            continue
        n = C.plate_frame(p["points"])[3]
        start = C.v_sub(p["points"][0], C.v_mul(n, th / 2.0))
        path = rg.LineCurve(L2P(start, s), L2P(C.v_add(start, C.v_mul(n, th)), s))
        for b in breps:
            b.Translate(V(C.v_mul(n, -0.5 * th / s)))
            solid = b.Faces[0].CreateExtrusion(path, True)
            if solid is not None:
                made += _add_solid(solid, lay, plate_color(lib, p["prop"]), "plate", p.get("src", ""), p["name"])
    rs.LayerLocked(PREVIEW_LAYER, True)
    st = dict(settings, show_3d=True)
    made += build_profile_solids(lib, st, None)
    sc.doc.Views.Redraw()
    return made


# =========================================================================== import
def import_project(path, settings):
    d = C.read_project(path)
    lib = load_library()
    plib = C.project_library(d)
    for key in ("materials", "plate_props", "sections"):
        names = set(x["name"] for x in plib[key])
        lib[key] = [x for x in lib[key] if x["name"] not in names] + plib[key]
    save_library(lib)
    s = scale()
    t = tol()
    layers = {l.get("name"): l.get("color", "#7FA7C9") for l in d.get("layers", []) if isinstance(l, dict)}
    n_pl = n_bm = 0
    for p in d.get("plates", []):
        P, holes = C.project_plate_outlines(p, 16)
        if len(P) < 3:
            continue
        lay = ensure_layer(_layer_path(p.get("group", "Default")), layers.get(p.get("group")))
        crvs = [rg.PolylineCurve([L2P(q, s) for q in P] + [L2P(P[0], s)])]
        fr = C.plate_frame(P)
        for op, H in zip(p.get("openings", []), holes):
            if op.get("kind") == "circle":
                pl = rg.Plane(L2P(op["center"], s), V(fr[1]), V(fr[2]))
                crvs.append(rg.ArcCurve(rg.Circle(pl, op["a"] / 2.0 / s)))
            elif len(H) >= 3:
                crvs.append(rg.PolylineCurve([L2P(q, s) for q in H] + [L2P(H[0], s)]))
        breps = rg.Brep.CreatePlanarBreps(crvs, t)
        if not breps:
            continue
        for b in breps:
            add_plate(b, p.get("prop", ""), lib, settings, name=p.get("name", ""), role="Plate", layer_index=lay,
                      mesh_size=float(p.get("mesh_size", 0.0) or 0.0))
            n_pl += 1
    for b in d.get("beams", []):
        lay = ensure_layer(_layer_path(b.get("group", "Default")), layers.get(b.get("group")))
        gid = add_curve(rg.LineCurve(L2P(b["p1"], s), L2P(b["p2"], s)), lay, b.get("name", ""))
        if gid != System.Guid.Empty:
            tag_profile(gid, lib, b.get("section", ""), side="V", flange=int(b.get("flange_side", 1)),
                        offset=b.get("offset_mode", "auto"), orient=b.get("orient", [0, 0, 1]), name=b.get("name", ""))
            n_bm += 1
    n_cad = 0
    for c in d.get("cad", []):
        if c.get("tri_points") and c.get("tri_faces"):
            m = rg.Mesh()
            for q in c["tri_points"]:
                m.Vertices.Add(L2P(q, s))
            for f in c["tri_faces"]:
                m.Faces.AddFace(int(f[0]), int(f[1]), int(f[2]))
            m.Normals.ComputeNormals()
            lay = ensure_layer(_layer_path("FEAPRO CAD surfaces"), "#90A4AE")
            attr = Rhino.DocObjects.ObjectAttributes()
            attr.LayerIndex = lay
            attr.Name = c.get("name", "")
            sc.doc.Objects.AddMesh(m, attr)
            n_cad += 1
    sc.doc.Views.Redraw()
    return n_pl, n_bm, n_cad, d


def _layer_path(group):
    g = (group or "Default").replace(" / ", "::").replace("/", "::")
    return g if g.strip(":") else "Default"
