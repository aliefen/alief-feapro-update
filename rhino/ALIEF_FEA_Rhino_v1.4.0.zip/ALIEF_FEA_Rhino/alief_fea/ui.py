"""Eto user interface of ALIEF FEA MODELER: parameter dialogs, report dialog and the main panel."""
import csv
import json
import os
import textwrap

import Rhino
import Rhino.UI
import scriptcontext as sc
import Eto.Forms as forms
import Eto.Drawing as drawing

from . import core as C

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
STICKY = "ALIEF_FEA_PANEL"


def img(name):
    return os.path.join(HERE, "img", name + ".png")


def icon(name):
    return os.path.join(HERE, "icons", name + ".png")


def bitmap(path):
    try:
        return drawing.Bitmap(path) if path and os.path.exists(path) else None
    except Exception:
        return None


def owner():
    return Rhino.UI.RhinoEtoApp.MainWindow


def message(text, title=C.APP):
    Rhino.UI.Dialogs.ShowMessage(text, title)


def confirm(text, title=C.APP):
    """Yes / No question. Returns True for Yes."""
    try:
        import rhinoscriptsyntax as rs
        return rs.MessageBox(text, 4 | 32, title) == 6
    except Exception:
        try:
            r = forms.MessageBox.Show(text, title, forms.MessageBoxButtons.YesNo, forms.MessageBoxType.Question)
            return r == forms.DialogResult.Yes
        except Exception:
            return True


def wrap_text(text, chars=64):
    """Explicit line breaks: Eto measures auto-wrapped labels as one line, which squashes the rows below."""
    out = []
    for para in str(text).split("\n"):
        out.extend(textwrap.wrap(para, chars) or [""])
    return "\n".join(out)


def label(text, bold=False, size=None, wrap=False, chars=64):
    lb = forms.Label()
    lb.Text = wrap_text(text, chars) if wrap else text
    if bold:
        lb.Font = drawing.Font("Segoe UI", size or 9, drawing.FontStyle.Bold)
    elif size:
        lb.Font = drawing.Font("Segoe UI", size)
    lb.VerticalAlignment = forms.VerticalAlignment.Center
    return lb


def button(text, handler=None, icon_name=None, tip=None, above=False):
    b = forms.Button()
    b.Text = text
    bmp = bitmap(icon(icon_name)) if icon_name else None
    if bmp is not None:
        b.Image = bmp
        b.ImagePosition = forms.ButtonImagePosition.Above if above else forms.ButtonImagePosition.Left
    if tip:
        b.ToolTip = tip
    if handler is not None:
        b.Click += handler
    return b


def textbox(value="", width=None):
    t = forms.TextBox()
    t.Text = value if isinstance(value, str) else ("%g" % value)
    if width:
        t.Width = width
    return t


def dropdown(items, current=None, labels=None):
    d = forms.DropDown()
    for it in items:
        d.Items.Add(str(labels.get(it, it)) if labels else str(it))
    if current in items:
        d.SelectedIndex = list(items).index(current)
    elif items:
        d.SelectedIndex = 0
    return d


def row(*cells):
    r = forms.TableRow()
    for c in cells:
        if c is None:
            sp = forms.TableCell()
            sp.ScaleWidth = True
            r.Cells.Add(sp)
        elif isinstance(c, forms.TableCell):
            r.Cells.Add(c)
        else:
            r.Cells.Add(forms.TableCell(c))
    return r


def table(rows, spacing=6, padding=0):
    t = forms.TableLayout()
    t.Spacing = drawing.Size(spacing, spacing)
    t.Padding = drawing.Padding(padding)
    for r in rows:
        t.Rows.Add(r)
    return t


def form_grid(pairs, spacing=6):
    """Two-column label / control grid; the control column stretches."""
    t = forms.TableLayout()
    t.Spacing = drawing.Size(spacing, spacing)
    for lab, ctl in pairs:
        r = forms.TableRow()
        r.Cells.Add(forms.TableCell(label(lab) if isinstance(lab, str) else lab))
        r.Cells.Add(forms.TableCell(ctl, True))
        t.Rows.Add(r)
    return t


def add_scaled(lay, ctl):
    """Add a control that takes the remaining height of a DynamicLayout."""
    try:
        lay.Add(ctl, False, True)
    except Exception:
        lay.Add(ctl)


def to_float(text, default=None):
    try:
        return float(str(text).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default


# =========================================================================== parameter dialog
def _preselected(pick):
    """Objects already selected in Rhino that the dialog's Select button would accept."""
    import rhinoscriptsyntax as rs
    out = []
    flt = pick.get("filter", 0) or 0
    cf = pick.get("custom_filter")
    for i in rs.SelectedObjects() or []:
        try:
            if flt and not (rs.ObjectType(i) & flt):
                continue
            if cf is not None:
                o = sc.doc.Objects.FindId(i)
                if o is None or not cf(o, o.Geometry, None):
                    continue
            out.append(i)
        except Exception:
            continue
    return out


def ask(title, fields, image=None, intro=None, ok_text="OK", width=440, pick=None):
    """Modal parameter dialog.
    fields: dict(key, label, kind=float|int|text|choice|bool|multiline|savefile, value, choices, labels,
                 images={choice: image}, min, tip, filter=(name, ext) for savefile)
    pick:   dict(button, prompt, filter, custom_filter, what) - adds a 'Select ...' button: the dialog steps aside
            while the objects are picked in Rhino and comes back with the values kept; the main button becomes
            'Assign'. Objects selected before the command are taken over. The result has '_ids'.
    Returns dict of values, or None when cancelled."""
    import rhinoscriptsyntax as rs
    fields = [dict(f) for f in fields]
    ids = _preselected(pick) if pick else []
    if pick and ok_text == "OK":
        ok_text = "Assign"
    while True:
        res = _ask_once(title, fields, image, intro, ok_text, width, pick, ids)
        if res is None:
            return None
        if res.pop("__pick__", False):
            raw = res.pop("__raw__", {})
            for f in fields:
                if f["key"] in raw:
                    f["value"] = raw[f["key"]]
            got = rs.GetObjects(pick.get("prompt", "Select objects"), pick.get("filter", 0) or 0, preselect=True, select=True,
                                custom_filter=pick.get("custom_filter"))
            if got:
                ids = list(got)
            continue
        res["_ids"] = list(ids)
        return res


def _ask_once(title, fields, image, intro, ok_text, width, pick, ids):
    dlg = forms.Dialog()
    dlg.Title = title
    dlg.Padding = drawing.Padding(12)
    dlg.Resizable = True
    lay = forms.DynamicLayout()
    lay.Spacing = drawing.Size(6, 8)
    est_h = 24
    img_w = 0
    if intro:
        txt = wrap_text(intro, 74)
        lb = label(txt)
        lay.AddRow(lb)
        est_h += 17 * (txt.count("\n") + 1) + 8
    view = None
    if image:
        bmp = bitmap(img(image))
        if bmp is not None:
            view = forms.ImageView()
            view.Image = bmp
            try:
                img_w, img_h = int(bmp.Width), int(bmp.Height)
            except Exception:
                img_w, img_h = 0, 0
            if img_w <= 0 or img_h <= 0:
                img_w, img_h = 460, 250
            view.Size = drawing.Size(img_w, img_h)
            lay.AddRow(view)
            est_h += img_h + 8
    controls = []
    pairs = []
    for f in fields:
        kind = f.get("kind", "float")
        val = f.get("value", "")
        cell = None
        if kind == "choice":
            ch = list(f["choices"])
            c = dropdown(ch, val, f.get("labels"))
            if f.get("images") and view is not None:
                def on_change(sender, e, f=f, c=c):
                    k = list(f["choices"])[c.SelectedIndex] if c.SelectedIndex >= 0 else None
                    b = bitmap(img(f["images"].get(k, ""))) if k in f["images"] else None
                    if b is not None:
                        view.Image = b
                c.SelectedIndexChanged += on_change
                on_change(None, None)
            est_h += 32
        elif kind == "bool":
            c = forms.CheckBox()
            c.Checked = bool(val)
            c.Text = f.get("text", "")
            est_h += 28
        elif kind == "multiline":
            c = forms.TextArea()
            c.Text = str(val)
            c.Size = drawing.Size(240, 70)
            est_h += 78
        else:
            c = textbox(val if isinstance(val, str) else ("%g" % val if val != "" else ""))
            est_h += 32
            if kind == "savefile":
                def browse(sender, e, c=c, f=f):
                    d = forms.SaveFileDialog()
                    d.Title = f["label"]
                    nm, ext = f.get("filter", ("File", ".*"))
                    try:
                        d.Filters.Add(forms.FileFilter(nm, ext))
                    except Exception:
                        pass
                    if c.Text:
                        d.FileName = c.Text
                    if d.ShowDialog(dlg) == forms.DialogResult.Ok and d.FileName:
                        fn = d.FileName
                        if ext != ".*" and not fn.lower().endswith(ext):
                            fn += ext
                        c.Text = fn
                bb = button("...", browse, None, "Choose the folder and file name")
                bb.Size = drawing.Size(34, 24)
                cell = table([row(forms.TableCell(c, True), bb)], spacing=4)
        if f.get("tip"):
            c.ToolTip = f["tip"]
        controls.append((f, kind, c))
        pairs.append((f["label"], cell if cell is not None else c))
    lay.AddRow(form_grid(pairs))
    result = {}

    def raw_values():
        vals = {}
        for f, kind, c in controls:
            if kind == "choice":
                ch = list(f["choices"])
                vals[f["key"]] = ch[c.SelectedIndex] if c.SelectedIndex >= 0 and ch else (ch[0] if ch else "")
            elif kind == "bool":
                vals[f["key"]] = bool(c.Checked)
            else:
                vals[f["key"]] = c.Text
        return vals

    if pick:
        what = pick.get("what", "object(s)")
        n_lab = label("%d %s selected" % (len(ids), what) if ids else "nothing selected yet - %s" % pick.get("hint", "press the button"))
        if ids:
            n_lab.TextColor = drawing.Color.FromArgb(19, 121, 91)

        def on_pick(sender, e):
            result["__pick__"] = True
            result["__raw__"] = raw_values()
            dlg.Close()
        pb = button(pick.get("button", "Select objects"), on_pick, pick.get("icon"), pick.get("prompt"))
        pb.Size = drawing.Size(170, 30)
        lay.AddRow(table([row(pb, n_lab, None)]))
        est_h += 40

    def on_ok(sender, e):
        vals = {}
        for f, kind, c in controls:
            if kind in ("float", "int"):
                v = to_float(c.Text)
                if v is None:
                    message("'%s' must be a number." % f["label"], title)
                    return
                if "min" in f and v < f["min"]:
                    message("'%s' must be at least %g." % (f["label"], f["min"]), title)
                    return
                vals[f["key"]] = int(round(v)) if kind == "int" else v
            elif kind == "choice":
                ch = list(f["choices"])
                vals[f["key"]] = ch[c.SelectedIndex] if c.SelectedIndex >= 0 and ch else (ch[0] if ch else "")
            elif kind == "bool":
                vals[f["key"]] = bool(c.Checked)
            else:
                vals[f["key"]] = c.Text
        result.update(vals)
        result["__ok__"] = True
        dlg.Close()

    ok = button(ok_text, on_ok)
    cancel = button("Cancel", lambda s, e: dlg.Close())
    for b_ in (ok, cancel):
        b_.Size = drawing.Size(110, 30)
    add_scaled(lay, forms.Panel())          # spare height goes here, not into the buttons
    lay.AddRow(table([row(None, ok, cancel)]))
    est_h += 30 + 40
    dlg.Content = lay
    dlg.DefaultButton = ok
    dlg.AbortButton = cancel
    try:
        dlg.ClientSize = drawing.Size(max(width, img_w) + 24, est_h)
        dlg.MinimumSize = drawing.Size(max(width, img_w) + 24, est_h)
    except Exception:
        pass
    dlg.ShowModal(owner())
    if result.pop("__pick__", False):
        return {"__pick__": True, "__raw__": result.get("__raw__", {})}
    if result.pop("__ok__", False):
        return result
    return None


# =========================================================================== report dialog
def report(title, text, items=None, on_select=None, on_save=None, width=640, height=420):
    dlg = forms.Dialog()
    dlg.Title = title
    dlg.Padding = drawing.Padding(10)
    dlg.Resizable = True
    dlg.ClientSize = drawing.Size(width, height)
    lay = forms.DynamicLayout()
    lay.Spacing = drawing.Size(6, 6)
    ta = forms.TextArea()
    ta.ReadOnly = True
    ta.Text = text
    try:
        ta.Font = drawing.Font(drawing.FontFamilies.Monospace, 9)
    except Exception:
        pass
    lst = None
    if items:
        lst = forms.ListBox()
        for it in items:
            lst.Items.Add(it)
        lst.Height = 170
        lay.AddRow(label("Double-click an item (or press 'Select objects') to select the members in Rhino:"))
        lay.AddRow(lst)
    add_scaled(lay, ta)
    btns = [None]
    if items and on_select:
        def sel(sender, e):
            if lst.SelectedIndex >= 0:
                on_select(lst.SelectedIndex)
        btns.append(button("Select objects", sel))
        lst.MouseDoubleClick += sel
    if on_save:
        btns.append(button("Save CSV...", lambda s, e: on_save()))
    close = button("Close", lambda s, e: dlg.Close())
    btns.append(close)
    lay.AddRow(table([row(*btns)]))
    dlg.Content = lay
    dlg.AbortButton = close
    dlg.ShowModal(owner())


# =========================================================================== section sketch
def draw_section(g, w, h, sec_type, dims, color=(19, 121, 91)):
    g.FillRectangle(drawing.Colors.White, 0, 0, w, h)
    err = C.check_dims(sec_type, dims)
    if err:
        g.DrawText(drawing.Font("Segoe UI", 8), drawing.Colors.Firebrick, 6, 6, err)
        return
    shapes = C.section_shapes(sec_type, dims)
    ys, zs = [], []
    for sh in shapes:
        if sh[0] == "R":
            ys += [sh[1], sh[1] + sh[3]]
            zs += [sh[2], sh[2] + sh[4]]
        else:
            ys += [sh[1] - sh[3], sh[1] + sh[3]]
            zs += [sh[2] - sh[3], sh[2] + sh[3]]
    ymin, ymax, zmin, zmax = min(ys), max(ys), min(zs + [0.0]), max(zs)
    span = max(ymax - ymin, zmax - zmin, 1.0)
    sc_ = min((w - 40) / max(ymax - ymin, 1e-6), (h - 40) / max(zmax - zmin, 1e-6), (min(w, h) - 40) / span * 1.6)
    ox = w / 2.0 - (ymin + ymax) / 2.0 * sc_
    oy = h - 22.0 + zmin * sc_

    def X(y):
        return ox + y * sc_

    def Y(z):
        return oy - z * sc_
    fill = drawing.Color.FromArgb(color[0], color[1], color[2], 255)
    edge = drawing.Color.FromArgb(11, 61, 46, 255)
    for sh in shapes:
        if sh[0] == "R":
            _, y0, z0, ww, hh = sh
            g.FillRectangle(fill, X(y0), Y(z0 + hh), ww * sc_, hh * sc_)
            g.DrawRectangle(edge, X(y0), Y(z0 + hh), ww * sc_, hh * sc_)
        else:
            _, yc, zc, ro, ri = sh
            g.FillEllipse(fill, X(yc - ro), Y(zc + ro), 2 * ro * sc_, 2 * ro * sc_)
            if ri > 0:
                g.FillEllipse(drawing.Colors.White, X(yc - ri), Y(zc + ri), 2 * ri * sc_, 2 * ri * sc_)
    gold = drawing.Color.FromArgb(201, 162, 39, 255)
    g.FillRectangle(gold, 6, Y(0), w - 12, 3)
    g.DrawText(drawing.Font("Segoe UI", 7), drawing.Color.FromArgb(120, 100, 20, 255), 8, Y(0) + 4, "plating (toe, z = 0)")
    p = C.section_properties(sec_type, dims)
    red = drawing.Colors.Firebrick
    cx, cy = X(p.get("yc", 0.0)), Y(p["zc"])
    g.DrawLine(red, cx - 5, cy, cx + 5, cy)
    g.DrawLine(red, cx, cy - 5, cx, cy + 5)


# =========================================================================== main panel
def run_command(script):
    """Start one of the AF_ commands from the panel (typed into the command line, so it runs as a
    normal Rhino command with undo)."""
    path = os.path.join(ROOT, "commands", script + ".py")
    try:
        if Rhino.Commands.Command.InCommand():
            message("Finish or cancel (Esc) the running Rhino command first.")
            return
    except Exception:
        pass
    try:
        is_alias = Rhino.ApplicationSettings.CommandAliasList.IsAlias(script)
    except Exception:
        is_alias = False
    macro = script if is_alias else ('_-RunPythonScript "%s"' % path)
    try:
        Rhino.RhinoApp.SendKeystrokes(macro, True)
    except Exception:
        Rhino.RhinoApp.RunScript(macro, False)


MODEL_BUTTONS = [
    ("Plate", "AF_Plate", "af_plate", "Closed planar curves -> plates (inner curves = openings)"),
    ("Srf -> Plate", "AF_SurfaceToPlate", "af_srf2plate", "Existing surfaces / polysurfaces (also curved shell) -> plates"),
    ("Web / Girder", "AF_Web", "af_web", "Web plate along a line, with face plate or edge profile"),
    ("Profile", "AF_Profile", "af_profile", "Lines / curves -> profiles (stiffeners, beams, pillars)"),
    ("Stiffeners", "AF_Stiffeners", "af_stiffeners", "Stiffeners at a spacing across a plate (interrupted at openings)"),
    ("Bracket", "AF_Bracket", "af_bracket", "Bracket plate between two members, toes and face plate"),
    ("Opening", "AF_Opening", "af_opening", "Manhole / lightening hole / circle / any closed curve in a plate"),
    ("Face plate", "AF_FacePlate", "af_faceplate", "Face plate strip on the free edge of a web or bracket"),
    ("Assign", "AF_Assign", "af_assign", "STAAD-style property window: assign a plate property / section to many objects at once"),
    ("Flip web", "AF_FlipSide", "af_flipside", "Put the profile web on the other side of the plating"),
    ("Flip flange", "AF_FlipFlange", "af_flipflange", "Mirror the flange of L / bulb / channel profiles"),
    ("Info / Edit", "AF_Info", "af_info", "Show and edit the FEA data of picked members"),
    ("Check", "AF_Check", "af_check", "Model check: properties, planarity, gaps between plates"),
    ("Colour", "AF_Color", "af_color", "Colour members by property, material, thickness or layer"),
    ("3D View", "AF_3DView", "af_3dview", "3D View on / off: real plate thickness and profile sections, always up to date"),
    ("Index", "AF_Legend", "af_legend", "Floating property index (colours, counts, weights) on / off"),
    ("Team sync", "AF_Sync", "af_sync", "Publish your zone and load the zones of the team (shared folder)"),
    ("Material list", "AF_MTO", "af_mto", "Material take-off: plates and profiles with weights"),
    ("Export", "AF_Export", "af_export", "Export to ALIEF FEAPRO (.alfea)"),
    ("Import", "AF_Import", "af_import", "Open an ALIEF FEAPRO project (.alfea) in Rhino"),
    ("Update", "AF_Update", "af_update", "Check for a new version on the internet and install it"),
    ("Icon bar", "AF_Toolbar", "af_library", "Floating icon toolbar with all commands"),
    ("Rhino toolbar", "AF_RhinoToolbar", "af_logo_32", "Create / reopen the Rhino toolbar 'ALIEF FEA'"),
]


class Panel(object):
    def __init__(self):
        from . import rhinoio as io
        self.io = io
        self.busy = False
        self.lib = io.load_library()
        self.settings = io.load_settings()
        f = forms.Form()
        f.Title = "%s %s" % (C.APP, C.VERSION)
        f.ClientSize = drawing.Size(430, 800)
        f.Resizable = True
        f.Padding = drawing.Padding(6)
        self.form = f
        head = forms.TableLayout()
        logo = bitmap(icon("af_logo"))
        cells = []
        if logo is not None:
            iv = forms.ImageView()
            iv.Image = logo
            cells.append(iv)
        tl = forms.DynamicLayout()
        tl.AddRow(label("ALIEF FEA MODELER", True, 12))
        tl.AddRow(label("Rhino 8 -> ALIEF FEAPRO  |  %s" % C.COMPANY))
        cells.append(tl)
        head.Rows.Add(row(*cells + [None]))
        self.tabs = forms.TabControl()
        self.tabs.Pages.Add(self._page("Model", self._model_page()))
        self.tabs.Pages.Add(self._page("Plates", self._plates_page()))
        self.tabs.Pages.Add(self._page("Profiles", self._profiles_page()))
        self.tabs.Pages.Add(self._page("Materials", self._materials_page()))
        self.tabs.Pages.Add(self._page("Export", self._export_page()))
        self.tabs.Pages.Add(self._page("Team", self._team_page()))
        self.tabs.SelectedIndexChanged += lambda s, e: self.refresh()
        self._last = None
        lay = forms.DynamicLayout()
        lay.Spacing = drawing.Size(4, 6)
        lay.AddRow(head)
        add_scaled(lay, self.tabs)
        self.status = label("Ready")
        lay.AddRow(self.status)
        f.Content = lay
        f.GotFocus += lambda s, e: self.refresh()
        f.Closed += self._closed
        self.refresh()

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _page(text, content):
        p = forms.TabPage()
        p.Text = text
        sc_ = forms.Scrollable()
        sc_.Content = content
        p.Content = sc_
        return p

    def _rebuild_3d(self):
        """Library changed: the live 3D view and the property index are rebuilt on the next idle."""
        try:
            from . import live
            live.ensure().invalidate_all()
        except Exception as ex:
            self.say("3D view not updated: %s" % ex)

    def _closed(self, sender, e):
        try:
            del sc.sticky[STICKY]
        except Exception:
            pass

    def show(self):
        self.form.Owner = owner()
        self.form.Show()

    def say(self, text):
        self.status.Text = text

    def save_lib(self):
        self.io.save_library(self.lib)

    def save_settings(self):
        self.io.save_settings(self.settings)
        self._last = self._stamp()

    def names(self, key):
        return [x["name"] for x in self.lib.get(key, [])]

    @staticmethod
    def fill(dd, items, current=None, labels=None):
        dd.Items.Clear()
        for it in items:
            dd.Items.Add(str(labels.get(it, it)) if labels else str(it))
        if current in items:
            dd.SelectedIndex = list(items).index(current)
        elif items:
            dd.SelectedIndex = 0

    @staticmethod
    def pick(dd, items):
        i = dd.SelectedIndex
        return items[i] if 0 <= i < len(items) else (items[0] if items else "")

    @staticmethod
    def _dd_text(dd):
        i = dd.SelectedIndex
        return dd.Items[i].Text if 0 <= i < dd.Items.Count else None

    def _stamp(self):
        return (self.io._data("library") or "") + "|" + (self.io._data("settings") or "") + "|" + str(sc.doc.RuntimeSerialNumber)

    def refresh(self, force=False):
        if self.busy:
            return
        if not force and getattr(self, "_last", None) == self._stamp():
            return
        self.busy = True
        try:
            self.lib = self.io.load_library()
            self.settings = self.io.load_settings()
            st = self.settings
            self.fill(self.dd_prop, self.names("plate_props"), st["active_prop"])
            self.fill(self.dd_sec, self.names("sections"), st["active_section"])
            self.fill(self.dd_side, C.WEB_SIDES, st["web_side"], C.WEB_SIDE_LABELS)
            self.dd_flange.SelectedIndex = 0 if int(st.get("flange", 1)) >= 0 else 1
            self.fill(self.dd_off, C.OFFSET_MODES, st["offset"], C.OFFSET_LABELS)
            self.fill(self.dd_color, ["Property", "Material", "Thickness", "Layer"], st.get("color_by", "Property"))
            self.tb_facet.Text = "%g" % float(st.get("facet_size", 300.0))
            self._fill_props()
            self._fill_sections()
            self._fill_materials()
            self._fill_export()
            self.cb_3d.Checked = bool(st.get("show_3d", True))
            self.cb_legend.Checked = bool(st.get("legend", True))
            self._fill_team()
        finally:
            self.busy = False
        self._last = self._stamp()

    # ------------------------------------------------------------------ model page
    def _model_page(self):
        st = self.settings
        self.dd_prop = forms.DropDown()
        self.dd_sec = forms.DropDown()
        self.dd_side = forms.DropDown()
        self.dd_flange = dropdown(["+1 (normal)", "-1 (mirrored)"])
        self.dd_off = forms.DropDown()
        self.dd_color = forms.DropDown()
        self.tb_facet = textbox(st.get("facet_size", 300.0))
        for dd in (self.dd_prop, self.dd_sec, self.dd_side, self.dd_flange, self.dd_off, self.dd_color):
            dd.SelectedIndexChanged += self._active_changed
        self.tb_facet.LostFocus += self._active_changed
        self.cb_3d = checkbox("3D View - real plate thickness and profile sections (follows every change)",
                              st.get("show_3d", True))
        self.cb_legend = checkbox("Property index on screen (top left of the view)", st.get("legend", True))
        self.cb_3d.CheckedChanged += self._view_toggled
        self.cb_legend.CheckedChanged += self._view_toggled
        grid = form_grid([("Plate property", self.dd_prop), ("Profile section", self.dd_sec),
                          ("Profile web side", self.dd_side), ("Flange", self.dd_flange),
                          ("Profile offset", self.dd_off), ("Curved facet size [mm]", self.tb_facet),
                          ("Colour by", self.dd_color), ("", self.cb_3d), ("", self.cb_legend)])
        box = forms.GroupBox()
        box.Text = "Active properties (used by the tools)"
        box.Padding = drawing.Padding(6)
        box.Content = grid
        t = forms.TableLayout()
        t.Spacing = drawing.Size(4, 4)
        cur = []
        for text, script, ico, tip in MODEL_BUTTONS:
            b = button(text, lambda s, e, sc_=script: run_command(sc_), ico, tip, above=True)
            b.Width = 128
            b.Height = 74
            cur.append(b)
            if len(cur) == 3:
                t.Rows.Add(row(*cur))
                cur = []
        if cur:
            t.Rows.Add(row(*(cur + [None])))
        tools = forms.GroupBox()
        tools.Text = "Modelling tools"
        tools.Padding = drawing.Padding(6)
        tools.Content = t
        lay = forms.DynamicLayout()
        lay.Spacing = drawing.Size(6, 8)
        lay.Padding = drawing.Padding(4)
        lay.AddRow(box)
        lay.AddRow(tools)
        lay.AddRow(label("Tip: model plates as mid-plane surfaces and draw profiles on the plating "
                         "(the line is the profile toe). Brackets, webs and decks must meet exactly - "
                         "use object snaps. Run Check before Export.", wrap=True))
        return lay

    def _view_toggled(self, sender, e):
        if self.busy:
            return
        self.settings["show_3d"] = bool(self.cb_3d.Checked)
        self.settings["legend"] = bool(self.cb_legend.Checked)
        self.save_settings()
        try:
            from . import live
            live.ensure().settings_changed()
        except Exception as ex:
            self.say(str(ex))
        self.say("3D View %s, index %s" % ("on" if self.cb_3d.Checked else "off", "on" if self.cb_legend.Checked else "off"))

    def _active_changed(self, sender, e):
        if self.busy:
            return
        st = self.settings
        st["active_prop"] = self.pick(self.dd_prop, self.names("plate_props"))
        st["active_section"] = self.pick(self.dd_sec, self.names("sections"))
        st["web_side"] = self.pick(self.dd_side, C.WEB_SIDES)
        st["flange"] = 1 if self.dd_flange.SelectedIndex <= 0 else -1
        st["offset"] = self.pick(self.dd_off, C.OFFSET_MODES)
        new_color = self.pick(self.dd_color, ["Property", "Material", "Thickness", "Layer"])
        recolor = new_color != st.get("color_by")
        st["color_by"] = new_color
        v = to_float(self.tb_facet.Text)
        if v and v > 0:
            st["facet_size"] = v
        self.save_settings()
        if recolor:
            n = self.io.recolor_all(self.lib, st)
            self._rebuild_3d()
            self.say("%d members coloured by %s" % (n, new_color))
        else:
            try:
                from . import live
                live.settings_changed()
            except Exception:
                pass
            self.say("Active: %s | %s" % (st["active_prop"], st["active_section"]))

    # ------------------------------------------------------------------ plates page
    def _plates_page(self):
        self.lst_props = forms.ListBox()
        self.lst_props.Height = 230
        self.lst_props.SelectedIndexChanged += self._prop_selected
        self.tb_t = textbox("10")
        self.dd_pmat = forms.DropDown()
        self.tb_tc = textbox("0")
        self.tb_pname = textbox("")
        self.tb_pname.PlaceholderText = "automatic: PL<t> <material>"
        self.cp_pcol = forms.ColorPicker()
        grid = form_grid([("Thickness t [mm]", self.tb_t), ("Material", self.dd_pmat),
                          ("Corrosion addition tc [mm]", self.tb_tc), ("Name", self.tb_pname), ("Colour", self.cp_pcol)])
        btns = table([row(button("Add", self._prop_add), button("Update", self._prop_update),
                          button("Delete", self._prop_delete), None)])
        btn2 = table([row(button("Make active", self._prop_active), button("Assign to selected objects", self._prop_assign), None)])
        lay = forms.DynamicLayout()
        lay.Spacing = drawing.Size(6, 8)
        lay.Padding = drawing.Padding(4)
        lay.AddRow(label("Plate properties (thickness + material) - exported to ALIEF FEAPRO 'Plate properties'", wrap=True))
        lay.AddRow(self.lst_props)
        lay.AddRow(grid)
        lay.AddRow(btns)
        lay.AddRow(btn2)
        return lay

    def _fill_props(self):
        sel = self.lst_props.SelectedIndex
        self.lst_props.Items.Clear()
        for p in self.lib["plate_props"]:
            self.lst_props.Items.Add("%-22s  t = %g mm   %s%s" % (p["name"], p["thickness"], p["material"],
                                                                  ("   tc %g" % p["tc"]) if p.get("tc") else ""))
        self.fill(self.dd_pmat, self.names("materials"), self._dd_text(self.dd_pmat))
        if 0 <= sel < len(self.lib["plate_props"]):
            self.lst_props.SelectedIndex = sel

    def _prop_selected(self, sender, e):
        i = self.lst_props.SelectedIndex
        if i < 0 or i >= len(self.lib["plate_props"]):
            return
        p = self.lib["plate_props"][i]
        self.tb_t.Text = "%g" % p["thickness"]
        self.fill(self.dd_pmat, self.names("materials"), p["material"])
        self.tb_tc.Text = "%g" % p.get("tc", 0.0)
        self.tb_pname.Text = p["name"]
        r, g, b = C.hex2rgb(p.get("color") or C.thickness_color(p["thickness"]))
        self.cp_pcol.Value = drawing.Color.FromArgb(r, g, b, 255)

    def _prop_from_fields(self):
        t = to_float(self.tb_t.Text)
        tc = to_float(self.tb_tc.Text, 0.0)
        if not t or t <= 0:
            message("Thickness must be a positive number.")
            return None
        mat = self.pick(self.dd_pmat, self.names("materials"))
        nm = self.tb_pname.Text.strip() or C.plate_prop_name(t, mat)
        c = self.cp_pcol.Value
        col = C.rgb2hex((c.Rb, c.Gb, c.Bb)) if c.A > 0 and (c.Rb, c.Gb, c.Bb) != (0, 0, 0) else C.thickness_color(t)
        return C.plate_prop(nm, t, mat, tc or 0.0, col)

    def _prop_add(self, sender, e):
        p = self._prop_from_fields()
        if p is None:
            return
        if p["name"] in self.names("plate_props"):
            p["name"] = C.plate_prop_name(p["thickness"], p["material"])
            if p["name"] in self.names("plate_props"):
                message("A plate property named '%s' exists already - use Update." % p["name"])
                return
        self.lib["plate_props"].append(p)
        self.save_lib()
        self.tb_pname.Text = ""
        self.refresh(True)
        self.say("Plate property %s added" % p["name"])

    def _prop_update(self, sender, e):
        i = self.lst_props.SelectedIndex
        if i < 0:
            message("Select a plate property in the list first.")
            return
        p = self._prop_from_fields()
        if p is None:
            return
        old = self.lib["plate_props"][i]["name"]
        self.lib["plate_props"][i] = p
        self.save_lib()
        n = 0
        for obj in self.io.af_objects("plate"):
            if self.io.af(obj, self.io.K_PROP) == old:
                self.io.set_af(obj, {self.io.K_PROP: p["name"]}, color=self.io.plate_color(self.lib, p["name"]))
                n += 1
        if self.settings["active_prop"] == old:
            self.settings["active_prop"] = p["name"]
            self.save_settings()
        self._rebuild_3d()
        sc.doc.Views.Redraw()
        self.refresh(True)
        self.say("Plate property updated (%d plates)" % n)

    def _prop_delete(self, sender, e):
        i = self.lst_props.SelectedIndex
        if i < 0:
            return
        nm = self.lib["plate_props"][i]["name"]
        used = sum(1 for o in self.io.af_objects("plate") if self.io.af(o, self.io.K_PROP) == nm)
        if used:
            message("'%s' is used by %d plates - assign another property first." % (nm, used))
            return
        del self.lib["plate_props"][i]
        self.save_lib()
        self.refresh(True)

    def _prop_active(self, sender, e):
        i = self.lst_props.SelectedIndex
        if i >= 0:
            self.settings["active_prop"] = self.lib["plate_props"][i]["name"]
            self.save_settings()
            self.refresh(True)
            self.say("Active plate property: %s" % self.settings["active_prop"])

    def _prop_assign(self, sender, e):
        self._prop_active(sender, e)
        sc.sticky[ASSIGN_KEY] = dict(kind="plate", name=self.settings["active_prop"], method="Assign To Selected",
                                     role="Plate", keep=True)
        run_command("AF_AssignNow")

    # ------------------------------------------------------------------ profiles page
    def _profiles_page(self):
        self.lst_secs = forms.ListBox()
        self.lst_secs.Height = 170
        self.lst_secs.SelectedIndexChanged += self._sec_selected
        self.dd_type = dropdown(C.TYPE_ORDER, "L", C.TYPE_LABELS)
        self.dd_type.SelectedIndexChanged += self._type_changed
        self.dd_size = forms.DropDown()
        self.dd_size.SelectedIndexChanged += self._size_changed
        self.dim_lab, self.dim_tb = [], []
        pairs = [("Profile type", self.dd_type), ("Catalogue size", self.dd_size)]
        for k in range(6):
            lb = label("")
            tb = textbox("")
            tb.TextChanged += lambda s, e: self._sketch.Invalidate()
            self.dim_lab.append(lb)
            self.dim_tb.append(tb)
            pairs.append((lb, tb))
        self.dd_smat = forms.DropDown()
        self.tb_stc = textbox("0")
        self.tb_secname = textbox("")
        self.tb_secname.ToolTip = "Leave empty for the ALIEF FEAPRO name (e.g. HP 200x10); fill in for your own name (e.g. Rail 30 kg)"
        pairs += [("Material", self.dd_smat), ("Corrosion addition tc [mm]", self.tb_stc), ("Own name (optional)", self.tb_secname)]
        grid = form_grid(pairs)
        self._sketch = forms.Drawable()
        self._sketch.Size = drawing.Size(200, 190)
        self._sketch.Paint += self._paint_sketch
        self.lb_props = label("")
        self.lb_props.Size = drawing.Size(200, 112)
        side = forms.DynamicLayout()
        side.AddRow(self._sketch)
        side.AddRow(self.lb_props)
        top = table([row(forms.TableCell(grid, True), side)])
        btns = table([row(button("Add", self._sec_add), button("Update", self._sec_update), button("Delete", self._sec_delete),
                          button("Make active", self._sec_active), None),
                      row(button("+ Catalogue", self._cat_add, None, "Add these dimensions to your own profile catalogue"),
                          button("- Catalogue", self._cat_remove, None, "Remove the selected size from your own catalogue"),
                          button("Import CSV", self._cat_import, None, "Read sizes from a CSV file (type, name, dimensions)"),
                          button("Export CSV", self._cat_export, None, "Write your own catalogue to a CSV file"), None)])
        lay = forms.DynamicLayout()
        lay.Spacing = drawing.Size(6, 8)
        lay.Padding = drawing.Padding(4)
        lay.AddRow(label("Profile sections - ALIEF FEAPRO catalogue and rules (FB, L, T, H, C, HP, PIPE, RB, GEN). "
                         "Section axes: z along the web from the plating (toe) to the free flange. Sizes marked * are "
                         "your own catalogue (+ Catalogue) - kept on this computer and in the model.", wrap=True))
        lay.AddRow(self.lst_secs)
        lay.AddRow(top)
        lay.AddRow(btns)
        self._type_changed(None, None)
        return lay

    def _cur_type(self):
        return self.pick(self.dd_type, C.TYPE_ORDER)

    def _type_changed(self, sender, e):
        st = self._cur_type()
        self.ucat = user_catalogue(getattr(self, "lib", None))
        self.cat_entries = C.catalogue_entries(st, self.ucat)
        labs = [x[0] for x in self.cat_entries]
        self.dd_size.Items.Clear()
        self.dd_size.Items.Add("(manual dimensions)")
        for lb, d, src in self.cat_entries:
            self.dd_size.Items.Add(("* " + lb) if src == "User" else lb)
        fields = C.DIM_FIELDS[st]
        for k in range(6):
            vis = k < len(fields)
            self.dim_lab[k].Visible = vis
            self.dim_tb[k].Visible = vis
            if vis:
                self.dim_lab[k].Text = fields[k][1] + (" [mm]" if "[" not in fields[k][1] else "")
        self.dd_size.SelectedIndex = 1 if labs and not self.busy else 0
        self._sketch.Invalidate()

    def _size_changed(self, sender, e):
        st = self._cur_type()
        i = self.dd_size.SelectedIndex - 1
        cat = getattr(self, "cat_entries", None) or C.catalogue_entries(st)
        if 0 <= i < len(cat):
            lab, dims, src = cat[i]
            for k, (key, lb) in enumerate(C.DIM_FIELDS[st]):
                self.dim_tb[k].Text = "%g" % dims.get(key, 0.0)
            own = lab if (src == "User" and lab != C.section_label(st, dims)) else ""
            if hasattr(self, "tb_secname") and not self.busy:
                self.tb_secname.Text = own
        self._sketch.Invalidate()

    # ------------------------------------------------------------------ own catalogue
    def _cat_add(self, sender, e):
        st, d = self._dims()
        own = (self.tb_secname.Text or "").strip()
        cat, msg = C.catalogue_add(user_catalogue(self.lib), st, d, own)
        if "added" in msg:
            save_user_catalogue(cat, self.lib)
            self.save_lib()
            lab = C.catalogue_entry_label(st, dict(d, name=own))
            self._type_changed(None, None)
            for k, x in enumerate(self.cat_entries):
                if x[0] == lab:
                    self.dd_size.SelectedIndex = k + 1
        self.say(msg)

    def _cat_remove(self, sender, e):
        st = self._cur_type()
        i = self.dd_size.SelectedIndex - 1
        if not (0 <= i < len(self.cat_entries)) or self.cat_entries[i][2] != "User":
            message("Choose one of YOUR catalogue sizes (marked *) in 'Catalogue size' first.")
            return
        cat, msg = C.catalogue_remove(user_catalogue(self.lib), st, self.cat_entries[i][0])
        save_user_catalogue(cat, self.lib, replace=True)
        self.save_lib()
        self._type_changed(None, None)
        self.say(msg)

    def _cat_import(self, sender, e):
        dlg = forms.OpenFileDialog()
        dlg.Title = "Import profile catalogue (CSV: type, name, dimensions)"
        try:
            dlg.Filters.Add(forms.FileFilter("CSV file", ".csv"))
        except Exception:
            pass
        if dlg.ShowDialog(self.form) != forms.DialogResult.Ok:
            return
        try:
            with open(dlg.FileName, newline="", encoding="utf-8-sig") as fh:
                first = fh.readline()
                fh.seek(0)
                rows = list(csv.reader(fh, delimiter=";" if ";" in first and "," not in first else ","))
        except Exception as ex:
            message("Could not read the file:\n%s" % ex)
            return
        new, msgs = C.catalogue_from_rows(rows)
        n = sum(len(v) for v in new.values())
        cat = C.catalogue_merge(user_catalogue(self.lib), new)
        save_user_catalogue(cat, self.lib)
        self.save_lib()
        self._type_changed(None, None)
        report("Catalogue import", "%d size(s) read from %s\n\n%s" % (n, dlg.FileName, "\n".join(msgs) or "No problems."))

    def _cat_export(self, sender, e):
        dlg = forms.SaveFileDialog()
        dlg.Title = "Export your profile catalogue"
        try:
            dlg.Filters.Add(forms.FileFilter("CSV file", ".csv"))
        except Exception:
            pass
        dlg.FileName = "ALIEF_FEA_profile_catalogue.csv"
        if dlg.ShowDialog(self.form) != forms.DialogResult.Ok:
            return
        fn = dlg.FileName if dlg.FileName.lower().endswith(".csv") else dlg.FileName + ".csv"
        with open(fn, "w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerows(C.catalogue_to_rows(user_catalogue(self.lib)))
        self.say("Catalogue written to %s" % fn)

    def _dims(self):
        st = self._cur_type()
        d = {}
        for k, (key, lab) in enumerate(C.DIM_FIELDS[st]):
            v = to_float(self.dim_tb[k].Text, 0.0)
            d[key] = v or 0.0
        return st, C.normalise_dims(st, d)

    def _paint_sketch(self, sender, e):
        st, d = self._dims()
        try:
            draw_section(e.Graphics, float(self._sketch.Width), float(self._sketch.Height), st, d)
            if not C.check_dims(st, d):
                p = C.section_properties(st, d)
                self.lb_props.Text = ("%s\nA = %.1f cm2   zc = %.1f mm\nIy = %.4g cm4\nWmin = %.4g cm3\nmass = %.2f kg/m\n(%s)"
                                      % (C.section_label(st, d), p["A"] / 100, p["zc"], p["Iy"] / 1e4, p["Wmin"] / 1e3,
                                         p["mass"], p["source"]))
            else:
                self.lb_props.Text = ""
        except Exception as ex:
            self.lb_props.Text = str(ex)

    def _fill_sections(self):
        sel = self.lst_secs.SelectedIndex
        self.lst_secs.Items.Clear()
        for s in self.lib["sections"]:
            self.lst_secs.Items.Add("%-24s %-6s %s%s" % (s["name"], s["stype"], s["material"],
                                                         ("   tc %g" % s["tc"]) if s.get("tc") else ""))
        self.fill(self.dd_smat, self.names("materials"), self._dd_text(self.dd_smat))
        if 0 <= sel < len(self.lib["sections"]):
            self.lst_secs.SelectedIndex = sel

    def _sec_selected(self, sender, e):
        i = self.lst_secs.SelectedIndex
        if i < 0 or i >= len(self.lib["sections"]):
            return
        s = self.lib["sections"][i]
        self.busy = True
        try:
            self.dd_type.SelectedIndex = C.TYPE_ORDER.index(s["stype"])
            self._type_changed(None, None)
            self.dd_size.SelectedIndex = 0
            for k, (key, lab) in enumerate(C.DIM_FIELDS[s["stype"]]):
                self.dim_tb[k].Text = "%g" % s["dims"].get(key, 0.0)
            self.tb_secname.Text = s["name"] if s["name"] != C.section_label(s["stype"], s["dims"]) else ""
            self.fill(self.dd_smat, self.names("materials"), s["material"])
            self.tb_stc.Text = "%g" % s.get("tc", 0.0)
        finally:
            self.busy = False
        self._sketch.Invalidate()

    def _sec_from_fields(self):
        st, d = self._dims()
        err = C.check_dims(st, d)
        if err:
            message(err)
            return None
        mat = self.pick(self.dd_smat, self.names("materials"))
        n = len(self.lib["sections"])
        own = (self.tb_secname.Text or "").strip() or None
        return C.make_section(st, d, mat, name=own, tc=to_float(self.tb_stc.Text, 0.0) or 0.0,
                              color=C.SECTION_PALETTE[n % len(C.SECTION_PALETTE)])

    def _sec_add(self, sender, e):
        s = self._sec_from_fields()
        if s is None:
            return
        if s["name"] in self.names("sections"):
            message("Section '%s' exists already." % s["name"])
            return
        self.lib["sections"].append(s)
        self.save_lib()
        self.refresh(True)
        self.say("Section %s added" % s["name"])

    def _sec_update(self, sender, e):
        i = self.lst_secs.SelectedIndex
        if i < 0:
            message("Select a section in the list first.")
            return
        s = self._sec_from_fields()
        if s is None:
            return
        old = self.lib["sections"][i]
        s["color"] = old.get("color", s["color"])
        self.lib["sections"][i] = s
        self.save_lib()
        n = 0
        for obj in self.io.af_objects("profile"):
            if self.io.af(obj, self.io.K_SEC) == old["name"]:
                self.io.set_af(obj, {self.io.K_SEC: s["name"]})
                n += 1
        if self.settings["active_section"] == old["name"]:
            self.settings["active_section"] = s["name"]
            self.save_settings()
        self._rebuild_3d()
        self.refresh(True)
        self.say("Section updated (%d profiles)" % n)

    def _sec_delete(self, sender, e):
        i = self.lst_secs.SelectedIndex
        if i < 0:
            return
        nm = self.lib["sections"][i]["name"]
        used = sum(1 for o in self.io.af_objects("profile") if self.io.af(o, self.io.K_SEC) == nm)
        if used:
            message("'%s' is used by %d profiles - assign another section first." % (nm, used))
            return
        del self.lib["sections"][i]
        self.save_lib()
        self.refresh(True)

    def _sec_active(self, sender, e):
        i = self.lst_secs.SelectedIndex
        if i >= 0:
            self.settings["active_section"] = self.lib["sections"][i]["name"]
            self.save_settings()
            self.refresh(True)
            self.say("Active section: %s" % self.settings["active_section"])

    # ------------------------------------------------------------------ team page
    def _team_page(self):
        self.lb_team = label("", wrap=True, chars=66)
        self.lst_team = forms.ListBox()
        self.lst_team.Height = 190
        self.lst_team.Font = drawing.Font("Consolas", 8)
        btns = table([row(button("Sync now", lambda s, e: run_command("AF_Sync"), "af_sync", "Publish your zone and load the others"),
                          button("Setup...", lambda s, e: run_command("AF_SyncSetup"), None, "Shared folder, your name and zone"),
                          button("Show / hide team zones", self._team_toggle), None)])
        lay = forms.DynamicLayout()
        lay.Spacing = drawing.Size(6, 8)
        lay.Padding = drawing.Padding(4)
        lay.AddRow(label("Team sync - several people, one model", True, 10))
        lay.AddRow(label("Everybody uses the SAME shared folder (Google Drive / OneDrive / Dropbox / network) and models his "
                         "OWN zone. Saving the file (Ctrl+S) publishes your zone; the zones of the others appear locked on "
                         "layer ALIEF_SYNC and are refreshed automatically when their owner saves.", wrap=True, chars=66))
        lay.AddRow(self.lb_team)
        lay.AddRow(self.lst_team)
        lay.AddRow(btns)
        lay.AddRow(label("Export to ALIEF FEAPRO from any file: it contains the whole model. Member ids stay the same, "
                         "so supports and loads made in FEAPRO are kept when you export again.", wrap=True, chars=66))
        return lay

    def _fill_team(self):
        try:
            from . import sync as S
            cfg = S.load_cfg()
            self.lst_team.Items.Clear()
            if not S.configured(cfg):
                self.lb_team.Text = "Not set up yet - press Setup... (or run AF_SyncSetup)."
                return
            self.lb_team.Text = wrap_text("Folder: %s\nYou: %s  |  zone %s  |  %s  |  automatic: %s" % (
                cfg["folder"], cfg.get("user"), C.safe_zone(cfg["zone"]), S.computer(), "yes" if cfg.get("auto", True) else "no"), 66)
            self.lst_team.Items.Add("%-12s %-22s %-17s %4s %6s  %s" % ("ZONE", "OWNER", "SAVED", "REV", "MEMB.", "STATE"))
            for r in S.status_rows(cfg):
                self.lst_team.Items.Add("%-12s %-22s %-17s %4s %6s  %s" % (r[0][:12], r[1][:22], str(r[2])[:17], r[3], r[4], r[5]))
        except Exception as ex:
            self.lb_team.Text = "Team status not available: %s" % ex

    def _team_toggle(self, sender, e):
        import rhinoscriptsyntax as rs
        if not rs.IsLayer("ALIEF_SYNC"):
            self.say("No team zones loaded yet.")
            return
        vis = not rs.LayerVisible("ALIEF_SYNC")
        rs.LayerVisible("ALIEF_SYNC", vis)
        sc.doc.Views.Redraw()
        self.say("Team zones %s" % ("shown" if vis else "hidden"))

    # ------------------------------------------------------------------ materials page
    def _materials_page(self):
        self.lst_mats = forms.ListBox()
        self.lst_mats.Height = 180
        self.lst_mats.SelectedIndexChanged += self._mat_selected
        self.builtin = C.material_library()
        self.dd_lib = dropdown(list(self.builtin))
        self.tb_m = {}
        pairs = []
        for key, lab in (("name", "Name"), ("category", "Category"), ("E", "E [MPa]"), ("nu", "Poisson nu"),
                         ("density", "Density [kg/m3]"), ("ReH", "ReH [MPa]"), ("Rm", "Rm [MPa]"), ("k", "Material factor k"),
                         ("standard", "Standard")):
            self.tb_m[key] = textbox("")
            pairs.append((lab, self.tb_m[key]))
        lay = forms.DynamicLayout()
        lay.Spacing = drawing.Size(6, 8)
        lay.Padding = drawing.Padding(4)
        lay.AddRow(label("Materials of this model (IACS UR W11 grades, aluminium, stainless or custom).", wrap=True))
        lay.AddRow(self.lst_mats)
        lay.AddRow(table([row(self.dd_lib, button("Add from library", self._mat_add_lib), None)]))
        lay.AddRow(form_grid(pairs))
        lay.AddRow(table([row(button("Add / update custom", self._mat_custom), button("Delete", self._mat_delete), None)]))
        lay.AddRow(label("k: IACS / CSR values; BKI uses k = 295 / (ReH + 60).", wrap=True))
        return lay

    def _fill_materials(self):
        sel = self.lst_mats.SelectedIndex
        self.lst_mats.Items.Clear()
        for m in self.lib["materials"]:
            self.lst_mats.Items.Add("%-16s ReH %4g  Rm %4g  E %g  k %.2f  %s" % (m["name"], m["ReH"], m["Rm"], m["E"], m["k"], m["category"]))
        if 0 <= sel < len(self.lib["materials"]):
            self.lst_mats.SelectedIndex = sel

    def _mat_selected(self, sender, e):
        i = self.lst_mats.SelectedIndex
        if 0 <= i < len(self.lib["materials"]):
            m = self.lib["materials"][i]
            for k, tb in self.tb_m.items():
                v = m.get(k, "")
                tb.Text = ("%g" % v) if isinstance(v, float) else str(v)

    def _mat_add_lib(self, sender, e):
        nm = self.pick(self.dd_lib, list(self.builtin))
        if nm in self.names("materials"):
            self.say("%s is already in the model" % nm)
            return
        self.lib["materials"].append(dict(self.builtin[nm]))
        self.save_lib()
        self.refresh(True)
        self.say("Material %s added" % nm)

    def _mat_custom(self, sender, e):
        d = {}
        for k, tb in self.tb_m.items():
            d[k] = tb.Text.strip()
        if not d["name"]:
            message("Enter a material name.")
            return
        try:
            m = C.material(d["name"], d["category"] or "Custom", float(d["E"]), float(d["nu"]), float(d["density"]),
                           float(d["ReH"]), float(d["Rm"]), float(d["k"] or C.k_factor(float(d["ReH"]))),
                           d["standard"] or "Custom", "#9E9E9E")
        except ValueError:
            message("E, nu, density, ReH, Rm and k must be numbers.")
            return
        for i, old in enumerate(self.lib["materials"]):
            if old["name"] == m["name"]:
                m["color"] = old.get("color", m["color"])
                self.lib["materials"][i] = m
                break
        else:
            self.lib["materials"].append(m)
        self.save_lib()
        self.refresh(True)
        self.say("Material %s saved" % m["name"])

    def _mat_delete(self, sender, e):
        i = self.lst_mats.SelectedIndex
        if i < 0:
            return
        nm = self.lib["materials"][i]["name"]
        users = [p["name"] for p in self.lib["plate_props"] if p["material"] == nm] + \
                [s["name"] for s in self.lib["sections"] if s["material"] == nm]
        if users:
            message("'%s' is used by: %s" % (nm, ", ".join(users[:8])))
            return
        del self.lib["materials"][i]
        self.save_lib()
        self.refresh(True)

    # ------------------------------------------------------------------ export page
    def _export_page(self):
        self.tb_proj = textbox("")
        self.tb_ship = textbox("")
        self.tb_desc = textbox("")
        self.tb_path = textbox("")
        self.cb_keep = forms.CheckBox()
        self.cb_keep.Text = "Update an existing file: keep supports, loads, load cases and settings made in ALIEF FEAPRO"
        self.tb_gx0 = textbox("0")
        self.ta_gseg = forms.TextArea()
        self.ta_gseg.Size = drawing.Size(200, 50)
        self.tb_gdeck = textbox("")
        self.cb_grid = forms.CheckBox()
        self.cb_grid.Text = "Write the frame table to the file"
        self.tb_gmesh = textbox("100")
        self.tb_chord = textbox("1")
        self.tb_gap = textbox("5")
        for tb in (self.tb_proj, self.tb_ship, self.tb_desc, self.tb_path, self.tb_gx0, self.ta_gseg, self.tb_gdeck,
                   self.tb_gmesh, self.tb_chord, self.tb_gap):
            tb.TextChanged += self._export_edited
        self.cb_keep.CheckedChanged += self._export_edited
        self.cb_grid.CheckedChanged += self._export_edited
        browse = button("...", self._browse)
        prow = table([row(forms.TableCell(self.tb_path, True), browse)])
        g1 = form_grid([("Project name", self.tb_proj), ("Ship name", self.tb_ship), ("Description", self.tb_desc),
                        ("File (.alfea)", prow)])
        g2 = form_grid([("X of Fr 0 [mm]", self.tb_gx0), ("Frame spacing\n(from, to, spacing)", self.ta_gseg),
                        ("Decks (MD=3000, ...)", self.tb_gdeck), ("", self.cb_grid)])
        g3 = form_grid([("Global mesh size [mm]", self.tb_gmesh), ("Chord tolerance curves [mm]", self.tb_chord),
                        ("Gap check tolerance [mm]", self.tb_gap)])
        gb2 = forms.GroupBox()
        gb2.Text = "Frame table (FEAPRO coordinates Fr12, MD+450 ...)"
        gb2.Padding = drawing.Padding(6)
        gb2.Content = g2
        btns = table([row(button("Model check", lambda s, e: self._export_cmd("AF_Check"), "af_check", above=True),
                          button("Export now", lambda s, e: self._export_cmd("AF_ExportNow"), "af_export", above=True),
                          button("Import .alfea", lambda s, e: self._export_cmd("AF_Import"), "af_import", above=True),
                          button("Material list", lambda s, e: self._export_cmd("AF_MTO"), "af_mto", above=True))])
        lay = forms.DynamicLayout()
        lay.Spacing = drawing.Size(6, 8)
        lay.Padding = drawing.Padding(4)
        lay.AddRow(g1)
        lay.AddRow(self.cb_keep)
        lay.AddRow(gb2)
        lay.AddRow(g3)
        lay.AddRow(btns)
        lay.AddRow(label("In ALIEF FEAPRO: File > Open the .alfea file. Materials, plate properties, sections, plates, "
                         "profiles and layers are ready - add the mesh, supports and loads.", wrap=True))
        return lay

    def _fill_export(self):
        st = self.settings
        self.tb_proj.Text = st.get("project", "")
        self.tb_ship.Text = st.get("ship", "")
        self.tb_desc.Text = st.get("description", "")
        self.tb_path.Text = st.get("export_path", "")
        self.cb_keep.Checked = bool(st.get("keep_existing", True))
        self.tb_gx0.Text = "%g" % float(st.get("grid_x0", 0.0) or 0.0)
        self.ta_gseg.Text = str(st.get("grid_spacing", "")).replace(";", "\n")
        self.tb_gdeck.Text = st.get("grid_decks", "")
        self.cb_grid.Checked = bool(st.get("write_grid", False))
        self.tb_gmesh.Text = "%g" % float(st.get("global_mesh", 100.0))
        self.tb_chord.Text = "%g" % float(st.get("chord_tol", 1.0))
        self.tb_gap.Text = "%g" % float(st.get("gap_tol", 5.0))

    def _export_edited(self, sender, e):
        if not self.busy:
            self._read_export()

    def _read_export(self):
        st = self.settings
        st["project"] = self.tb_proj.Text.strip()
        st["ship"] = self.tb_ship.Text.strip()
        st["description"] = self.tb_desc.Text.strip()
        st["export_path"] = self.tb_path.Text.strip()
        st["keep_existing"] = bool(self.cb_keep.Checked)
        st["grid_x0"] = to_float(self.tb_gx0.Text, 0.0) or 0.0
        st["grid_spacing"] = self.ta_gseg.Text.strip().replace("\r", "").replace("\n", ";")
        st["grid_decks"] = self.tb_gdeck.Text.strip()
        st["write_grid"] = bool(self.cb_grid.Checked)
        st["global_mesh"] = to_float(self.tb_gmesh.Text, 100.0) or 100.0
        st["chord_tol"] = max(to_float(self.tb_chord.Text, 1.0) or 1.0, 0.05)
        st["gap_tol"] = to_float(self.tb_gap.Text, 5.0) or 5.0
        self.save_settings()

    def _browse(self, sender, e):
        dlg = forms.SaveFileDialog()
        dlg.Title = "Export to ALIEF FEAPRO"
        dlg.Filters.Add(forms.FileFilter("ALIEF FEAPRO project (*.alfea)", ".alfea"))
        if self.tb_path.Text:
            try:
                dlg.FileName = self.tb_path.Text
            except Exception:
                pass
        if dlg.ShowDialog(self.form) == forms.DialogResult.Ok:
            fn = dlg.FileName
            if not fn.lower().endswith(".alfea"):
                fn += ".alfea"
            self.tb_path.Text = fn
            self._read_export()

    def _export_cmd(self, script):
        self._read_export()
        run_command(script)


TOOLBAR_STICKY = "ALIEF_FEA_TOOLBAR"


class IconToolbar(object):
    """Small floating toolbar: one icon per command, tooltip on hover (like a Rhino toolbar)."""

    def __init__(self, vertical=False):
        from . import toolbar as T
        self.T = T
        self.vertical = vertical
        f = forms.Form()
        f.Title = "ALIEF FEA"
        f.Resizable = False
        f.Minimizable = False
        f.Maximizable = False
        f.ShowInTaskbar = False
        f.Padding = drawing.Padding(3)
        f.Closed += self._closed
        self.form = f
        self.build()

    def _closed(self, sender, e):
        try:
            del sc.sticky[TOOLBAR_STICKY]
        except Exception:
            pass

    def _btn(self, script, ico, text, tip):
        b = forms.Button()
        bmp = bitmap(icon(ico if ico != "af_logo" else "af_logo_32"))
        if bmp is not None:
            b.Image = bmp
            b.ImagePosition = forms.ButtonImagePosition.Overlay
            b.Text = ""
        else:
            b.Text = text
        b.ToolTip = "%s\n%s" % (script, tip)
        b.Size = drawing.Size(40, 40)
        b.Click += lambda s, e, sc_=script: run_command(sc_)
        return b

    def build(self):
        t = forms.TableLayout()
        t.Spacing = drawing.Size(2, 2)
        cells = []
        for it in self.T.ITEMS:
            if it is None:
                sep = forms.Label()
                sep.Text = ""
                sep.Size = drawing.Size(6, 6)
                cells.append(sep)
            else:
                cells.append(self._btn(*it))
        flip = forms.Button()
        flip.Text = "<>" if not self.vertical else "^v"
        flip.ToolTip = "Horizontal / vertical"
        flip.Size = drawing.Size(28, 40) if not self.vertical else drawing.Size(40, 22)
        flip.Click += self._flip
        cells.append(flip)
        if self.vertical:
            for c in cells:
                t.Rows.Add(row(c))
        else:
            t.Rows.Add(row(*cells))
        self.form.Content = t

    def _flip(self, sender, e):
        self.vertical = not self.vertical
        self.build()

    def show(self):
        self.form.Owner = owner()
        self.form.Show()


def show_toolbar(vertical=False):
    tb = sc.sticky.get(TOOLBAR_STICKY)
    if tb is not None:
        try:
            tb.form.BringToFront()
            return tb
        except Exception:
            pass
    tb = IconToolbar(vertical)
    sc.sticky[TOOLBAR_STICKY] = tb
    tb.show()
    return tb


def cfg_dir():
    d = os.path.join(os.environ.get("APPDATA", ROOT), "AliefEnergy", "ALIEF_FEA_Rhino")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def _show_toolbar_group(tf, T):
    """Make the 'ALIEF FEA' toolbar visible. Rhino 8 turns the .rui toolbar group into a container
    (tab 'ALIEF FEA' + icon row, docked at the top); -ShowToolbar is the fallback when the group
    cannot be reached."""
    shown = False
    try:
        for i in range(int(tf.GroupCount)):
            g = tf.GetGroup(i)
            if g is not None:
                g.Visible = True
                shown = shown or bool(g.Visible)
    except Exception:
        shown = False
    if not shown:
        try:
            shown = bool(Rhino.RhinoApp.RunScript('_-ShowToolbar "%s"' % T.TOOLBAR_NAME, False))
        except Exception:
            shown = False
    return shown


def open_rhino_toolbar(root, show=None):
    """Write ALIEF_FEA.rui with this folder's paths, open it in Rhino and show the 'ALIEF FEA' toolbar.
    show: True = always show, False = never, None = only the first time on this computer (so a
    re-install does not add a second copy next to the one the user already docked).
    Returns (path, message, opened)."""
    from . import toolbar as T
    path = os.path.join(root, "ALIEF_FEA.rui")
    flag = os.path.join(cfg_dir(), "toolbar_%s.txt" % T.GROUP_SEED)
    try:
        tfs = Rhino.RhinoApp.ToolbarFiles
        tf = tfs.FindByPath(path)
        if tf is None or T.rui_text_changed(root, path):
            if tf is not None:
                tf.Close(False)          # reopen so Rhino reads the new icons / paths
            T.write_rui(root, path)
            tf = tfs.Open(path)
        if tf is None:
            return path, "Rhino could not open %s - use AF_Toolbar (floating icon bar) instead." % path, False
        if show is None:
            show = not os.path.exists(flag)
        if show:
            _show_toolbar_group(tf, T)
            try:
                with open(flag, "w") as f:
                    f.write(path)
            except Exception:
                pass
        return path, ("Toolbar 'ALIEF FEA' is loaded (%s). It sits at the top of the Rhino window like the "
                      "Standard / Drafting tabs; if Rhino shows it floating, drag its tab next to 'Drafting' once - "
                      "Rhino remembers the place." % path), True
    except Exception as ex:
        try:
            T.write_rui(root, path)
        except Exception:
            pass
        return path, ("Toolbar file written (%s) but not opened automatically (%s). Open it with Window > Toolbars "
                      "or Tools > Options > Toolbars > File > Open, or use AF_Toolbar." % (path, ex)), False


def add_startup_command(name="AF_Startup"):
    """Add a command to Rhino's 'Run these commands every time Rhino starts' (when RhinoCommon exposes it)."""
    for holder in ("GeneralSettings", "FileSettings"):
        try:
            gs = getattr(Rhino.ApplicationSettings, holder)
            cur = getattr(gs, "StartupCommands")
        except Exception:
            continue
        if not isinstance(cur, str):
            continue
        if name.lower() in cur.lower().split():
            return True
        try:
            setattr(gs, "StartupCommands", (cur.rstrip() + "\n" + name) if cur.strip() else name)
            return True
        except Exception:
            return False
    return False


def show_panel(tab=None):
    p = sc.sticky.get(STICKY)
    if p is not None:
        try:
            p.refresh(True)
            if tab is not None:
                p.tabs.SelectedIndex = tab
            p.form.BringToFront()
            p.form.Focus()
            return p
        except Exception:
            pass
    p = Panel()
    sc.sticky[STICKY] = p
    if tab is not None:
        p.tabs.SelectedIndex = tab
    p.show()
    return p


def refresh_panel():
    p = sc.sticky.get(STICKY)
    if p is not None:
        try:
            p.refresh()
        except Exception:
            pass


# =========================================================================== own profile catalogue
def _catalogue_file():
    return os.path.join(cfg_dir(), "catalogue.json")


def user_catalogue(lib=None):
    """Own catalogue sizes: this computer (AppData) + the ones stored in the model (shared with the team)."""
    d = {}
    try:
        with open(_catalogue_file(), "r", encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    return C.catalogue_merge(d, (lib or {}).get("catalogue"))


def save_user_catalogue(cat, lib=None, replace=False):
    cat = C.clean_catalogue(cat)
    try:
        old = {}
        if not replace:
            with open(_catalogue_file(), "r", encoding="utf-8") as f:
                old = json.load(f)
    except (OSError, ValueError):
        old = {}
    try:
        with open(_catalogue_file(), "w", encoding="utf-8") as f:
            json.dump(cat if replace else C.catalogue_merge(old, cat), f, indent=1)
    except OSError:
        pass
    if lib is not None:
        lib["catalogue"] = cat
    return cat


# =========================================================================== Assign window (STAAD Pro style)
ASSIGN_STICKY = "ALIEF_FEA_ASSIGN_WINDOW"
ASSIGN_KEY = "ALIEF_FEA_ASSIGN"
ASSIGN_METHODS = ["Assign To Selected", "Use Cursor To Assign", "Assign To Layer", "Assign To View"]
PLATE_ROLES = ["Plate", "Shell", "Deck", "Bulkhead", "Web", "Girder", "Floor", "Bracket", "Face plate"]


def checkbox(text, value=False, tip=None):
    c = forms.CheckBox()
    c.Text = text
    c.Checked = bool(value)
    if tip:
        c.ToolTip = tip
    return c


class AssignWindow(object):
    """Property list like STAAD Pro 'Properties - Whole Structure': pick a plate property or a section,
    choose the assignment method and press Assign - many curves, closed curves and surfaces at once."""

    def __init__(self):
        from . import rhinoio as io
        self.io = io
        self.rows = []
        f = forms.Form()
        f.Title = "ALIEF FEA - Properties & Assign"
        f.ClientSize = drawing.Size(470, 640)
        f.MinimumSize = drawing.Size(420, 520)
        f.Resizable = True
        f.Padding = drawing.Padding(8)
        self.form = f
        self.lst = forms.ListBox()
        self.lst.Height = 230
        self.lst.Font = drawing.Font("Consolas", 9)
        self.lst.SelectedIndexChanged += self._selected
        self.lst.MouseDoubleClick += lambda s, e: self._assign(None, None)
        self.dd_method = dropdown(ASSIGN_METHODS)
        self.dd_method.SelectedIndexChanged += self._method_changed
        self.dd_layer = forms.DropDown()
        self.dd_role = dropdown(PLATE_ROLES)
        self.cb_role = checkbox("Also set the member type of existing plates")
        self.cb_keep = checkbox("Keep the input curves (closed curves -> plates)", True)
        self.dd_side = dropdown(C.WEB_SIDES, "+N", C.WEB_SIDE_LABELS)
        self.dd_flange = dropdown(["+1 (normal)", "-1 (mirrored)"])
        self.dd_off = dropdown(["section default"] + C.OFFSET_MODES, "section default",
                               dict(C.OFFSET_LABELS, **{"section default": "section default (auto / pipe: centroid)"}))
        self.cb_side = checkbox("Also apply web side / flange / offset to existing profiles")
        self.info = label("", wrap=True, chars=70)
        self.status = label("Select objects in Rhino (click / window / crossing), choose a property and press Assign.",
                            wrap=True, chars=70)
        pbox = forms.GroupBox()
        pbox.Text = "Plates (closed curves, surfaces, polysurfaces)"
        pbox.Padding = drawing.Padding(6)
        pbox.Content = form_grid([("Member type", self.dd_role), ("", self.cb_role), ("", self.cb_keep)])
        sbox = forms.GroupBox()
        sbox.Text = "Profiles (lines, polylines, curves)"
        sbox.Padding = drawing.Padding(6)
        sbox.Content = form_grid([("Web side", self.dd_side), ("Flange", self.dd_flange), ("Offset", self.dd_off), ("", self.cb_side)])
        mbox = forms.GroupBox()
        mbox.Text = "Assignment method"
        mbox.Padding = drawing.Padding(6)
        mbox.Content = form_grid([("Method", self.dd_method), ("Layer", self.dd_layer)])
        b_assign = button("Assign", self._assign, "af_assign", "Assign the selected property (double-click in the list does the same)")
        b_assign.Size = drawing.Size(120, 34)
        b_sel = button("Select members", self._highlight, None, "Select every member that uses this property")
        b_sel.Size = drawing.Size(120, 34)
        b_new = button("New / edit...", self._edit, None, "Open the panel to add plate properties or sections")
        b_new.Size = drawing.Size(110, 34)
        b_close = button("Close", lambda s, e: self.form.Close())
        b_close.Size = drawing.Size(80, 34)
        lay = forms.DynamicLayout()
        lay.Spacing = drawing.Size(6, 6)
        lay.AddRow(label("Properties - whole structure", True, 10))
        lay.AddRow(label(" Ref  Type     Name                       Material      Used", False, 8))
        add_scaled(lay, self.lst)
        lay.AddRow(self.info)
        lay.AddRow(mbox)
        lay.AddRow(pbox)
        lay.AddRow(sbox)
        lay.AddRow(table([row(b_assign, b_sel, b_new, None, b_close)]))
        lay.AddRow(self.status)
        f.Content = lay
        self._stamp = None
        f.GotFocus += lambda s, e: self.refresh(False)
        f.Closed += self._closed
        self.refresh()

    def _closed(self, sender, e):
        try:
            del sc.sticky[ASSIGN_STICKY]
        except Exception:
            pass

    def show(self):
        self.form.Owner = owner()
        self.form.Show()

    def refresh(self, force=True):
        io = self.io
        stamp = (io._data("library") or "") + "|" + (io._data("settings") or "") + "|" + str(sc.doc.RuntimeSerialNumber)
        if not force and stamp == self._stamp:
            return
        self._stamp = stamp
        lib = io.load_library()
        st = io.load_settings()
        used = {}
        for o in io.af_objects():
            k = (io.af(o, io.K_KIND), io.af(o, io.K_PROP) if io.is_plate(o) else io.af(o, io.K_SEC))
            used[k] = used.get(k, 0) + 1
        keep = self.lst.SelectedIndex
        cur = self.rows[keep] if 0 <= keep < len(self.rows) else None
        self.rows = []
        self.lst.Items.Clear()
        ref = 1
        for p in lib.get("plate_props", []):
            self.rows.append(("plate", p["name"]))
            self.lst.Items.Add("%3d  PLATE    %-26s %-12s %4d" % (ref, p["name"][:26], p["material"][:12], used.get(("plate", p["name"]), 0)))
            ref += 1
        for s_ in lib.get("sections", []):
            self.rows.append(("profile", s_["name"]))
            self.lst.Items.Add("%3d  PROFILE  %-26s %-12s %4d" % (ref, s_["name"][:26], s_["material"][:12], used.get(("profile", s_["name"]), 0)))
            ref += 1
        want = cur or ("plate", st.get("active_prop"))
        if want in self.rows:
            self.lst.SelectedIndex = self.rows.index(want)
        elif self.rows:
            self.lst.SelectedIndex = 0
        layers = sorted(set(sc.doc.Layers[i].FullPath for i in range(int(sc.doc.Layers.Count)) if not sc.doc.Layers[i].IsDeleted))
        cur_l = self.dd_layer.SelectedIndex
        old = self.dd_layer.Items[cur_l].Text if 0 <= cur_l < self.dd_layer.Items.Count else sc.doc.Layers.CurrentLayer.FullPath
        self.dd_layer.Items.Clear()
        for L in layers:
            self.dd_layer.Items.Add(L)
        if old in layers:
            self.dd_layer.SelectedIndex = layers.index(old)
        self._method_changed(None, None)
        self._selected(None, None)

    def _current(self):
        i = self.lst.SelectedIndex
        return self.rows[i] if 0 <= i < len(self.rows) else None

    def _method_changed(self, sender, e):
        self.dd_layer.Enabled = self.dd_method.SelectedIndex == 2

    def _selected(self, sender, e):
        cur = self._current()
        if cur is None:
            self.info.Text = "Add plate properties / sections first (New / edit...)."
            return
        kind, name = cur
        lib = self.io.load_library()
        mats, props, secs = C.library_index(lib)
        if kind == "plate":
            p = props.get(name, {})
            self.info.Text = wrap_text("PLATE  %s  -  t = %g mm, %s%s.  Closed curves and surfaces become plates; existing "
                                       "plates get this property." % (name, p.get("thickness", 0), p.get("material", "?"),
                                                                       (", tc %g" % p["tc"]) if p.get("tc") else ""), 70)
        else:
            s_ = secs.get(name, {})
            try:
                pr = C.section_properties(s_["stype"], s_["dims"])
                extra = "A = %.1f cm2, Iy = %.4g cm4, %.1f kg/m" % (pr["A"] / 100.0, pr["Iy"] / 1e4, pr["mass"])
            except Exception:
                extra = ""
            self.info.Text = wrap_text("PROFILE  %s  (%s)  -  %s.  Lines / curves become profiles; existing profiles get this "
                                       "section." % (name, s_.get("material", "?"), extra), 70)

    def _request(self):
        cur = self._current()
        if cur is None:
            return None
        kind, name = cur
        i = self.dd_method.SelectedIndex
        j = self.dd_layer.SelectedIndex
        return dict(kind=kind, name=name, method=ASSIGN_METHODS[i if 0 <= i < 4 else 0],
                    layer=self.dd_layer.Items[j].Text if 0 <= j < self.dd_layer.Items.Count else "",
                    role=PLATE_ROLES[max(self.dd_role.SelectedIndex, 0)], set_role=bool(self.cb_role.Checked),
                    keep=bool(self.cb_keep.Checked), side=C.WEB_SIDES[max(self.dd_side.SelectedIndex, 0)],
                    flange=1 if self.dd_flange.SelectedIndex <= 0 else -1,
                    offset=(["section default"] + C.OFFSET_MODES)[max(self.dd_off.SelectedIndex, 0)],
                    apply_side=bool(self.cb_side.Checked))

    def _assign(self, sender, e):
        req = self._request()
        if req is None:
            message("Choose a plate property or a section in the list.")
            return
        sc.sticky[ASSIGN_KEY] = req
        self.status.Text = wrap_text("Assigning %s (%s) ..." % (req["name"], req["method"]), 70)
        run_command("AF_AssignNow")

    def _highlight(self, sender, e):
        cur = self._current()
        if cur is None:
            return
        kind, name = cur
        io = self.io
        key = io.K_PROP if kind == "plate" else io.K_SEC
        ids = [o.Id for o in io.af_objects(kind) if io.af(o, key) == name]
        sc.doc.Objects.UnselectAll()
        n = 0
        for i in ids:
            if sc.doc.Objects.Select(i, True):
                n += 1
        sc.doc.Views.Redraw()
        self.status.Text = "%d member(s) use %s (selected)." % (n, name)

    def _edit(self, sender, e):
        cur = self._current()
        show_panel(2 if cur and cur[0] == "profile" else 1)


def show_assign():
    w = sc.sticky.get(ASSIGN_STICKY)
    if w is not None:
        try:
            w.refresh()
            w.form.BringToFront()
            w.form.Focus()
            return w
        except Exception:
            pass
    w = AssignWindow()
    sc.sticky[ASSIGN_STICKY] = w
    w.show()
    return w
