"""Rhino toolbar (.rui) for ALIEF FEA MODELER - written by the installer with the real folder paths.

Pure Python (no Rhino imports) so it can be tested outside Rhino. Icon strips (one row, one cell per
macro, same order as MACROS) are pre-rendered in icons/strip_16.png, strip_24.png, strip_32.png."""
import base64
import os
import uuid
from xml.sax.saxutils import escape, quoteattr

NS = uuid.UUID("6f1c2b9e-4a7d-4c1e-9a55-2f3e8d0b7a11")
GROUP_NAME = "ALIEF FEA"
TOOLBAR_NAME = "ALIEF FEA"
# new group id in 1.0.3: Rhino 8 turns a .rui toolbar group into a container only the first time it sees
# the group, so a new id makes Rhino create the (top docked) container again on machines that ran 1.0.1/1.0.2
GROUP_SEED = "group-v103"

# (script, icon, button text, tooltip) ; None = spacer between groups
ITEMS = [
    ("AF_Panel", "af_logo", "Panel", "ALIEF FEA panel - libraries, active properties, export, team"),
    None,
    ("AF_Plate", "af_plate", "Plate", "Plate from closed planar curves (inner curves = openings)"),
    ("AF_SurfaceToPlate", "af_srf2plate", "Srf>Plate", "Surfaces / polysurfaces (also curved shell) become plates"),
    ("AF_Web", "af_web", "Web", "Web / girder / floor with face plate or edge profile"),
    ("AF_Profile", "af_profile", "Profile", "Curves become profiles (section, web side, flange, offset)"),
    ("AF_Stiffeners", "af_stiffeners", "Stiffeners", "Stiffeners across plates at a spacing / count / positions"),
    ("AF_Bracket", "af_bracket", "Bracket", "Bracket: click two members (profile / plate) and it is made at once"),
    ("AF_Opening", "af_opening", "Opening", "Opening in a plate: manhole, rectangle, circle, any curve"),
    ("AF_FacePlate", "af_faceplate", "Face plate", "Face plate on the free edge of a web or bracket"),
    None,
    ("AF_Assign", "af_assign", "Assign", "Properties & Assign window (like STAAD Pro): one property to many objects at once"),
    ("AF_FlipSide", "af_flipside", "Flip web", "Put the profile web on the other side of the plating"),
    ("AF_FlipFlange", "af_flipflange", "Flip flange", "Mirror the flange of L / bulb / channel profiles"),
    ("AF_Info", "af_info", "Info", "Show and edit the FEA data of members"),
    None,
    ("AF_Check", "af_check", "Check", "Model check: properties, planarity, gaps between plates"),
    ("AF_Color", "af_color", "Colour", "Colour members by property, material, thickness or layer"),
    ("AF_3DView", "af_3dview", "3D View", "3D View on / off - real plate thickness and profile sections, always up to date"),
    ("AF_Legend", "af_legend", "Index", "Property index on screen on / off (colours, counts, weights)"),
    None,
    ("AF_MTO", "af_mto", "MTO", "Material take-off with weights (CSV)"),
    ("AF_Sync", "af_sync", "Team sync", "Team sync: publish your zone, load the zones of the team"),
    ("AF_Export", "af_export", "Export", "Export to ALIEF FEAPRO (.alfea)"),
    ("AF_Import", "af_import", "Import", "Open an ALIEF FEAPRO project in Rhino"),
    None,
    ("AF_Update", "af_update", "Update", "Check for a new version on the internet and install it"),
]
MACROS = [it for it in ITEMS if it is not None]
SIZES = (16, 24, 32)


def gid(name):
    return str(uuid.uuid5(NS, name))


def _bar_width():
    return 28 * len(MACROS) + 10 * (len(ITEMS) - len(MACROS)) + 24


def macro_script(root, script):
    return '! _-RunPythonScript "%s"' % os.path.join(root, "commands", script + ".py")


def _txt(tag, value, indent):
    return '%s<%s>\n%s  <locale_1033>%s</locale_1033>\n%s</%s>\n' % (indent, tag, indent, escape(value), indent, tag)


def build_rui(root, icon_dir=None):
    icon_dir = icon_dir or os.path.join(root, "alief_fea", "icons")
    tb = gid("toolbar")
    grp = gid(GROUP_SEED)
    grp_item = gid(GROUP_SEED + "-item")
    out = ['<?xml version="1.0" encoding="utf-8"?>\n',
           '<RhinoUI major_ver="3" minor_ver="0" guid="%s" localize="False" default_language_id="1033" dpi_scale="100">\n' % gid("rui"),
           '  <extend_rhino_menus>\n    <menu guid="%s">\n' % gid("menu"),
           _txt("text", "Extend Rhino Menus", "      "),
           '    </menu>\n  </extend_rhino_menus>\n  <menus />\n  <tool_bar_groups>\n',
           ('    <tool_bar_group guid="%s" dock_bar_guid32="00000000-0000-0000-0000-000000000000" dock_bar_guid64="%s" '
            'active_tool_bar_group="%s" single_file="False" hide_single_tab="False" point_floating="320,160">\n') % (grp, gid("dock"), grp_item),
           _txt("text", GROUP_NAME, "      "),
           '      <tool_bar_group_item guid="%s" major_version="1" minor_version="1">\n' % grp_item,
           _txt("text", TOOLBAR_NAME, "        "),
           '        <tool_bar_id>%s</tool_bar_id>\n      </tool_bar_group_item>\n' % tb,
           # docked at the top edge of the Rhino window, like the Standard / Drafting tabs
           ('      <dock_bar_info dpi_scale="100" dock_bar="False" docking="True" horz="True" visible="True" floating="False" '
            'mru_float_style="8192" bar_id="59661" mru_width="%d" point_pos="-2,-2" float_point="320,160" '
            'rect_mru_dock_pos="0,0,%d,64" dock_location_u="59419" dock_location="top" float_size="%d,64" />\n')
           % (_bar_width(), _bar_width(), _bar_width()),
           '    </tool_bar_group>\n  </tool_bar_groups>\n  <tool_bars>\n',
           '    <tool_bar guid="%s" item_display_style="control_only">\n' % tb,
           _txt("text", TOOLBAR_NAME, "      ")]
    sp = 0
    for it in ITEMS:
        if it is None:
            sp += 1
            out.append('      <tool_bar_item guid="%s" button_style="spacer" />\n' % gid("spacer%d" % sp))
        else:
            out.append('      <tool_bar_item guid="%s" button_display_mode="control_only" button_style="normal">\n'
                       '        <left_macro_id>%s</left_macro_id>\n      </tool_bar_item>\n'
                       % (gid("item-" + it[0]), gid("macro-" + it[0])))
    out.append('    </tool_bar>\n  </tool_bars>\n  <macros>\n')
    for script, ico, text, tip in MACROS:
        out.append('    <macro_item guid="%s" bitmap_id="%s">\n' % (gid("macro-" + script), gid("bmp-" + script)))
        out.append(_txt("text", script, "      "))
        out.append(_txt("tooltip", "%s - %s" % (script, tip), "      "))
        out.append(_txt("help_text", tip, "      "))
        out.append(_txt("button_text", text, "      "))
        out.append(_txt("menu_text", text, "      "))
        out.append('      <script>%s</script>\n' % escape(macro_script(root, script), {'"': "&quot;"}))
        out.append('    </macro_item>\n')
    out.append('  </macros>\n  <bitmaps>\n')
    for size, tag in zip(SIZES, ("small_bitmap", "normal_bitmap", "large_bitmap")):
        path = os.path.join(icon_dir, "strip_%d.png" % size)
        if not os.path.exists(path):
            continue
        with open(path, "rb") as f:
            data = base64.encodebytes(f.read()).decode("ascii").strip()
        out.append('    <%s item_width="%d" item_height="%d">\n' % (tag, size, size))
        for k, m in enumerate(MACROS):
            out.append('      <bitmap_item guid="%s" index="%d" />\n' % (gid("bmp-" + m[0]), k))
        out.append('      <bitmap>%s</bitmap>\n' % data)
        out.append('    </%s>\n' % tag)
    out.append('  </bitmaps>\n</RhinoUI>\n')
    return "".join(out)


def write_rui(root, path=None):
    path = path or os.path.join(root, "ALIEF_FEA.rui")
    with open(path, "w", encoding="utf-8") as f:
        f.write(build_rui(root))
    return path


def rui_text_changed(root, path=None):
    """True when the .rui on disk differs from what this version would write."""
    path = path or os.path.join(root, "ALIEF_FEA.rui")
    try:
        with open(path, encoding="utf-8") as f:
            return f.read() != build_rui(root)
    except OSError:
        return True


__all__ = ["ITEMS", "MACROS", "GROUP_NAME", "TOOLBAR_NAME", "build_rui", "write_rui", "rui_text_changed", "quoteattr"]
