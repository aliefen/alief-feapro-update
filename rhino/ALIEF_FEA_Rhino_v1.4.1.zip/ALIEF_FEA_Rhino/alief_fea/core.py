"""ALIEF FEA MODELER for Rhino - core library (pure Python, no Rhino imports).

PT. Alief Energy Utama - Naval Architect & Marine Engineer Consultant, Batam.

Everything that does not need RhinoCommon lives here so it behaves the same
inside Rhino 8 (CPython 3) and in the test bench:

  * ALIEF FEAPRO conventions copied 1:1 - material library (IACS UR W11 grades,
    aluminium, stainless), profile catalogue and section rules (FB, L, T, H, C,
    BP/HP, PIPE, RB, GEN with the same dimension keys and names), plate frame,
    opening types (circle / rect / slot / poly)
  * conformal facetting helpers for curved plating (profiles walked across the
    facets, planar plates re-edged on the facet vertices)
  * opening classification, model check, material take-off
  * writer / reader for the ALIEF FEAPRO project file (.alfea, JSON)

Units: mm, N, MPa, kg/m3 (as ALIEF FEAPRO).
"""
import json
import os
import math

APP = "ALIEF FEA MODELER"
VERSION = "1.4.1"
FEAPRO_FORMAT = "ALIEF_FEAPRO"
FILE_EXT = ".alfea"
COMPANY = "PT. Alief Energy Utama"

EPS = 1e-9


# =========================================================================== vectors
def v_add(a, b):
    return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]


def v_sub(a, b):
    return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]


def v_mul(a, s):
    return [a[0] * s, a[1] * s, a[2] * s]


def v_dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def v_cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def v_len(a):
    return math.sqrt(v_dot(a, a))


def v_unit(a, default=None):
    n = v_len(a)
    if n < 1e-15:
        return list(default) if default is not None else [0.0, 0.0, 0.0]
    return [a[0] / n, a[1] / n, a[2] / n]


def v_dist(a, b):
    return v_len(v_sub(a, b))


def v_lerp(a, b, t):
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]


def v_round(a, nd=4):
    return [round(float(x), nd) for x in a]


def argmax_abs(a):
    m, k = -1.0, 0
    for i, x in enumerate(a):
        if abs(x) > m:
            m, k = abs(x), i
    return k


AXES = {"+X": [1.0, 0.0, 0.0], "-X": [-1.0, 0.0, 0.0], "+Y": [0.0, 1.0, 0.0],
        "-Y": [0.0, -1.0, 0.0], "+Z": [0.0, 0.0, 1.0], "-Z": [0.0, 0.0, -1.0]}


def axis_name(v):
    best, nm = -2.0, "+Z"
    for k, a in AXES.items():
        d = v_dot(v_unit(v, [0, 0, 1]), a)
        if d > best:
            best, nm = d, k
    return nm


def hex2rgb(h, default=(160, 180, 200)):
    try:
        h = h.lstrip("#")
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    except Exception:
        return default


def rgb2hex(c):
    return "#%02X%02X%02X" % (int(c[0]), int(c[1]), int(c[2]))


# =========================================================================== materials
# identical to ALIEF FEAPRO core/materials.py
_STEEL = [
    ("Grade A", 235, 400, "#8FB3D9"), ("Grade B", 235, 400, "#86A9CF"),
    ("Grade D", 235, 400, "#7C9FC6"), ("Grade E", 235, 400, "#7295BC"),
    ("AH32", 315, 440, "#7FC8A9"), ("DH32", 315, 440, "#6FBB9A"),
    ("EH32", 315, 440, "#5FAE8B"), ("FH32", 315, 440, "#4FA17C"),
    ("AH36", 355, 490, "#F2C14E"), ("DH36", 355, 490, "#E9B23F"),
    ("EH36", 355, 490, "#E0A330"), ("FH36", 355, 490, "#D79421"),
    ("AH40", 390, 510, "#E07A5F"), ("DH40", 390, 510, "#D66B50"),
    ("EH40", 390, 510, "#CC5C41"), ("FH40", 390, 510, "#C24D32"),
]

MATERIAL_FIELDS = ["name", "category", "E", "nu", "density", "ReH", "Rm", "k", "standard", "color", "note"]


def k_factor(ReH, rule="IACS"):
    """Material factor k. rule = 'IACS' (CSR table) or 'BKI' (295/(ReH+60))."""
    if ReH <= 235.0:
        return 1.0
    if rule.upper() == "BKI":
        return round(295.0 / (ReH + 60.0), 2)
    for r, k in [(315.0, 0.78), (355.0, 0.72), (390.0, 0.68), (460.0, 0.62)]:
        if abs(ReH - r) < 1.0:
            return k
    return round(295.0 / (ReH + 60.0), 2)


def material(name, category="Steel", E=206000.0, nu=0.3, density=7850.0, ReH=235.0, Rm=400.0,
             k=1.0, standard="IACS UR W11", color="#7FA7C9", note=""):
    return dict(name=name, category=category, E=float(E), nu=float(nu), density=float(density),
                ReH=float(ReH), Rm=float(Rm), k=float(k), standard=standard, color=color, note=note)


def material_library():
    """All built-in materials of ALIEF FEAPRO (ordered dict name -> material dict)."""
    lib = {}
    for name, reh, rm, col in _STEEL:
        lib[name] = material(name, "Steel", 206000.0, 0.3, 7850.0, reh, rm, k_factor(reh),
                             "IACS UR W11", col, "Hull structural steel")
    lib["SS400 / A36"] = material("SS400 / A36", "Steel", 206000.0, 0.3, 7850.0, 245.0, 400.0, 1.0,
                                  "JIS G3101 / ASTM A36", "#A3B8CC", "Structural steel (non-hull)")
    lib["AL 5083-H111"] = material("AL 5083-H111", "Aluminium", 70000.0, 0.33, 2660.0, 125.0, 275.0, 1.0,
                                   "EN 573 / class rules", "#C9D6DF", "Unwelded; check HAZ values")
    lib["AL 5083-H321"] = material("AL 5083-H321", "Aluminium", 70000.0, 0.33, 2660.0, 215.0, 305.0, 1.0,
                                   "EN 573 / class rules", "#B8C9D4", "Unwelded; welded Rp0.2 = 125 MPa")
    lib["AL 6082-T6"] = material("AL 6082-T6", "Aluminium", 70000.0, 0.33, 2700.0, 250.0, 290.0, 1.0,
                                 "EN 755 / class rules", "#A9BCC9", "Extrusions; unwelded")
    lib["AL 6061-T6"] = material("AL 6061-T6", "Aluminium", 69000.0, 0.33, 2700.0, 240.0, 260.0, 1.0,
                                 "EN 755 / class rules", "#9AAFBD", "Extrusions; unwelded")
    lib["SS 316L"] = material("SS 316L", "Stainless", 200000.0, 0.3, 8000.0, 220.0, 520.0, 1.0,
                              "EN 10088-2", "#D5D8DC", "Austenitic stainless")
    return lib


def clean_material(d):
    out = material(d.get("name", "Custom"))
    for k in MATERIAL_FIELDS:
        if k in d and d[k] is not None:
            out[k] = d[k]
    for k in ("E", "nu", "density", "ReH", "Rm", "k"):
        out[k] = float(out[k])
    return out


# =========================================================================== sections
# identical to ALIEF FEAPRO core/sections.py (catalogue, dimension keys, names, rules)
# HP bulb flats: (h, t, A cm2, e cm (centroid from toe), Ix cm4)
HP_TABLE = [
    (60, 4, 3.58, 3.82, 12.2), (60, 5, 4.18, 3.70, 14.4), (60, 6, 4.78, 3.62, 16.4),
    (80, 5, 5.41, 4.90, 33.87), (80, 6, 6.21, 4.78, 38.7), (80, 7, 7.00, 4.69, 43.3),
    (100, 6, 7.74, 5.99, 76.8), (100, 7, 8.74, 5.87, 85.3), (100, 8, 9.74, 5.78, 94.3),
    (120, 6, 9.32, 7.21, 133), (120, 7, 10.52, 7.07, 149), (120, 8, 11.72, 6.96, 165),
    (140, 7, 12.43, 8.32, 241), (140, 8, 13.83, 8.18, 266), (140, 9, 15.20, 8.07, 291),
    (140, 10, 16.63, 7.99, 315),
    (160, 7, 14.60, 9.66, 373), (160, 8, 16.20, 9.50, 411), (160, 9, 17.80, 9.37, 449),
    (180, 8, 18.86, 10.89, 609), (180, 9, 20.66, 10.73, 664), (180, 10, 22.46, 10.59, 717),
    (180, 11, 24.26, 10.47, 770),
    (200, 9, 23.66, 12.12, 942), (200, 10, 25.66, 11.96, 1017), (200, 11, 27.66, 11.82, 1091),
    (200, 11.5, 28.60, 11.70, 1126), (200, 12, 29.66, 11.69, 1164),
    (220, 10, 29.00, 13.35, 1396), (220, 11, 31.20, 13.19, 1496), (220, 11.5, 32.30, 13.10, 1550),
    (220, 12, 33.40, 13.04, 1595),
    (240, 10, 32.49, 14.77, 1865), (240, 11, 34.89, 14.58, 1997), (240, 12, 37.29, 14.42, 2127),
    (260, 10, 36.11, 16.22, 2434), (260, 11, 38.71, 16.00, 2605), (260, 12, 41.31, 15.81, 2774),
    (280, 11, 42.68, 17.44, 3333), (280, 12, 45.48, 17.23, 3647), (280, 13, 48.28, 17.04, 3757),
    (300, 11, 46.78, 18.90, 4192), (300, 12, 49.79, 18.70, 4459), (300, 13, 52.79, 18.45, 4722),
    (320, 12, 54.25, 20.12, 5525), (320, 13, 57.45, 19.89, 5849), (320, 14, 60.85, 19.68, 6168),
    (340, 12, 58.84, 21.69, 6757), (340, 13, 62.24, 21.34, 7152), (340, 14, 65.54, 21.10, 7540),
    (370, 13, 69.70, 23.54, 9469), (370, 14, 73.40, 23.29, 9980), (370, 15, 77.10, 23.06, 10483),
    (400, 14, 81.48, 25.49, 12924), (400, 15, 85.48, 25.24, 13573), (400, 16, 89.48, 25.00, 14211),
    (430, 14, 89.70, 27.70, 16460), (430, 15, 94.19, 27.46, 17249), (430, 17, 102.79, 26.95, 18853),
    (430, 19, 111.39, 26.53, 20413), (430, 20, 115.00, 26.30, 21180),
]

CATALOGUE = {
    "FB": [dict(h=h, t=t) for h, t in [
        (50, 6), (50, 8), (65, 6), (65, 8), (75, 6), (75, 8), (75, 10), (90, 8), (100, 8),
        (100, 10), (100, 12), (125, 10), (125, 12), (150, 10), (150, 12), (150, 15),
        (180, 12), (200, 10), (200, 12), (200, 15), (250, 12), (250, 15), (300, 12),
        (300, 15), (350, 15), (400, 15), (400, 20)]],
    "L": [dict(h=h, b=b, tw=tw, tf=tf) for h, b, tw, tf in [
        (50, 50, 5, 5), (50, 50, 6, 6), (60, 60, 5, 5), (60, 60, 6, 6), (65, 65, 6, 6),
        (65, 65, 8, 8), (75, 75, 6, 6), (75, 75, 9, 9), (90, 90, 7, 7), (90, 90, 10, 10),
        (100, 100, 7, 7), (100, 100, 10, 10), (100, 100, 13, 13), (120, 120, 8, 8),
        (130, 130, 9, 9), (130, 130, 12, 12), (150, 150, 12, 12), (150, 150, 15, 15),
        (90, 75, 9, 9), (100, 75, 7, 7), (100, 75, 10, 10), (125, 75, 7, 7),
        (125, 75, 10, 10), (125, 90, 10, 10), (150, 90, 9, 9), (150, 90, 12, 12),
        (150, 100, 9, 9), (150, 100, 12, 12), (200, 90, 9, 14), (250, 90, 10, 15),
        (250, 90, 12, 16), (300, 90, 11, 16), (300, 90, 13, 17), (350, 100, 12, 17),
        (400, 100, 13, 18)]],
    "T": [dict(hw=hw, tw=tw, bf=bf, tf=tf) for hw, tw, bf, tf in [
        (150, 8, 75, 8), (200, 8, 80, 10), (200, 10, 100, 10), (250, 9, 100, 12),
        (250, 10, 100, 12), (300, 10, 100, 12), (300, 10, 120, 12), (350, 10, 120, 12),
        (400, 10, 150, 12), (400, 12, 150, 15), (450, 12, 150, 15), (500, 12, 150, 15),
        (500, 12, 200, 15), (600, 12, 200, 15), (600, 14, 200, 18), (700, 14, 250, 18),
        (800, 14, 250, 20), (1000, 14, 300, 20)]],
    "H": [dict(h=h, b=b, tw=tw, tf=tf) for h, b, tw, tf in [
        (100, 100, 6, 8), (125, 125, 6.5, 9), (150, 75, 5, 7), (150, 150, 7, 10),
        (175, 90, 5, 8), (175, 175, 7.5, 11), (200, 100, 5.5, 8), (200, 200, 8, 12),
        (250, 125, 6, 9), (250, 250, 9, 14), (300, 150, 6.5, 9), (300, 300, 10, 15),
        (350, 175, 7, 11), (350, 350, 12, 19), (400, 200, 8, 13), (400, 400, 13, 21),
        (450, 200, 9, 14), (500, 200, 10, 16), (600, 200, 11, 17), (700, 300, 13, 24),
        (800, 300, 14, 26), (900, 300, 16, 28)]],
    "C": [dict(h=h, b=b, tw=tw, tf=tf) for h, b, tw, tf in [
        (75, 40, 5, 7), (100, 50, 5, 7.5), (125, 65, 6, 8), (150, 75, 6.5, 10),
        (150, 75, 9, 12.5), (180, 75, 7, 10.5), (200, 80, 7.5, 11), (200, 90, 8, 13.5),
        (250, 90, 9, 13), (250, 90, 11, 14.5), (300, 90, 9, 13), (300, 90, 10, 15.5),
        (300, 90, 12, 16), (380, 100, 10.5, 16), (380, 100, 13, 20)]],
    "BP": [dict(h=r[0], t=r[1]) for r in HP_TABLE],
    "PIPE": [dict(D=D, t=t) for D, ts in [
        (21.7, (2.8, 3.7)), (27.2, (2.9, 3.9)), (34.0, (3.4, 4.5)), (42.7, (3.6, 4.9)),
        (48.6, (3.7, 5.1)), (60.5, (3.9, 5.5)), (76.3, (5.2, 7.0)), (89.1, (5.5, 7.6)),
        (114.3, (6.0, 8.6)), (139.8, (6.6, 9.5)), (165.2, (7.1, 11.0)),
        (216.3, (8.2, 12.7)), (267.4, (9.3, 15.1)), (318.5, (10.3, 17.4))] for t in ts],
    "RB": [dict(D=D) for D in [10, 12, 16, 19, 20, 22, 25, 28, 30, 32, 36, 40, 45, 50,
                                60, 70, 80, 90, 100]],
    "GEN": [],
}

TYPE_ORDER = ["FB", "L", "T", "H", "C", "BP", "PIPE", "RB", "GEN"]
TYPE_LABELS = {
    "FB": "Flat bar (FB)", "L": "Angle (L, equal / unequal)", "T": "Tee built-up (T)",
    "H": "H-beam / I-beam (H)", "C": "Channel (C / UNP)", "BP": "Bulb flat (BP / HP)",
    "PIPE": "Pipe (CHS)", "RB": "Round bar (RB)", "GEN": "General - manual properties",
}

DIM_FIELDS = {
    "FB": [("h", "Height h"), ("t", "Thickness t")],
    "L": [("h", "Web height h"), ("b", "Flange width b"), ("tw", "Web thk tw"), ("tf", "Flange thk tf")],
    "T": [("hw", "Web height hw"), ("tw", "Web thk tw"), ("bf", "Flange width bf"), ("tf", "Flange thk tf")],
    "H": [("h", "Depth h"), ("b", "Flange width b"), ("tw", "Web thk tw"), ("tf", "Flange thk tf")],
    "C": [("h", "Depth h"), ("b", "Flange width b"), ("tw", "Web thk tw"), ("tf", "Flange thk tf")],
    "BP": [("h", "Height h"), ("t", "Web thk t")],
    "PIPE": [("D", "Outside dia. D"), ("t", "Wall thk t")],
    "RB": [("D", "Diameter D")],
    "GEN": [("h", "Total height h"), ("A", "Area A [mm2]"), ("Iy", "Iy strong [mm4]"),
            ("Iz", "Iz weak [mm4]"), ("J", "Torsion J [mm4]"), ("zc", "Centroid z from toe")],
}

SECTION_PALETTE = ["#C9A227", "#13795B", "#14365D", "#B5523B", "#6A4C93", "#2E86AB",
                   "#8D6E63", "#D17B0F", "#4E8D3A", "#A23B72", "#3D5A80", "#7A9E9F"]


def fmt(v):
    return "%g" % v


def section_label(stype, d):
    """Section name exactly as ALIEF FEAPRO names it."""
    if stype == "FB":
        return "FB %sx%s" % (fmt(d["h"]), fmt(d["t"]))
    if stype == "L":
        if abs(d["tw"] - d["tf"]) < 1e-9:
            return "L %sx%sx%s" % (fmt(d["h"]), fmt(d["b"]), fmt(d["tw"]))
        return "L %sx%sx%s/%s" % (fmt(d["h"]), fmt(d["b"]), fmt(d["tw"]), fmt(d["tf"]))
    if stype == "T":
        return "T %sx%s / %sx%s" % (fmt(d["hw"]), fmt(d["tw"]), fmt(d["bf"]), fmt(d["tf"]))
    if stype in ("H", "C"):
        return "%s %sx%sx%sx%s" % (stype, fmt(d["h"]), fmt(d["b"]), fmt(d["tw"]), fmt(d["tf"]))
    if stype == "BP":
        return "HP %sx%s" % (fmt(d["h"]), fmt(d["t"]))
    if stype == "PIPE":
        return "PIPE %sx%s" % (fmt(d["D"]), fmt(d["t"]))
    if stype == "RB":
        return "RB %s" % fmt(d["D"])
    return "GEN h=%s" % fmt(d.get("h", 0))


def catalogue_labels(stype):
    return [section_label(stype, d) for d in CATALOGUE.get(stype, [])]


def hp_lookup(h, t):
    for r in HP_TABLE:
        if abs(r[0] - h) < 1e-6 and abs(r[1] - t) < 1e-6:
            return r
    return None


def normalise_dims(stype, dims):
    d = {k: float(v) for k, v in dims.items()}
    if stype == "L" and "tf" not in d:
        d["tf"] = d.get("tw", d.get("t", 8.0))
    for k, _ in DIM_FIELDS.get(stype, []):
        d.setdefault(k, 0.0)
    return d


def check_dims(stype, dims):
    """Return an error message or '' when the dimensions are usable."""
    if stype not in DIM_FIELDS:
        return "Unknown profile type %s" % stype
    for k, lab in DIM_FIELDS[stype]:
        if dims.get(k, 0.0) <= 0.0 and not (stype == "GEN" and k == "zc"):
            return "%s must be greater than zero" % lab
    d = dims
    if stype in ("H", "C") and 2 * d["tf"] >= d["h"]:
        return "Flange thickness too large for the depth"
    if stype == "L" and d["tf"] >= d["h"]:
        return "Flange thickness must be smaller than the web height"
    if stype == "PIPE" and 2 * d["t"] >= d["D"]:
        return "Wall thickness too large for the diameter"
    return ""


def section_shapes(stype, d):
    """Primitive shapes ('R', y0, z0, w, h) / ('O', yc, zc, ro, ri) - section axes of ALIEF FEAPRO:
    z along the web from the attachment face (toe, z = 0) towards the free flange, y across."""
    s = stype
    if s == "FB":
        return [("R", -d["t"] / 2, 0.0, d["t"], d["h"])]
    if s == "L":
        return [("R", -d["tw"] / 2, 0.0, d["tw"], d["h"] - d["tf"]),
                ("R", -d["tw"] / 2, d["h"] - d["tf"], d["b"], d["tf"])]
    if s == "T":
        return [("R", -d["tw"] / 2, 0.0, d["tw"], d["hw"]),
                ("R", -d["bf"] / 2, d["hw"], d["bf"], d["tf"])]
    if s == "H":
        return [("R", -d["b"] / 2, 0.0, d["b"], d["tf"]),
                ("R", -d["tw"] / 2, d["tf"], d["tw"], d["h"] - 2 * d["tf"]),
                ("R", -d["b"] / 2, d["h"] - d["tf"], d["b"], d["tf"])]
    if s == "C":
        return [("R", -d["tw"] / 2, 0.0, d["b"], d["tf"]),
                ("R", -d["tw"] / 2, d["tf"], d["tw"], d["h"] - 2 * d["tf"]),
                ("R", -d["tw"] / 2, d["h"] - d["tf"], d["b"], d["tf"])]
    if s == "BP":
        h, t = d["h"], d["t"]
        hw = h - h / 9.2 + 2.0
        tf = h / 9.2 - 2.0
        alpha = 1.1 + (120.0 - h) ** 2 / 3000.0 if h <= 120 else 1.0
        bf = alpha * (t + h / 6.7 - 2.0)
        return [("R", -t / 2, 0.0, t, hw), ("R", -t / 2, hw, bf, tf)]
    if s == "PIPE":
        D, t = d["D"], d["t"]
        return [("O", 0.0, D / 2, D / 2, max(D / 2 - t, 0.0))]
    if s == "RB":
        D = d["D"]
        return [("O", 0.0, D / 2, D / 2, 0.0)]
    h = d.get("h", 100.0)
    A = d.get("A", 1000.0)
    return [("R", -A / h / 2, 0.0, A / h, h)]


def section_height(stype, d):
    zmax = 0.0
    for sh in section_shapes(stype, d):
        zmax = max(zmax, sh[2] + sh[4]) if sh[0] == "R" else max(zmax, sh[2] + sh[3])
    return zmax


def section_outlines(stype, d, ncirc=24):
    """List of closed outlines [(y, z), ...] (annulus -> outer and inner ring)."""
    out = []
    for sh in section_shapes(stype, d):
        if sh[0] == "R":
            _, y0, z0, w, h = sh
            out.append([(y0, z0), (y0 + w, z0), (y0 + w, z0 + h), (y0, z0 + h)])
        else:
            _, yc, zc, ro, ri = sh
            out.append([(yc + ro * math.cos(2 * math.pi * i / ncirc), zc + ro * math.sin(2 * math.pi * i / ncirc))
                        for i in range(ncirc)])
            if ri > 0:
                out.append([(yc + ri * math.cos(2 * math.pi * i / ncirc), zc + ri * math.sin(2 * math.pi * i / ncirc))
                            for i in range(ncirc)])
    return out


def section_properties(stype, d):
    """A, yc, zc, Iy (strong), Iz, Iyz, J, h, Wtop, Wbot, Wmin, mass (kg/m steel) - same as ALIEF FEAPRO."""
    if stype == "GEN":
        h = d.get("h", 100.0)
        A = d.get("A", 1000.0)
        Iy = d.get("Iy", A * h * h / 12)
        Iz = d.get("Iz", Iy * 0.05)
        J = d.get("J", Iz * 0.1)
        zc = d.get("zc", h / 2) or h / 2
        p = dict(A=A, yc=0.0, zc=zc, Iy=Iy, Iz=Iz, Iyz=0.0, J=J, h=h, source="Typed manually")
        return _finish(p)
    prim = section_shapes(stype, d)
    A = Sy = Sz = 0.0
    for sh in prim:
        if sh[0] == "R":
            _, y0, z0, w, h = sh
            a = w * h
            A += a
            Sy += a * (y0 + w / 2)
            Sz += a * (z0 + h / 2)
        else:
            _, yc, zc, ro, ri = sh
            a = math.pi * (ro ** 2 - ri ** 2)
            A += a
            Sy += a * yc
            Sz += a * zc
    yc = Sy / A
    zc = Sz / A
    Iy = Iz = Iyz = J = 0.0
    for sh in prim:
        if sh[0] == "R":
            _, y0, z0, w, h = sh
            a = w * h
            cy, cz = y0 + w / 2 - yc, z0 + h / 2 - zc
            Iy += w * h ** 3 / 12 + a * cz ** 2
            Iz += h * w ** 3 / 12 + a * cy ** 2
            Iyz += a * cy * cz
            b, t = max(w, h), min(w, h)
            J += b * t ** 3 * (1.0 / 3.0 - 0.21 * (t / b) * (1 - t ** 4 / (12 * b ** 4)))
        else:
            _, ycc, zcc, ro, ri = sh
            a = math.pi * (ro ** 2 - ri ** 2)
            I0 = math.pi / 4 * (ro ** 4 - ri ** 4)
            Iy += I0 + a * (zcc - zc) ** 2
            Iz += I0 + a * (ycc - yc) ** 2
            J += math.pi / 2 * (ro ** 4 - ri ** 4)
    p = dict(A=A, yc=yc, zc=zc, Iy=Iy, Iz=Iz, Iyz=Iyz, J=J, h=section_height(stype, d),
             source="Computed from geometry")
    if stype == "BP":
        r = hp_lookup(d["h"], d["t"])
        if r:
            p["A"] = r[2] * 100.0
            p["zc"] = r[3] * 10.0
            p["Iy"] = r[4] * 1e4
            p["source"] = "HP catalogue (EN 10067)"
    return _finish(p)


def _finish(p):
    h = p["h"]
    p["Wtop"] = p["Iy"] / max(h - p["zc"], 1e-9)
    p["Wbot"] = p["Iy"] / max(p["zc"], 1e-9)
    p["Wmin"] = min(p["Wtop"], p["Wbot"])
    p["mass"] = p["A"] * 1e-6 * 7850.0
    return p


def make_section(stype, dims, material="Grade A", name=None, tc=0.0, color=None):
    d = normalise_dims(stype, dims)
    return dict(name=name or section_label(stype, d), stype=stype, dims=d, material=material,
                tc=float(tc), color=color or "#C9A227")


def default_offset(stype):
    """Pillars / rods are modelled on their centre line, everything else on the plating."""
    return "centroid" if stype in ("PIPE", "RB") else "auto"


def plate_prop(name, thickness, material="Grade A", tc=0.0, color=""):
    return dict(name=name, thickness=float(thickness), material=material, tc=float(tc), color=color)


def plate_prop_name(t, mat):
    """Default plate property name as ALIEF FEAPRO creates it ('PL10 Grade A')."""
    return "PL%g %s" % (float(t), mat)


THK_PALETTE = ["#9CC3E6", "#7FB3D5", "#5DADE2", "#48C9B0", "#58D68D", "#F4D03F", "#F5B041",
               "#EB984E", "#DC7633", "#C0392B", "#AF7AC5", "#5D6D7E"]


def thickness_color(t):
    steps = [5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 20, 25]
    for i, s in enumerate(steps):
        if t <= s + 1e-9:
            return THK_PALETTE[i]
    return THK_PALETTE[-1]


# =========================================================================== library
def default_library():
    lib = material_library()
    mats = [lib["Grade A"], lib["AH36"]]
    props = [plate_prop(plate_prop_name(t, "Grade A"), t, "Grade A", 0.0, thickness_color(t))
             for t in (8, 10, 12)]
    secs = []
    for i, (st, d) in enumerate([("FB", dict(h=100, t=10)), ("L", dict(h=100, b=75, tw=7, tf=7)),
                                 ("BP", dict(h=160, t=8)), ("T", dict(hw=300, tw=10, bf=100, tf=12))]):
        secs.append(make_section(st, d, "Grade A", color=SECTION_PALETTE[i % len(SECTION_PALETTE)]))
    return dict(materials=mats, plate_props=props, sections=secs, catalogue={})


def library_index(lib):
    return ({m["name"]: m for m in lib.get("materials", [])},
            {p["name"]: p for p in lib.get("plate_props", [])},
            {s["name"]: s for s in lib.get("sections", [])})


def parse_plate_prop_name(name):
    """'PL10 Grade A' / 'PL12.5 AH36' -> (12.5, 'AH36') or None."""
    s = (name or "").strip()
    if not s.upper().startswith("PL"):
        return None
    rest = s[2:].strip()
    num = ""
    for ch in rest:
        if ch.isdigit() or ch == ".":
            num += ch
        else:
            break
    if not num:
        return None
    try:
        t = float(num)
    except ValueError:
        return None
    mat = rest[len(num):].strip() or "Grade A"
    return t, mat


def parse_section_name(name):
    """ALIEF FEAPRO section label -> (stype, dims) or None ('HP 200x10', 'T 300x10 / 100x12', 'L 200x90x9/14' ...)."""
    s = (name or "").strip().upper().replace(",", ".")
    if not s:
        return None
    head, _, rest = s.partition(" ")
    rest = rest.replace(" ", "")

    def nums(txt):
        out = []
        for part in txt.replace("/", "X").split("X"):
            if part:
                out.append(float(part))
        return out
    try:
        if head == "FB":
            h, t = nums(rest)
            return "FB", dict(h=h, t=t)
        if head == "L":
            v = nums(rest)
            if len(v) == 3:
                return "L", dict(h=v[0], b=v[1], tw=v[2], tf=v[2])
            if len(v) == 4:
                return "L", dict(h=v[0], b=v[1], tw=v[2], tf=v[3])
        if head == "T":
            hw, tw, bf, tf = nums(rest)
            return "T", dict(hw=hw, tw=tw, bf=bf, tf=tf)
        if head in ("H", "C"):
            h, b, tw, tf = nums(rest)
            return head, dict(h=h, b=b, tw=tw, tf=tf)
        if head in ("HP", "BP"):
            h, t = nums(rest)
            return "BP", dict(h=h, t=t)
        if head == "PIPE":
            D, t = nums(rest)
            return "PIPE", dict(D=D, t=t)
        if head == "RB":
            return "RB", dict(D=nums(rest)[0])
    except (ValueError, IndexError):
        return None
    return None


def library_autofix(lib, used_props=(), used_sections=()):
    """Create missing materials / plate properties that can be derived from their names.
    Returns a list of messages."""
    msgs = []
    mats, props, secs = library_index(lib)
    builtin = material_library()
    for nm in used_props:
        if nm and nm not in props:
            pr = parse_plate_prop_name(nm)
            if pr:
                t, m = pr
                lib["plate_props"].append(plate_prop(nm, t, m, 0.0, thickness_color(t)))
                props[nm] = lib["plate_props"][-1]
                msgs.append("Plate property '%s' re-created from its name" % nm)
    for nm in used_sections:
        if nm and nm not in secs:
            ps = parse_section_name(nm)
            if ps and not check_dims(ps[0], normalise_dims(ps[0], ps[1])):
                n = len(lib["sections"])
                lib["sections"].append(make_section(ps[0], ps[1], "Grade A", name=nm,
                                                    color=SECTION_PALETTE[n % len(SECTION_PALETTE)]))
                secs[nm] = lib["sections"][-1]
                msgs.append("Section '%s' re-created from its name (material Grade A - check it)" % nm)
    for coll in (props.values(), [s for s in lib.get("sections", [])]):
        for item in coll:
            m = item.get("material", "")
            if m and m not in mats and m in builtin:
                lib["materials"].append(builtin[m])
                mats[m] = builtin[m]
                msgs.append("Material '%s' added from the IACS library" % m)
    return msgs


def library_from_json(text):
    try:
        d = json.loads(text) if text else None
    except ValueError:
        d = None
    if not isinstance(d, dict):
        return default_library()
    out = dict(materials=[clean_material(m) for m in d.get("materials", []) if isinstance(m, dict) and m.get("name")],
               plate_props=[], sections=[])
    for p in d.get("plate_props", []):
        if isinstance(p, dict) and p.get("name"):
            out["plate_props"].append(plate_prop(p["name"], p.get("thickness", 10), p.get("material", "Grade A"),
                                                 p.get("tc", 0.0), p.get("color", "")))
    for s in d.get("sections", []):
        if isinstance(s, dict) and s.get("name") and s.get("stype") in DIM_FIELDS:
            out["sections"].append(dict(name=s["name"], stype=s["stype"], dims=normalise_dims(s["stype"], s.get("dims", {})),
                                        material=s.get("material", "Grade A"), tc=float(s.get("tc", 0.0)),
                                        color=s.get("color", "#C9A227")))
    if not out["materials"]:
        out["materials"] = default_library()["materials"]
    out["catalogue"] = clean_catalogue(d.get("catalogue"))
    return out


def library_to_json(lib):
    return json.dumps(lib, indent=1)


def merge_library(base, extra):
    """Add items of 'extra' that 'base' does not have (by name). Returns number added."""
    n = 0
    for key in ("materials", "plate_props", "sections"):
        have = set(x["name"] for x in base.get(key, []))
        for x in extra.get(key, []):
            if x.get("name") and x["name"] not in have:
                base.setdefault(key, []).append(x)
                have.add(x["name"])
                n += 1
    return n


# =========================================================================== settings
DEFAULT_SETTINGS = dict(
    active_prop="PL10 Grade A", active_section="L 100x75x7", web_side="+N", flange=1, offset="auto",
    mesh_size=0.0, facet_size=300.0, chord_tol=1.0, gap_tol=5.0,
    shell_tol=2.0, curved_method="Fast", export_scope="All AF members", facet_warn=20000, max_facets=5000, auto_coarsen=True, limit_x="", limit_y="", limit_z="", min_plate_area=100.0,
    merge_flat=True, decimate=True,
    project="", ship="", description="", export_path="", keep_existing=True,
    grid_x0=0.0, grid_spacing="-10, 200, 600", grid_decks="", write_grid=False, global_mesh=100.0,
    web_height=500.0, web_prop="", top="Face plate (shell)", fp_width=150.0, fp_prop="", fp_side="Centred",
    edge_section="", stf_dir="X", stf_mode="Spacing", stf_spacing=600.0, stf_count=4, stf_start=0.0,
    stf_end=0.0, stf_positions="", stf_margin=0.0, stf_side="+N", stf_planes="Z",
    bkt_a=400.0, bkt_b=400.0, bkt_toe=20.0, bkt_prop="", bkt_edge="None", bkt_fp_width=100.0,
    op_kind="Slot / manhole", op_a=600.0, op_b=400.0, op_r=0.0, op_angle=0.0,
    color_by="Property", show_3d=True, legend=True, legend_all_views=False, view3d_alpha=0.0,
    bkt_method="Click two members", bkt_auto=False, plate_light=True,
    as_method="Assign To Selected", as_role="Plate", as_keep=True, as_apply_side=False,
)

WEB_SIDES = ["+N", "-N", "+X", "-X", "+Y", "-Y", "+Z", "-Z"]
WEB_SIDE_LABELS = {"+N": "Plate normal side (+N)", "-N": "Opposite side (-N)", "+X": "+X", "-X": "-X",
                   "+Y": "+Y", "-Y": "-Y", "+Z": "+Z", "-Z": "-Z"}
OFFSET_MODES = ["auto", "centroid", "none"]
OFFSET_LABELS = {"auto": "auto - toe on the plating (eccentric)", "centroid": "centroid on the line",
                 "none": "none - no eccentricity (centroid on the line)"}


def settings_from_json(text):
    s = dict(DEFAULT_SETTINGS)
    try:
        d = json.loads(text) if text else {}
    except ValueError:
        d = {}
    if isinstance(d, dict):
        for k, v in d.items():
            if k in s:
                s[k] = v
    return s


# =========================================================================== plate geometry
def newell_normal(P):
    n = [0.0, 0.0, 0.0]
    m = len(P)
    for i in range(m):
        a, b = P[i], P[(i + 1) % m]
        n[0] += (a[1] - b[1]) * (a[2] + b[2])
        n[1] += (a[2] - b[2]) * (a[0] + b[0])
        n[2] += (a[0] - b[0]) * (a[1] + b[1])
    return n


def centroid(P):
    m = float(len(P))
    return [sum(p[0] for p in P) / m, sum(p[1] for p in P) / m, sum(p[2] for p in P) / m]


def plate_frame(P):
    """(origin, u, v, n) - identical to ALIEF FEAPRO Plate.frame()."""
    n = v_unit(newell_normal(P), [0.0, 0.0, 1.0])
    ax = argmax_abs(n)
    if abs(n[ax]) > 0.999:
        if ax == 2:
            u = [1.0, 0.0, 0.0]
        elif ax == 0:
            u = [0.0, 1.0, 0.0]
        else:
            u = [1.0, 0.0, 0.0]
        v = v_cross(n, u)
        if v[argmax_abs(v)] < 0:
            n, v = v_mul(n, -1.0), v_mul(v, -1.0)
    else:
        u = v_sub(P[1], P[0])
        u = v_unit(v_sub(u, v_mul(n, v_dot(u, n))), [1.0, 0.0, 0.0])
        v = v_cross(n, u)
    return centroid(P), u, v, n


def to_local(pts, fr):
    o, u, v, n = fr
    out = []
    for p in pts:
        q = v_sub(p, o)
        out.append((v_dot(q, u), v_dot(q, v)))
    return out


def to_global(uv, fr):
    o, u, v, n = fr
    return [v_add(v_add(o, v_mul(u, a)), v_mul(v, b)) for a, b in uv]


def planarity(P, fr=None):
    o, u, v, n = fr or plate_frame(P)
    return max(abs(v_dot(v_sub(p, o), n)) for p in P) if P else 0.0


def area2d(Q):
    s = 0.0
    m = len(Q)
    for i in range(m):
        x1, y1 = Q[i]
        x2, y2 = Q[(i + 1) % m]
        s += x1 * y2 - x2 * y1
    return 0.5 * s


def polygon_area3d(P):
    return 0.5 * v_len(newell_normal(P))


def point_in_poly(pt, poly):
    x, y = pt
    inside = False
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        if (y1 > y) != (y2 > y):
            xin = x1 + (y - y1) * (x2 - x1) / (y2 - y1)
            if xin > x:
                inside = not inside
    return inside


def seg_closest2d(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    t = 0.0 if L2 < 1e-18 else max(0.0, min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
    return (a[0] + t * dx, a[1] + t * dy), t


def dist2d(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def poly_boundary_dist2d(p, poly):
    best = 1e30
    n = len(poly)
    for i in range(n):
        q, _ = seg_closest2d(p, poly[i], poly[(i + 1) % n])
        best = min(best, dist2d(p, q))
    return best


def seg_closest3d(p, a, b):
    d = v_sub(b, a)
    L2 = v_dot(d, d)
    t = 0.0 if L2 < 1e-18 else max(0.0, min(1.0, v_dot(v_sub(p, a), d) / L2))
    return v_add(a, v_mul(d, t)), t


def simplify_polygon(P, tol_dup=1e-3, tol_col=1e-4, closed=True):
    """Remove duplicate and exactly collinear vertices (tolerances in mm)."""
    Q = []
    for p in P:
        if not Q or v_dist(p, Q[-1]) > tol_dup:
            Q.append(list(p))
    if closed and len(Q) > 1 and v_dist(Q[0], Q[-1]) <= tol_dup:
        Q.pop()
    changed = True
    while changed and len(Q) > 3:
        changed = False
        m = len(Q)
        for i in range(m if closed else m - 2):
            a = Q[(i - 1) % m] if closed else Q[i]
            b = Q[i] if closed else Q[i + 1]
            c = Q[(i + 1) % m] if closed else Q[i + 2]
            ac = v_sub(c, a)
            L = v_len(ac)
            if L < 1e-12:
                continue
            dev = v_len(v_cross(v_sub(b, a), ac)) / L
            t = v_dot(v_sub(b, a), ac) / (L * L)
            if dev < tol_col and 0.0 < t < 1.0:
                del Q[i if closed else i + 1]
                changed = True
                break
    return Q


def project_to_plane(p, fr):
    o, u, v, n = fr
    return v_sub(p, v_mul(n, v_dot(v_sub(p, o), n)))


# =========================================================================== openings
def _hull(points):
    pts = sorted(set((round(p[0], 6), round(p[1], 6)) for p in points))
    if len(pts) <= 2:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def _rot2(p, ang):
    c, s = math.cos(ang), math.sin(ang)
    return (c * p[0] - s * p[1], s * p[0] + c * p[1])


def _rounded_rect_dist(p, a, b, r):
    """Distance from p to the boundary of a rounded rectangle (half sizes a, b, radius r) centred at 0."""
    qx, qy = abs(p[0]) - (a - r), abs(p[1]) - (b - r)
    outside = math.hypot(max(qx, 0.0), max(qy, 0.0))
    inside = min(max(qx, qy), 0.0)
    return abs(outside + inside - r)


def classify_hole(loc, tol=1.0):
    """Recognise an opening outline given in plate-local 2D coordinates.
    Returns dict(kind, cu, cv, a, b, r, angle) - kind circle | rect | slot | poly."""
    m = len(loc)
    cu = sum(p[0] for p in loc) / m
    cv = sum(p[1] for p in loc) / m
    rad = [dist2d(p, (cu, cv)) for p in loc]
    if m >= 8 and max(rad) - min(rad) <= tol:
        return dict(kind="circle", cu=cu, cv=cv, a=2.0 * sum(rad) / m, b=2.0 * sum(rad) / m, r=0.0, angle=0.0)
    hull = _hull(loc)
    best = None
    k = len(hull)
    for i in range(k):
        e = (hull[(i + 1) % k][0] - hull[i][0], hull[(i + 1) % k][1] - hull[i][1])
        ang = math.atan2(e[1], e[0])
        rp = [_rot2(p, -ang) for p in hull]
        xs, ys = [p[0] for p in rp], [p[1] for p in rp]
        area = (max(xs) - min(xs)) * (max(ys) - min(ys))
        if best is None or area < best[0] - 1e-9:
            best = (area, ang)
    ang = best[1] if best else 0.0
    # normalise to (-45, 45] deg, a along the rotated u axis
    while ang > math.pi / 4 + 1e-9:
        ang -= math.pi / 2
    while ang <= -math.pi / 4 + 1e-9:
        ang += math.pi / 2
    rp = [_rot2(p, -ang) for p in loc]
    xs, ys = [p[0] for p in rp], [p[1] for p in rp]
    cx, cy = 0.5 * (max(xs) + min(xs)), 0.5 * (max(ys) + min(ys))
    a, b = 0.5 * (max(xs) - min(xs)), 0.5 * (max(ys) - min(ys))
    rel = [(p[0] - cx, p[1] - cy) for p in rp]
    centre = _rot2((cx, cy), ang)
    res = dict(cu=centre[0], cv=centre[1], a=2 * a, b=2 * b, angle=math.degrees(ang))
    # corner radius from the extreme points along the diagonals
    A = (a + b) / math.sqrt(2.0)
    rs = []
    for sx, sy in ((1, 1), (-1, 1), (-1, -1), (1, -1)):
        S = max((sx * p[0] + sy * p[1]) / math.sqrt(2.0) for p in rel)
        rs.append((A - S) / (math.sqrt(2.0) - 1.0))
    r = max(0.0, min(sum(rs) / 4.0, min(a, b)))
    cands = [0.0, r, min(a, b)]
    for rr in cands:
        if all(_rounded_rect_dist(p, a, b, rr) <= tol for p in rel):
            if abs(rr - min(a, b)) <= tol and abs(a - b) > tol:
                res.update(kind="slot", r=min(a, b))
            elif rr <= tol:
                res.update(kind="rect", r=0.0)
            else:
                res.update(kind="rect", r=rr)
            return res
    res.update(kind="poly", r=0.0)
    return res


def _rotp(p, ang):
    return _rot2(p, ang)


def opening_segments(op_kind, c, a, b, r, angle_deg):
    """Segments of an opening centred at local point c - identical to ALIEF FEAPRO."""
    ang = math.radians(angle_deg)

    def T(p):
        q = _rotp(p, ang)
        return (c[0] + q[0], c[1] + q[1])
    segs = []
    if op_kind == "circle":
        rr = a / 2.0
        pts = [T((rr, 0)), T((0, rr)), T((-rr, 0)), T((0, -rr))]
        for i in range(4):
            segs.append(("A", pts[i], T((0, 0)), pts[(i + 1) % 4]))
        return segs
    a2, b2 = a / 2.0, b / 2.0
    if op_kind == "slot":
        if a >= b:
            rr = b2
            cx = a2 - rr
            segs += [("L", T((-cx, -rr)), T((cx, -rr))), ("A", T((cx, -rr)), T((cx, 0)), T((cx + rr, 0))),
                     ("A", T((cx + rr, 0)), T((cx, 0)), T((cx, rr))), ("L", T((cx, rr)), T((-cx, rr))),
                     ("A", T((-cx, rr)), T((-cx, 0)), T((-cx - rr, 0))),
                     ("A", T((-cx - rr, 0)), T((-cx, 0)), T((-cx, -rr)))]
        else:
            rr = a2
            cy = b2 - rr
            segs += [("L", T((rr, -cy)), T((rr, cy))), ("A", T((rr, cy)), T((0, cy)), T((0, cy + rr))),
                     ("A", T((0, cy + rr)), T((0, cy)), T((-rr, cy))), ("L", T((-rr, cy)), T((-rr, -cy))),
                     ("A", T((-rr, -cy)), T((0, -cy)), T((0, -cy - rr))),
                     ("A", T((0, -cy - rr)), T((0, -cy)), T((rr, -cy)))]
        return segs
    rr = min(max(r, 0.0), a2 * 0.999, b2 * 0.999)
    if rr <= 1e-6:
        pts = [T((-a2, -b2)), T((a2, -b2)), T((a2, b2)), T((-a2, b2))]
        return [("L", pts[i], pts[(i + 1) % 4]) for i in range(4)]
    segs += [("L", T((-a2 + rr, -b2)), T((a2 - rr, -b2))), ("A", T((a2 - rr, -b2)), T((a2 - rr, -b2 + rr)), T((a2, -b2 + rr))),
             ("L", T((a2, -b2 + rr)), T((a2, b2 - rr))), ("A", T((a2, b2 - rr)), T((a2 - rr, b2 - rr)), T((a2 - rr, b2))),
             ("L", T((a2 - rr, b2)), T((-a2 + rr, b2))), ("A", T((-a2 + rr, b2)), T((-a2 + rr, b2 - rr)), T((-a2, b2 - rr))),
             ("L", T((-a2, b2 - rr)), T((-a2, -b2 + rr))), ("A", T((-a2, -b2 + rr)), T((-a2 + rr, -b2 + rr)), T((-a2 + rr, -b2)))]
    return segs


def densify_segments(segs, arc_seg=8):
    pts = []
    for s in segs:
        if s[0] == "L":
            pts.append(s[1])
        else:
            p0, c, p1 = s[1], s[2], s[3]
            r = dist2d(p0, c)
            a0 = math.atan2(p0[1] - c[1], p0[0] - c[0])
            a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
            da = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi
            for i in range(arc_seg):
                t = a0 + da * i / arc_seg
                pts.append((c[0] + r * math.cos(t), c[1] + r * math.sin(t)))
    return pts


def opening_outline_global(op, fr, arc_seg=12):
    """3D outline points of an ALIEF FEAPRO opening dict on a plate frame."""
    if op.get("kind") == "poly" and op.get("pts"):
        return [list(p) for p in op["pts"]]
    c = to_local([op.get("center", [0, 0, 0])], fr)[0]
    segs = opening_segments(op.get("kind", "circle"), c, op.get("a", 400.0), op.get("b", 300.0),
                            op.get("r", 0.0), op.get("angle", 0.0))
    return to_global(densify_segments(segs, arc_seg), fr)


def make_opening(hole_pts, fr, tol=1.0, circle=None):
    """Build an ALIEF FEAPRO opening dict from a hole outline (3D points on the plate).
    circle = (centre3d, diameter) when the CAD curve is a true circle."""
    if circle is not None:
        return dict(kind="circle", center=v_round(circle[0], 4), a=round(float(circle[1]), 4),
                    b=round(float(circle[1]), 4), r=0.0, angle=0.0)
    loc = to_local(hole_pts, fr)
    c = classify_hole(loc, tol)
    centre = to_global([(c["cu"], c["cv"])], fr)[0]
    op = dict(kind=c["kind"], center=v_round(centre, 9), a=round(c["a"], 4), b=round(c["b"], 4),
              r=round(c.get("r", 0.0), 4), angle=round(c.get("angle", 0.0), 6))
    if c["kind"] == "poly":
        op["pts"] = [v_round(project_to_plane(p, fr), 9) for p in hole_pts]
    elif c["kind"] == "circle":
        op.update(b=op["a"], angle=0.0)
    return op


def opening_area(op):
    k = op.get("kind")
    a, b, r = op.get("a", 0.0), op.get("b", 0.0), op.get("r", 0.0)
    if k == "circle":
        return math.pi * a * a / 4.0
    if k == "slot":
        rr = min(a, b) / 2.0
        return a * b - (4.0 - math.pi) * rr * rr
    if k == "rect":
        return a * b - (4.0 - math.pi) * r * r
    if k == "poly" and op.get("pts"):
        return polygon_area3d(op["pts"])
    return 0.0


def cut_out_holes(p, q, fr, holes_loc, min_len=1.0, pullback=1.0):
    """Pieces of the straight profile p-q (on a planar plate) that are not inside an opening.
    Ends created at an opening are pulled back 'pullback' mm onto solid plating (the CAD hole is
    an arc, its outline here a chord polygon)."""
    a = to_local([p], fr)[0]
    b = to_local([q], fr)[0]
    L = v_dist(p, q)
    ts = [0.0, 1.0]
    dx, dy = b[0] - a[0], b[1] - a[1]
    for H in holes_loc:
        m = len(H)
        for j in range(m):
            c, d = H[j], H[(j + 1) % m]
            ex, ey = d[0] - c[0], d[1] - c[1]
            den = dx * ey - dy * ex
            if abs(den) < 1e-14:
                continue
            t = ((c[0] - a[0]) * ey - (c[1] - a[1]) * ex) / den
            s = ((c[0] - a[0]) * dy - (c[1] - a[1]) * dx) / den
            if 0.0 < t < 1.0 and -1e-9 <= s <= 1 + 1e-9:
                ts.append(t)
    ts = sorted(set(round(t, 9) for t in ts))
    keep = []
    for t0, t1 in zip(ts[:-1], ts[1:]):
        tm = 0.5 * (t0 + t1)
        mid = (a[0] + dx * tm, a[1] + dy * tm)
        if any(point_in_poly(mid, H) for H in holes_loc):
            continue
        if keep and abs(keep[-1][1] - t0) < 1e-12:
            keep[-1] = (keep[-1][0], t1)
        else:
            keep.append((t0, t1))
    out = []
    dt = pullback / L if L > 0 else 0.0
    for t0, t1 in keep:
        if t0 > 0.0:
            t0 += dt
        if t1 < 1.0:
            t1 -= dt
        P0, P1 = v_lerp(p, q, t0), v_lerp(p, q, t1)
        if t1 > t0 and v_dist(P0, P1) >= min_len:
            out.append((P0, P1))
    return out


# =========================================================================== facets (curved plating)
class FacetMesh(object):
    """Planar facets of one or more curved plates (triangles / planar quads), mm.

    facets : list of dict(pts=[[x,y,z],..], owner=<plate key>, n=unit normal)
    Shared vertices are recognised by rounded coordinates so the facets of
    neighbouring curved plates join conformally."""

    def __init__(self, facets, cell=None):
        self.facets = facets
        for f in self.facets:
            f.setdefault("n", v_unit(newell_normal(f["pts"]), [0, 0, 1]))
            f["fr"] = self._frame(f)
            f["loc"] = to_local(f["pts"], f["fr"])
        self.vkey_facets = {}
        self.edge_facets = {}
        for i, f in enumerate(self.facets):
            ks = [self.key(p) for p in f["pts"]]
            f["keys"] = ks
            for k in ks:
                self.vkey_facets.setdefault(k, set()).add(i)
            m = len(ks)
            for j in range(m):
                e = tuple(sorted((ks[j], ks[(j + 1) % m])))
                self.edge_facets.setdefault(e, set()).add(i)
        sizes = []
        for f in self.facets:
            P = f["pts"]
            sizes.append(max(v_dist(P[j], P[(j + 1) % len(P)]) for j in range(len(P))))
        self.size = (sum(sizes) / len(sizes)) if sizes else 100.0
        self.cell = cell or max(self.size, 1.0)
        self.grid = {}
        for i, f in enumerate(self.facets):
            lo = [min(p[k] for p in f["pts"]) for k in range(3)]
            hi = [max(p[k] for p in f["pts"]) for k in range(3)]
            for gx in range(int(math.floor(lo[0] / self.cell)), int(math.floor(hi[0] / self.cell)) + 1):
                for gy in range(int(math.floor(lo[1] / self.cell)), int(math.floor(hi[1] / self.cell)) + 1):
                    for gz in range(int(math.floor(lo[2] / self.cell)), int(math.floor(hi[2] / self.cell)) + 1):
                        self.grid.setdefault((gx, gy, gz), []).append(i)

    @staticmethod
    def key(p, nd=3):
        return (round(p[0], nd), round(p[1], nd), round(p[2], nd))

    @staticmethod
    def _frame(f):
        P = f["pts"]
        n = f["n"]
        u = v_unit(v_sub(P[1], P[0]), [1, 0, 0])
        u = v_unit(v_sub(u, v_mul(n, v_dot(u, n))), [1, 0, 0])
        return (P[0], u, v_cross(n, u), n)

    def closest_on_facet(self, i, p):
        f = self.facets[i]
        fr = f["fr"]
        q = to_local([p], fr)[0]
        loc = f["loc"]
        if point_in_poly(q, loc):
            best = q
        else:
            best, bd = None, 1e30
            m = len(loc)
            for j in range(m):
                c, _ = seg_closest2d(q, loc[j], loc[(j + 1) % m])
                d = dist2d(q, c)
                if d < bd:
                    best, bd = c, d
        g = to_global([best], fr)[0]
        return g, v_dist(p, g)

    def candidates(self, p, rings=1):
        gx, gy, gz = (int(math.floor(p[k] / self.cell)) for k in range(3))
        out = set()
        for r in range(rings, rings + 6):
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    for dz in range(-r, r + 1):
                        out.update(self.grid.get((gx + dx, gy + dy, gz + dz), ()))
            if out:
                return out
        return set(range(len(self.facets)))

    def closest(self, p):
        best = (None, None, 1e30)
        for i in self.candidates(p):
            g, d = self.closest_on_facet(i, p)
            if d < best[2]:
                best = (i, g, d)
        return best

    def near(self, p, r):
        """(facet, point, distance) of the nearest facet within r of p, else (None, None, 1e30).
        Looks only at the grid cells within r - never scans the whole shell."""
        if not hasattr(self, "lo"):
            pts = [q for f in self.facets for q in f["pts"]] or [[0.0, 0.0, 0.0]]
            self.lo, self.hi = bbox_of(pts)
        if any(p[k] < self.lo[k] - r or p[k] > self.hi[k] + r for k in range(3)):
            return (None, None, 1e30)
        c = self.cell
        rng = [range(int(math.floor((p[k] - r) / c)), int(math.floor((p[k] + r) / c)) + 1) for k in range(3)]
        cand = set()
        for gx in rng[0]:
            for gy in rng[1]:
                for gz in rng[2]:
                    cand.update(self.grid.get((gx, gy, gz), ()))
        best = (None, None, 1e30)
        for i in cand:
            g, d = self.closest_on_facet(i, p)
            if d <= r and d < best[2]:
                best = (i, g, d)
        return best

    def on_facet(self, i, p, eps):
        g, d = self.closest_on_facet(i, p)
        return d <= eps

    def neighbours_across(self, i, p, eps):
        """Facets sharing the boundary point p of facet i (edge or vertex), excluding i."""
        f = self.facets[i]
        P = f["pts"]
        m = len(P)
        for j in range(m):
            if v_dist(p, P[j]) <= 1e-6:
                # the point is a facet vertex: continue only into the facets around that vertex
                return self.vkey_facets.get(self.key(P[j]), set()) - set([i])
        out = set()
        for j in range(m):
            a, b = P[j], P[(j + 1) % m]
            c, t = seg_closest3d(p, a, b)
            if v_dist(c, p) <= eps:
                if t <= 1e-6 or v_dist(p, a) <= eps:
                    out |= self.vkey_facets.get(self.key(a), set())
                elif t >= 1 - 1e-6 or v_dist(p, b) <= eps:
                    out |= self.vkey_facets.get(self.key(b), set())
                else:
                    out |= self.edge_facets.get(tuple(sorted((f["keys"][j], f["keys"][(j + 1) % m]))), set())
        out.discard(i)
        return out


def walk_polyline(fm, points, eps=0.05, snap=2.0, max_steps=100000):
    """Split a polyline lying on curved plating into straight pieces, each inside one facet
    and ending on facet boundaries, so profiles share nodes with the shell mesh.
    Returns list of (p, q, facet_index)."""
    if len(points) < 2:
        return []
    samples = []
    for p in points:
        i, g, d = fm.closest(p)
        samples.append((i, g))
    segs = []
    cur_f, cur_p = samples[0]
    steps = 0
    for k in range(1, len(samples)):
        tf, tp = samples[k]
        guard = 0
        while tf != cur_f and guard < 200 and steps < max_steps:
            guard += 1
            steps += 1
            if fm.on_facet(cur_f, tp, eps):
                # target still on the current facet (on its boundary, e.g. a profile running along a
                # facet edge) -> stay on this facet
                break
            exit_p = _exit_point(fm, cur_f, cur_p, tp, eps)
            if exit_p is None:
                cur_f, cur_p = tf, tp       # jump (gap in the plating)
                break
            # snap to a facet vertex close to the exit point
            for v in fm.facets[cur_f]["pts"]:
                if v_dist(v, exit_p) <= snap:
                    exit_p = list(v)
                    break
            exit_p = fm.closest_on_facet(cur_f, exit_p)[0]
            if v_dist(cur_p, exit_p) > eps:
                segs.append((cur_p, exit_p, cur_f))
            nbs = fm.neighbours_across(cur_f, exit_p, eps)
            if not nbs:
                cur_f, cur_p = tf, tp
                break
            if tf in nbs:
                nxt = tf
            else:
                nxt, bd = None, 1e30
                for j in nbs:
                    g, d = fm.closest_on_facet(j, tp)
                    # prefer the facet the path actually enters
                    probe = v_lerp(exit_p, tp, min(1.0, 4 * eps / max(v_dist(exit_p, tp), 1e-9)))
                    g2, d2 = fm.closest_on_facet(j, probe)
                    score = d2 * 10.0 + d
                    if score < bd:
                        nxt, bd = j, score
            cur_f, cur_p = nxt, exit_p
    last_f, last_p = samples[-1]
    if last_f == cur_f or fm.on_facet(cur_f, last_p, eps):
        last_p = fm.closest_on_facet(cur_f, last_p)[0]
        if v_dist(cur_p, last_p) > eps:
            segs.append((cur_p, last_p, cur_f))
    return segs


def triangulate_facet(P, tol=-1.0):
    """Facet -> triangles (shorter diagonal). ALIEF FEAPRO / OpenCASCADE need exactly planar
    outlines and facet vertices are later snapped onto web / deck planes, so by default every
    facet becomes triangles; with tol >= 0 quads planar within tol are kept."""
    if len(P) == 3:
        return [P]
    if len(P) == 4:
        if planarity(P) <= tol:
            return [P]
        if v_dist(P[0], P[2]) <= v_dist(P[1], P[3]):
            return [[P[0], P[1], P[2]], [P[0], P[2], P[3]]]
        return [[P[0], P[1], P[3]], [P[1], P[2], P[3]]]
    c = centroid(P)
    return [[P[i], P[(i + 1) % len(P)], c] for i in range(len(P))]


def snap_vertices_to_planes(facets, planes, tol):
    """Move facet vertices lying (within tol) on one or more planes exactly onto them
    (alternating projection -> onto the intersection line when on two planes).
    planes: list of (origin, unit normal). Facets must be triangles (they stay planar).
    Returns dict plane_index -> list of snapped points."""
    verts = {}
    for f in facets:
        for p in f["pts"]:
            verts.setdefault(FacetMesh.key(p, 6), list(p))
    on = {}
    moved = {}
    for k, p in verts.items():
        hits = [i for i, (o, n) in enumerate(planes) if abs(v_dot(v_sub(p, o), n)) <= tol]
        if not hits:
            continue
        q = list(p)
        for _ in range(60 if len(hits) > 1 else 1):
            for i in hits:
                o, n = planes[i]
                q = v_sub(q, v_mul(n, v_dot(v_sub(q, o), n)))
        moved[k] = q
        for i in hits:
            on.setdefault(i, []).append(q)
    for f in facets:
        f["pts"] = [moved.get(FacetMesh.key(p, 6), p) for p in f["pts"]]
    return on


def flatten_polygon(P):
    """Project a (nearly) planar polygon exactly onto its best plane."""
    if len(P) < 4:
        return [list(p) for p in P]
    fr = plate_frame(P)
    return [project_to_plane(p, fr) for p in P]


def _exit_point(fm, i, p, target, eps):
    """Point where the straight path p -> target (projected on facet i) leaves facet i."""
    f = fm.facets[i]
    fr = f["fr"]
    a = to_local([p], fr)[0]
    b = to_local([target], fr)[0]
    loc = f["loc"]
    m = len(loc)
    best_t, best = None, None
    dx, dy = b[0] - a[0], b[1] - a[1]
    for j in range(m):
        c, d = loc[j], loc[(j + 1) % m]
        ex, ey = d[0] - c[0], d[1] - c[1]
        den = dx * ey - dy * ex
        if abs(den) < 1e-14:
            continue
        t = ((c[0] - a[0]) * ey - (c[1] - a[1]) * ex) / den
        s = ((c[0] - a[0]) * dy - (c[1] - a[1]) * dx) / den
        if t > 1e-7 and -1e-7 <= s <= 1 + 1e-7:
            if best_t is None or t < best_t:
                best_t, best = t, (a[0] + t * dx, a[1] + t * dy)
    if best is None:
        # target behind / along an edge: use the boundary point closest to the target
        q, bd = None, 1e30
        for j in range(m):
            c, _ = seg_closest2d(b, loc[j], loc[(j + 1) % m])
            dd = dist2d(c, b)
            if dd < bd:
                q, bd = c, dd
        if q is None or dist2d(q, a) <= 1e-9:
            return None
        best = q
    return to_global([best], fr)[0]


def merge_collinear_segments(segs, tol=1e-3):
    """Join consecutive pieces in the same facet that are collinear."""
    out = []
    for p, q, f in segs:
        if out and out[-1][2] == f and v_dist(out[-1][1], p) <= tol:
            a = out[-1][0]
            ab, aq = v_sub(out[-1][1], a), v_sub(q, a)
            if v_len(v_cross(ab, aq)) <= tol * max(v_len(aq), 1.0):
                out[-1] = (a, q, f)
                continue
        out.append((p, q, f))
    return out


def conform_edges_to_facets(poly, on_surface, plane_pts, run_tol, snap_tol):
    """Re-edge a planar plate on curved plating.

    poly        : closed polygon (3D) of the planar plate, densified along curved edges
    on_surface  : flag per vertex - vertex lies on the curved plating
    plane_pts   : facet vertices that lie in the plate plane (they lie on the split curve)
    For every run of consecutive on-surface vertices the run is replaced by the facet
    vertices along it, and the run ends are snapped onto the facet chord chain, so that
    the plate edge follows the facet edges exactly (shared mesh nodes)."""
    m = len(poly)
    if m < 3 or not any(on_surface) or all(on_surface) or not plane_pts:
        return [list(p) for p in poly], 0
    start = next(i for i in range(m) if not on_surface[i])
    order = [(start + k) % m for k in range(m)]
    runs, cur = [], []
    for i in order:
        if on_surface[i]:
            cur.append(i)
        else:
            if len(cur) >= 2:
                runs.append(cur)
            cur = []
    if len(cur) >= 2:
        runs.append(cur)
    replace = {}
    for run in runs:
        rp = [poly[i] for i in run]
        cum = [0.0]
        for j in range(1, len(rp)):
            cum.append(cum[-1] + v_dist(rp[j - 1], rp[j]))
        chain = []
        for q in plane_pts:
            best_d, best_s = 1e30, 0.0
            for j in range(len(rp) - 1):
                c, t = seg_closest3d(q, rp[j], rp[j + 1])
                d = v_dist(q, c)
                if d < best_d:
                    best_d, best_s = d, cum[j] + t * (cum[j + 1] - cum[j])
            if best_d <= run_tol:
                chain.append((best_s, list(q)))
        chain.sort(key=lambda x: x[0])
        uniq = []
        for s, q in chain:
            if not uniq or v_dist(uniq[-1][1], q) > 1e-3:
                uniq.append((s, q))
        L = cum[-1]
        inner = [q for s, q in uniq if 1e-3 < s < L - 1e-3]
        cpts = [q for s, q in uniq]

        def snap(p):
            if len(cpts) == 0:
                return list(p)
            if len(cpts) == 1:
                return list(cpts[0]) if v_dist(cpts[0], p) <= snap_tol else list(p)
            best, bd = None, 1e30
            for j in range(len(cpts) - 1):
                c, _ = seg_closest3d(p, cpts[j], cpts[j + 1])
                d = v_dist(c, p)
                if d < bd:
                    best, bd = c, d
            return best if bd <= snap_tol else list(p)
        a, b = snap(rp[0]), snap(rp[-1])
        inner = [q for q in inner if v_dist(q, a) > 1e-3 and v_dist(q, b) > 1e-3]
        replace[run[0]] = [a] + inner
        for i in run[1:-1]:
            replace[i] = []
        replace[run[-1]] = [b]
    out = []
    for i in range(m):
        if i in replace:
            out.extend(replace[i])
        else:
            out.append(list(poly[i]))
    return simplify_polygon(out), len(runs)


# =========================================================================== model check
def check_model(plates, beams, lib, gap_tol=5.0, exact_tol=0.01):
    """plates: list of dict(key, name, points, prop, curved, holes)
    beams  : list of dict(key, name, points, section, host)
    Returns list of (level, message, [keys])."""
    mats, props, secs = library_index(lib)
    issues = []
    for p in plates:
        if p.get("prop") not in props:
            issues.append(("ERROR", "Plate %s: plate property '%s' not in the library" % (p["name"], p.get("prop")), [p["key"]]))
        if not p.get("curved"):
            P = p["points"]
            if len(P) < 3 or polygon_area3d(P) < 1.0:
                issues.append(("ERROR", "Plate %s: degenerate outline" % p["name"], [p["key"]]))
            else:
                dev = planarity(P)
                if dev > 1.0:
                    issues.append(("ERROR", "Plate %s is not planar (%.2f mm) - assign it as a curved plate" % (p["name"], dev), [p["key"]]))
    for pp in props.values():
        if pp["material"] not in mats:
            issues.append(("ERROR", "Plate property %s: material '%s' missing" % (pp["name"], pp["material"]), []))
    for s in secs.values():
        if s["material"] not in mats:
            issues.append(("ERROR", "Section %s: material '%s' missing" % (s["name"], s["material"]), []))
        msg = check_dims(s["stype"], s["dims"])
        if msg:
            issues.append(("ERROR", "Section %s: %s" % (s["name"], msg), []))
    for b in beams:
        if b.get("section") not in secs:
            issues.append(("ERROR", "Profile %s: section '%s' not in the library" % (b["name"], b.get("section")), [b["key"]]))
        P = b["points"]
        L = sum(v_dist(P[i], P[i + 1]) for i in range(len(P) - 1)) if len(P) > 1 else 0.0
        if L < 1.0:
            issues.append(("ERROR", "Profile %s has zero length" % b["name"], [b["key"]]))
        elif not b.get("host"):
            issues.append(("INFO", "Profile %s is not lying on a plate (free beam - check the offset mode)" % b["name"], [b["key"]]))
    # gaps / overlaps between planar plates (edges that almost touch another plate)
    planar = [p for p in plates if not p.get("curved") and len(p["points"]) >= 3]
    boxes = []
    for p in planar:
        P = p["points"]
        boxes.append(([min(q[k] for q in P) - gap_tol for k in range(3)],
                      [max(q[k] for q in P) + gap_tol for k in range(3)], plate_frame(P)))
    reported = set()
    sizes = sorted(max(hi[k] - lo[k] for k in range(3)) for lo, hi, _ in boxes) or [1000.0]
    gidx = GridIndex(max(sizes[len(sizes) // 2], 10.0 * gap_tol, 1.0))
    for j, (lo, hi, _) in enumerate(boxes):
        gidx.add(j, lo, hi)
    locs = {}
    for i, a in enumerate(planar):
        for j in sorted(gidx.query(boxes[i][0], boxes[i][1])):
            b = planar[j]
            if i == j or (j, i) in reported:
                continue
            lo, hi, frb = boxes[j]
            lo_a, hi_a, _ = boxes[i]
            if any(hi_a[k] < lo[k] or lo_a[k] > hi[k] for k in range(3)):
                continue
            o, u, v, n = frb
            if j not in locs:
                locs[j] = to_local(b["points"], frb)
            locb = locs[j]
            worst = 0.0
            for q in a["points"]:
                d = abs(v_dot(v_sub(q, o), n))
                if exact_tol < d <= gap_tol:
                    uv = to_local([q], frb)[0]
                    if point_in_poly(uv, locb) or poly_boundary_dist2d(uv, locb) <= gap_tol:
                        worst = max(worst, d)
            if worst > 0.0:
                reported.add((i, j))
                issues.append(("WARNING", "Plate %s does not meet plate %s (gap / overlap %.2f mm) - snap the edge onto the plate"
                               % (a["name"], b["name"], worst), [a["key"], b["key"]]))
    if not issues:
        issues.append(("OK", "Model check passed - ready to export to ALIEF FEAPRO", []))
    return issues


# =========================================================================== material take-off
def material_takeoff(plates, beams, lib):
    """plates: dict(prop, area_mm2) ; beams: dict(section, length_mm). Returns (rows_pl, rows_pr, totals)."""
    mats, props, secs = library_index(lib)
    pl = {}
    for p in plates:
        pl.setdefault(p["prop"], [0.0, 0])
        pl[p["prop"]][0] += p["area"]
        pl[p["prop"]][1] += 1
    rows_pl = []
    tot = 0.0
    for nm in sorted(pl, key=lambda x: (props.get(x, {}).get("thickness", 0), x)):
        pp = props.get(nm, {})
        m = mats.get(pp.get("material"), {})
        t = pp.get("thickness", 0.0)
        area = pl[nm][0] * 1e-6
        w = area * t * 1e-3 * m.get("density", 7850.0) / 1000.0
        tot += w
        rows_pl.append([nm, "%g" % t, pp.get("material", "?"), str(pl[nm][1]), "%.3f" % area, "%.3f" % w])
    pr = {}
    for b in beams:
        pr.setdefault(b["section"], [0.0, 0])
        pr[b["section"]][0] += b["length"]
        pr[b["section"]][1] += 1
    rows_pr = []
    totb = 0.0
    for nm in sorted(pr):
        s = secs.get(nm)
        if s:
            A = section_properties(s["stype"], s["dims"])["A"]
            m = mats.get(s["material"], {})
            kgm = A * 1e-6 * m.get("density", 7850.0)
        else:
            kgm = 0.0
        L = pr[nm][0] * 1e-3
        w = L * kgm / 1000.0
        totb += w
        rows_pr.append([nm, s["material"] if s else "?", str(pr[nm][1]), "%.3f" % L, "%.2f" % kgm, "%.3f" % w])
    return rows_pl, rows_pr, (tot, totb)


# =========================================================================== ids
class IdRegistry(object):
    """Stable ALIEF FEAPRO ids per Rhino object (and facet / piece index) so loads and supports
    defined in ALIEF FEAPRO stay valid when the model is exported again."""

    def __init__(self, text=None):
        d = {}
        try:
            d = json.loads(text) if text else {}
        except ValueError:
            d = {}
        self.map = dict(d.get("map", {})) if isinstance(d, dict) else {}
        self.next = int(d.get("next", 1)) if isinstance(d, dict) else 1
        self.used = set()

    def get(self, key):
        if key in self.map and self.map[key] not in self.used:
            i = self.map[key]
        else:
            i = self.next
            self.next += 1
            self.map[key] = i
        self.used.add(i)
        self.next = max(self.next, i + 1)
        return i

    def prune(self):
        self.map = {k: v for k, v in self.map.items() if v in self.used}

    def to_json(self):
        return json.dumps(dict(next=self.next, map=self.map))


# =========================================================================== ALIEF FEAPRO file
def _grid_from_settings(s):
    segs = []
    for part in str(s.get("grid_spacing", "")).replace(";", "\n").splitlines():
        vals = [x.strip() for x in part.split(",") if x.strip()]
        if len(vals) == 3:
            try:
                segs.append([float(vals[0]), float(vals[1]), float(vals[2])])
            except ValueError:
                pass
    decks = {}
    for part in str(s.get("grid_decks", "")).replace(";", "\n").replace(",", "\n").splitlines():
        if "=" in part:
            k, v = part.split("=", 1)
            try:
                decks[k.strip()] = float(v)
            except ValueError:
                pass
    return dict(x_fr0=float(s.get("grid_x0", 0.0) or 0.0), segments=segs or [[-10, 200, 600.0]],
                decks=decks, longitudinals={})


GEOMETRY_KEYS = ("plates", "beams")


def build_project(plates, beams, lib, settings, layers=None, existing=None):
    """Assemble the ALIEF FEAPRO project dict.

    plates : dict(id, name, points, prop, openings, mesh_size, group)
    beams  : dict(id, name, p1, p2, section, orient, flange_side, offset_mode, group)
    existing: dict of an .alfea file to update - supports, loads, load cases, mesh / analysis /
              report settings and anything else created in ALIEF FEAPRO are kept."""
    s = settings
    plates_out = []
    for p in plates:
        plates_out.append(dict(id=int(p["id"]), name=p["name"], points=[v_round(q, 9) for q in p["points"]],
                               prop=p["prop"], openings=p.get("openings", []),
                               mesh_size=float(p.get("mesh_size", 0.0) or 0.0), group=p.get("group", "Default"),
                               visible=True))
    beams_out = []
    for b in beams:
        beams_out.append(dict(id=int(b["id"]), name=b["name"], p1=v_round(b["p1"], 9), p2=v_round(b["p2"], 9),
                              section=b["section"], orient=v_round(b["orient"], 6), flange_side=int(b.get("flange_side", 1)),
                              offset_mode=b.get("offset_mode", "auto"), group=b.get("group", "Default"), visible=True))
    max_id = max([0] + [p["id"] for p in plates_out] + [b["id"] for b in beams_out])
    lay = [dict(name=l["name"], color=l.get("color", "#7FA7C9"), visible=True, locked=False, prop="", section="")
           for l in (layers or [])]
    if existing:
        d = dict(existing)
        for key in ("materials", "plate_props", "sections"):
            ours = {x["name"]: x for x in lib.get(key, [])}
            keep = [x for x in d.get(key, []) if isinstance(x, dict) and x.get("name") not in ours]
            d[key] = keep + list(ours.values())
        d["plates"] = plates_out
        d["beams"] = beams_out
        have = {l.get("name"): l for l in d.get("layers", []) if isinstance(l, dict)}
        for l in lay:
            if l["name"] not in have:
                have[l["name"]] = l
            else:
                have[l["name"]]["color"] = l["color"]
        d["layers"] = list(have.values())
        others = []
        for key in ("cad", "constraints", "links", "loads", "curves"):
            for x in d.get(key, []):
                if isinstance(x, dict) and isinstance(x.get("id"), int):
                    others.append(x["id"])
        d["next"] = max(int(d.get("next", 1)), max_id + 1, max([0] + others) + 1)
        if s.get("write_grid"):
            d["grid"] = _grid_from_settings(s)
        if s.get("project"):
            d["name"] = s["project"]
        return d
    rep = dict(project=s.get("project", "") or "", ship_name=s.get("ship", "") or "")
    return dict(
        format=FEAPRO_FORMAT, version=1, name=s.get("project") or "Rhino model", description=s.get("description", ""),
        grid=_grid_from_settings(s), materials=list(lib.get("materials", [])), plate_props=list(lib.get("plate_props", [])),
        sections=list(lib.get("sections", [])), plates=plates_out, beams=beams_out, cad=[], constraints=[], links=[],
        loads=[], loadcases=[], layers=lay, curves=[],
        mesh=dict(size=float(s.get("global_mesh", 100.0) or 100.0)), report=rep,
        exported_by="%s %s (Rhinoceros)" % (APP, VERSION), next=max_id + 1)


def dangling_references(d):
    """Loads / supports of an updated file that point to plates or profiles that no longer exist."""
    ids_p = set(p["id"] for p in d.get("plates", []))
    ids_b = set(b["id"] for b in d.get("beams", []))
    msgs = []
    for l in d.get("loads", []):
        data = l.get("data", {}) or {}
        miss = [i for i in data.get("plates", []) if i not in ids_p] + [i for i in data.get("beams", []) if i not in ids_b]
        sel = l.get("selection", {}) or {}
        if sel.get("kind") in ("plate_edges", "plate_all"):
            miss += [i for i in sel.get("data", {}).get("ids", []) if i not in ids_p]
        if miss:
            msgs.append("Load '%s' refers to removed members %s" % (l.get("name"), sorted(set(miss))))
    for c in d.get("constraints", []):
        sel = c.get("selection", {}) or {}
        if sel.get("kind") in ("plate_edges", "plate_all"):
            miss = [i for i in sel.get("data", {}).get("ids", []) if i not in ids_p]
            if miss:
                msgs.append("Support '%s' refers to removed plates %s" % (c.get("name"), sorted(set(miss))))
    return msgs


def write_project(d, path):
    big = len(d.get("plates", [])) + len(d.get("beams", [])) > 20000
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as f:
        if big:
            json.dump(d, f, separators=(",", ":"))       # big models: compact, about half the size
        else:
            json.dump(d, f, indent=1)
    try:
        os.replace(tmp, path)                            # an old file is never left half written
    except OSError:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(d, f, indent=None if big else 1)
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
    return path


def read_project(path):
    with open(path, "r", encoding="utf-8") as f:
        d = json.load(f)
    if not isinstance(d, dict) or d.get("format", FEAPRO_FORMAT) not in (FEAPRO_FORMAT, "ALIEF_FEAPRO_TEAM"):
        raise ValueError("Not an ALIEF FEAPRO project file")
    return d


def project_library(d):
    lib = dict(materials=[clean_material(m) for m in d.get("materials", []) if isinstance(m, dict) and m.get("name")],
               plate_props=[], sections=[])
    for p in d.get("plate_props", []):
        lib["plate_props"].append(plate_prop(p["name"], p.get("thickness", 10.0), p.get("material", "Grade A"),
                                             p.get("tc", 0.0), p.get("color", "")))
    for s in d.get("sections", []):
        if s.get("stype") in DIM_FIELDS:
            lib["sections"].append(dict(name=s["name"], stype=s["stype"], dims=normalise_dims(s["stype"], s.get("dims", {})),
                                        material=s.get("material", "Grade A"), tc=float(s.get("tc", 0.0)),
                                        color=s.get("color", "#C9A227")))
    return lib


def project_plate_outlines(p, arc_seg=12):
    """(outer points, [hole outlines]) of a plate of an ALIEF FEAPRO file."""
    P = [list(map(float, q)) for q in p.get("points", [])]
    if len(P) < 3:
        return P, []
    fr = plate_frame(P)
    holes = [opening_outline_global(op, fr, arc_seg) for op in p.get("openings", []) if isinstance(op, dict)]
    return P, holes


# =========================================================================== user profile catalogue
def clean_catalogue(d):
    """User catalogue {stype: [{dims..., 'name': optional}]} - unknown types / bad sizes dropped."""
    out = {}
    if not isinstance(d, dict):
        return out
    for stype, items in d.items():
        if stype not in DIM_FIELDS or not isinstance(items, list):
            continue
        keep = []
        for e in items:
            if not isinstance(e, dict):
                continue
            try:
                dims = normalise_dims(stype, {k: e[k] for k, _ in DIM_FIELDS[stype] if k in e})
            except (TypeError, ValueError):
                continue
            if check_dims(stype, dims):
                continue
            item = dict(dims)
            nm = str(e.get("name", "") or "").strip()
            if nm:
                item["name"] = nm
            keep.append(item)
        if keep:
            out[stype] = keep
    return out


def catalogue_entry_label(stype, e):
    return (e.get("name") or "").strip() or section_label(stype, normalise_dims(stype, {k: v for k, v in e.items() if k != "name"}))


def catalogue_entries(stype, user=None):
    """[(label, dims, source)] - the ALIEF FEAPRO sizes first, then the user's own sizes."""
    out = [(section_label(stype, d), normalise_dims(stype, d), "FEAPRO") for d in CATALOGUE.get(stype, [])]
    seen = set(x[0] for x in out)
    for e in clean_catalogue(user or {}).get(stype, []):
        lab = catalogue_entry_label(stype, e)
        if lab in seen:
            continue
        seen.add(lab)
        out.append((lab, normalise_dims(stype, {k: v for k, v in e.items() if k != "name"}), "User"))
    return out


def catalogue_add(user, stype, dims, name=""):
    """Add a size to the user catalogue. Returns (catalogue, message)."""
    cat = clean_catalogue(user)
    d = normalise_dims(stype, dims)
    err = check_dims(stype, d)
    if err:
        return cat, err
    e = dict(d)
    if name and name.strip():
        e["name"] = name.strip()
    lab = catalogue_entry_label(stype, e)
    if lab in [x[0] for x in catalogue_entries(stype, cat)]:
        return cat, "'%s' is already in the catalogue" % lab
    cat.setdefault(stype, []).append(e)
    return cat, "'%s' added to the %s catalogue" % (lab, stype)


def catalogue_remove(user, stype, label):
    cat = clean_catalogue(user)
    items = cat.get(stype, [])
    left = [e for e in items if catalogue_entry_label(stype, e) != label]
    if len(left) == len(items):
        return cat, "'%s' is an ALIEF FEAPRO standard size or not in your catalogue" % label
    if left:
        cat[stype] = left
    else:
        cat.pop(stype, None)
    return cat, "'%s' removed from the catalogue" % label


def catalogue_merge(a, b):
    """Union of two user catalogues (a first)."""
    out = clean_catalogue(a)
    for stype, items in clean_catalogue(b).items():
        have = set(catalogue_entry_label(stype, e) for e in out.get(stype, []))
        for e in items:
            lab = catalogue_entry_label(stype, e)
            if lab not in have:
                out.setdefault(stype, []).append(e)
                have.add(lab)
    return out


CATALOGUE_CSV_HEAD = ["type", "name", "d1", "d2", "d3", "d4", "d5", "d6"]


def catalogue_to_rows(user):
    """CSV rows: type, name, then the dimensions in the order of DIM_FIELDS."""
    rows = [CATALOGUE_CSV_HEAD]
    for stype in TYPE_ORDER:
        for e in clean_catalogue(user).get(stype, []):
            rows.append([stype, e.get("name", "")] + ["%g" % e[k] for k, _ in DIM_FIELDS[stype]])
    return rows


def catalogue_from_rows(rows):
    """Inverse of catalogue_to_rows (header row optional, HP accepted for BP). Returns (catalogue, messages)."""
    cat, msgs = {}, []
    for i, r in enumerate(rows):
        if not r or not str(r[0]).strip() or str(r[0]).strip().lower() == "type":
            continue
        stype = str(r[0]).strip().upper()
        stype = "BP" if stype == "HP" else stype
        if stype not in DIM_FIELDS:
            msgs.append("row %d: unknown type %s" % (i + 1, r[0]))
            continue
        keys = [k for k, _ in DIM_FIELDS[stype]]
        vals = r[2:2 + len(keys)]
        try:
            dims = {k: float(str(v).replace(",", ".")) for k, v in zip(keys, vals)}
        except ValueError:
            msgs.append("row %d: dimensions are not numbers" % (i + 1))
            continue
        if len(dims) < len(keys):
            msgs.append("row %d: %d dimensions expected" % (i + 1, len(keys)))
            continue
        cat, m = catalogue_add(cat, stype, dims, str(r[1]) if len(r) > 1 else "")
        if "added" not in m:
            msgs.append("row %d: %s" % (i + 1, m))
    return cat, msgs


# =========================================================================== 3D view meshes (pure, mm)
def section_frame(stype, dims, a, b, orient, flange, offset, tp):
    """Origin shift and axes of a profile piece exactly as ALIEF FEAPRO: ex along the beam, ez along the
    web (orient), ey = ez x ex (x flange). offset 'auto' = toe on the plate face (t/2 from the mid-plane),
    any other mode = centroid on the line. Returns (o_start, o_end, ex, ey, ez)."""
    ex = v_unit(v_sub(b, a))
    ez = v_sub(orient, v_mul(ex, v_dot(orient, ex)))
    ez = v_unit(ez, [0, 0, 1] if abs(ex[2]) < 0.9 else [1, 0, 0])
    ey = v_mul(v_cross(ez, ex), 1.0 if flange >= 0 else -1.0)
    if offset == "auto":
        shift = v_mul(ez, tp / 2.0)
    else:
        pr = section_properties(stype, dims)
        shift = v_add(v_mul(ez, -pr["zc"]), v_mul(ey, -pr.get("yc", 0.0)))
    return v_add(a, shift), v_add(b, shift), ex, ey, ez


def prism_mesh(stype, dims, a, b, orient, flange, offset, tp, nseg=16):
    """Display mesh of a profile section swept straight from a to b (mm).
    Returns (vertices, faces (tuples of 3 / 4 indices), edges [(p, q)] for the outline)."""
    o0, o1, ex, ey, ez = section_frame(stype, dims, a, b, orient, flange, offset, tp)

    def P(o, y, z):
        return v_add(v_add(o, v_mul(ey, y)), v_mul(ez, z))
    V, F, E = [], [], []

    def ring(pts):
        k = len(V)
        for y, z in pts:
            V.append(P(o0, y, z))
        for y, z in pts:
            V.append(P(o1, y, z))
        return k
    for sh in section_shapes(stype, dims):
        if sh[0] == "R":
            _, y0, z0, w, h = sh
            pts = [(y0, z0), (y0 + w, z0), (y0 + w, z0 + h), (y0, z0 + h)]
            n = 4
            k = ring(pts)
            for i in range(n):
                j = (i + 1) % n
                F.append((k + i, k + j, k + n + j, k + n + i))
                E.append((V[k + i], V[k + n + i]))
                E.append((V[k + i], V[k + j]))
                E.append((V[k + n + i], V[k + n + j]))
            F.append((k + 3, k + 2, k + 1, k + 0))
            F.append((k + n, k + n + 1, k + n + 2, k + n + 3))
        else:
            _, yc, zc, ro, ri = sh
            circ = [(yc + ro * math.cos(2 * math.pi * i / nseg), zc + ro * math.sin(2 * math.pi * i / nseg)) for i in range(nseg)]
            k = ring(circ)
            n = nseg
            for i in range(n):
                j = (i + 1) % n
                F.append((k + i, k + j, k + n + j, k + n + i))
                E.append((V[k + i], V[k + j]))
                E.append((V[k + n + i], V[k + n + j]))
            for i in range(0, n, max(n // 4, 1)):
                E.append((V[k + i], V[k + n + i]))
            if ri > 0:
                inner = [(yc + ri * math.cos(2 * math.pi * i / nseg), zc + ri * math.sin(2 * math.pi * i / nseg)) for i in range(nseg)]
                m = ring(inner)
                for i in range(n):
                    j = (i + 1) % n
                    F.append((m + j, m + i, m + n + i, m + n + j))
                    F.append((k + j, k + i, m + i, m + j))
                    F.append((k + n + i, k + n + j, m + n + j, m + n + i))
            else:
                c0 = len(V)
                V.append(P(o0, yc, zc))
                V.append(P(o1, yc, zc))
                for i in range(n):
                    j = (i + 1) % n
                    F.append((c0, k + j, k + i))
                    F.append((c0 + 1, k + n + i, k + n + j))
    return V, F, E


def thicken_mesh(verts, normals, faces, boundary, h):
    """Plate thickness solid from a mid-plane mesh: copies at +h / -h along the vertex normals and side
    walls along the boundary edges. Returns (vertices, faces, outline edges)."""
    n = len(verts)
    top = [v_add(v, v_mul(nv, h)) for v, nv in zip(verts, normals)]
    bot = [v_sub(v, v_mul(nv, h)) for v, nv in zip(verts, normals)]
    F = [tuple(f) for f in faces] + [tuple(n + i for i in reversed(f)) for f in faces]
    E = []
    for i, j in boundary:
        F.append((j, i, n + i, n + j))
        E.append((top[i], top[j]))
        E.append((bot[i], bot[j]))
    return top + bot, F, E


def mesh_boundary(faces):
    """Edges used by one face only (index pairs, in face order)."""
    count = {}
    order = {}
    for f in faces:
        m = len(f)
        for k in range(m):
            i, j = f[k], f[(k + 1) % m]
            key = (min(i, j), max(i, j))
            count[key] = count.get(key, 0) + 1
            order[key] = (i, j)
    return [order[k] for k, c in count.items() if c == 1]


# =========================================================================== bracket from two members (pure, mm)
def _closest_line_line(p, d, q, e):
    """Parameters s, t of the closest points p + s d, q + t e of two lines (None when parallel)."""
    a, b, c = v_dot(d, d), v_dot(d, e), v_dot(e, e)
    w = v_sub(p, q)
    dd, ee = v_dot(d, w), v_dot(e, w)
    den = a * c - b * b
    if abs(den) < 1e-12 * max(a * c, 1e-30):
        return None
    s = (b * ee - c * dd) / den
    t = (a * ee - b * dd) / den
    return s, t


def _toward(u, frm, pick, fallback=None):
    """u or -u, whichever points from 'frm' towards 'pick' (fallback point when pick is None)."""
    ref = pick if pick is not None else fallback
    if ref is not None and v_dot(v_sub(ref, frm), u) < 0:
        return v_mul(u, -1.0)
    return u


def bracket_corner(m1, m2, tol=1.0, max_gap=50.0):
    """Corner and leg directions of a bracket between two members.
    A member is dict(kind='profile', a, b, web (or None), pick) or dict(kind='plate', o, n, pick).
    Returns (C, u1, u2) or an error message (str)."""
    k1, k2 = m1["kind"], m2["kind"]
    if k1 == "profile" and k2 == "profile":
        d, e = v_unit(v_sub(m1["b"], m1["a"])), v_unit(v_sub(m2["b"], m2["a"]))
        st = _closest_line_line(m1["a"], d, m2["a"], e)
        if st is None:
            return "The two profiles are parallel - pick a profile and a plate, or two crossing members."
        c1 = v_add(m1["a"], v_mul(d, st[0]))
        c2 = v_add(m2["a"], v_mul(e, st[1]))
        if v_dist(c1, c2) > max_gap:
            return "The two profiles do not meet (%.0f mm apart)." % v_dist(c1, c2)
        C = v_mul(v_add(c1, c2), 0.5)
        far1 = m1["a"] if v_dist(m1["a"], C) > v_dist(m1["b"], C) else m1["b"]
        far2 = m2["a"] if v_dist(m2["a"], C) > v_dist(m2["b"], C) else m2["b"]
        u1 = _toward(d, C, m1.get("pick") if m1.get("pick") and v_dist(m1["pick"], C) > tol else None, far1)
        u2 = _toward(e, C, m2.get("pick") if m2.get("pick") and v_dist(m2["pick"], C) > tol else None, far2)
        return C, u1, u2
    if k1 == "plate" and k2 == "profile":
        r = bracket_corner(m2, m1, tol, max_gap)
        return r if isinstance(r, str) else (r[0], r[2], r[1])
    if k1 == "profile" and k2 == "plate":
        d = v_unit(v_sub(m1["b"], m1["a"]))
        n2 = v_unit(m2["n"])
        den = v_dot(d, n2)
        if abs(den) < 1e-6:
            return "The profile runs parallel to the plate - it does not end on it."
        s = v_dot(v_sub(m2["o"], m1["a"]), n2) / den
        C = v_add(m1["a"], v_mul(d, s))
        far1 = m1["a"] if v_dist(m1["a"], C) > v_dist(m1["b"], C) else m1["b"]
        u1 = _toward(d, C, m1.get("pick") if m1.get("pick") and v_dist(m1["pick"], C) > tol else None, far1)
        web = m1.get("web")
        if web is not None and v_len(v_sub(web, v_mul(u1, v_dot(web, u1)))) > 1e-6:
            nb = v_unit(v_cross(u1, web))
            v = v_unit(v_cross(nb, n2))
            if v_len(v) < 1e-9:
                return "The profile web is parallel to the plate."
            if v_dot(v, web) < -1e-9:
                v = v_mul(v, -1.0)
            elif abs(v_dot(v, web)) <= 1e-9:
                v = _toward(v, C, m2.get("pick"))
        else:
            # no web direction: bracket in the plane of the profile and the picked point on the plate
            pk = m2.get("pick")
            if pk is None:
                return "Pick the plate near the place where the bracket should go."
            w = v_sub(pk, C)
            w = v_sub(w, v_mul(n2, v_dot(w, n2)))
            w = v_sub(w, v_mul(d, v_dot(w, d)))
            if v_len(w) < tol:
                return "Pick the plate a bit away from the profile end."
            v = v_unit(w)
        return C, u1, v
    # plate - plate
    n1, n2 = v_unit(m1["n"]), v_unit(m2["n"])
    dl = v_cross(n1, n2)
    if v_len(dl) < 1e-6:
        return "The two plates are parallel."
    dl = v_unit(dl)
    # a point on the intersection line: solve n1.x = n1.o1, n2.x = n2.o2, dl.x = dl.pick
    pk = m1.get("pick") or m1["o"]
    h1, h2, h3 = v_dot(n1, m1["o"]), v_dot(n2, m2["o"]), v_dot(dl, pk)
    # x = (h1 (n2 x dl) + h2 (dl x n1) + h3 (n1 x n2)) / (n1 . (n2 x dl))
    den = v_dot(n1, v_cross(n2, dl))
    C = v_mul(v_add(v_add(v_mul(v_cross(n2, dl), h1), v_mul(v_cross(dl, n1), h2)), v_mul(v_cross(n1, n2), h3)), 1.0 / den)
    u1 = v_unit(v_cross(dl, n1))
    u2 = v_unit(v_cross(dl, n2))
    u1 = _toward(u1, C, m1.get("pick"), m1["o"])
    u2 = _toward(u2, C, m2.get("pick"), m2["o"])
    return C, u1, u2


def bracket_polygon(C0, d1, d2, a, b, toe):
    """Bracket outline (corner, leg a along d1, leg b along d2, toes of height 'toe' normal to the legs).
    Returns (points, Ap, Bp, n) - Ap / Bp are the ends of the free edge, n the plate normal."""
    d1, d2 = v_unit(d1), v_unit(d2)
    n = v_unit(v_cross(d1, d2))
    A = v_add(C0, v_mul(d1, a))
    B = v_add(C0, v_mul(d2, b))
    e1 = v_unit(v_cross(n, d1))
    if v_dot(e1, d2) < 0:
        e1 = v_mul(e1, -1.0)
    e2 = v_unit(v_cross(d2, n))
    if v_dot(e2, d1) < 0:
        e2 = v_mul(e2, -1.0)
    poly = [C0, A]
    if toe > 0:
        Ap, Bp = v_add(A, v_mul(e1, toe)), v_add(B, v_mul(e2, toe))
        poly += [Ap, Bp]
    else:
        Ap, Bp = A, B
    poly.append(B)
    return poly, Ap, Bp, n


def bracket_auto_leg(heights_mm, factor=2.0, minimum=150.0, step=25.0):
    """Rule-of-thumb arm length: factor x the deepest connected profile, rounded up to 'step'."""
    h = max([x for x in heights_mm if x] or [0.0])
    leg = max(minimum, factor * h)
    return math.ceil(leg / step - 1e-9) * step


# =========================================================================== team sync: 3-way library merge
def _item_key(x):
    return json.dumps(x, sort_keys=True)


def merge3_library(base, mine, shared, keys=("materials", "plate_props", "sections")):
    """Three-way merge of library lists by name. base = state at the last sync on this computer.
    Returns (new_mine, new_shared, conflicts, n_in, n_out)."""
    new_mine = dict(mine)
    new_shared = dict(shared)
    conflicts = []
    n_in = n_out = 0
    for key in keys:
        B = {x["name"]: x for x in (base or {}).get(key, []) if isinstance(x, dict) and x.get("name")}
        M = {x["name"]: x for x in (mine or {}).get(key, []) if isinstance(x, dict) and x.get("name")}
        S = {x["name"]: x for x in (shared or {}).get(key, []) if isinstance(x, dict) and x.get("name")}
        outM, outS = dict(M), dict(S)
        for nm in set(M) | set(S):
            m, s_, b = M.get(nm), S.get(nm), B.get(nm)
            if m is not None and s_ is None:
                outS[nm] = m
                n_out += 1
            elif s_ is not None and m is None:
                if b is None:          # new on the shared side (deletions are never pushed)
                    outM[nm] = s_
                    n_in += 1
                else:
                    outM[nm] = s_      # deleted locally but still used by others: keep it
            elif _item_key(m) != _item_key(s_):
                mine_changed = b is None or _item_key(m) != _item_key(b)
                shared_changed = b is None or _item_key(s_) != _item_key(b)
                if mine_changed and not shared_changed:
                    outS[nm] = m
                    n_out += 1
                elif shared_changed and not mine_changed:
                    outM[nm] = s_
                    n_in += 1
                else:
                    outM[nm] = s_
                    n_in += 1
                    conflicts.append("%s '%s' was changed here and by a team member - the shared version is kept" % (key, nm))
        order_m = [x["name"] for x in (mine or {}).get(key, []) if isinstance(x, dict) and x.get("name")]
        order_s = [x["name"] for x in (shared or {}).get(key, []) if isinstance(x, dict) and x.get("name")]
        new_mine[key] = [outM[n] for n in order_m if n in outM] + [outM[n] for n in sorted(outM) if n not in order_m]
        new_shared[key] = [outS[n] for n in order_s if n in outS] + [outS[n] for n in sorted(outS) if n not in order_s]
    cat = catalogue_merge((shared or {}).get("catalogue"), (mine or {}).get("catalogue"))
    new_shared["catalogue"] = cat
    new_mine["catalogue"] = catalogue_merge((mine or {}).get("catalogue"), cat)
    return new_mine, new_shared, conflicts, n_in, n_out


def safe_zone(name):
    keep = "".join(ch if (ch.isalnum() or ch in "-_") else "_" for ch in str(name or "").strip().upper())
    return keep.strip("_")[:40] or "ZONE"


# =========================================================================== legend (property index)
def legend_rows(members, lib, mode="Property", active_prop="", active_sec=""):
    """Rows of the on-screen property index.
    members: [dict(kind='plate'|'profile', name=property / section, qty=area mm2 | length mm)]
    Returns dict(groups=[(title, [(colour, label, detail, active)])], total_kg, counts)."""
    mats, props, secs = library_index(lib)
    area_cache = {}

    def dens(mat):
        m = mats.get(mat)
        return float(m.get("density", 7850.0)) if m else 7850.0

    def sec_area(nm):
        if nm not in area_cache:
            s = secs.get(nm)
            try:
                area_cache[nm] = section_properties(s["stype"], s["dims"])["A"] if s else 0.0
            except Exception:
                area_cache[nm] = 0.0
        return area_cache[nm]
    plate_rows, prof_rows, mat_rows, thk_rows = {}, {}, {}, {}
    total = 0.0
    n_pl = n_pr = 0
    for m in members:
        nm = m.get("name", "")
        if m["kind"] == "plate":
            n_pl += 1
            pp = props.get(nm)
            t = pp["thickness"] if pp else 0.0
            mat = pp["material"] if pp else "?"
            kg = m.get("qty", 0.0) * t * dens(mat) * 1e-9
            r = plate_rows.setdefault(nm, [0, 0.0, 0.0, mat, t])
            r[0] += 1
            r[1] += m.get("qty", 0.0)
            r[2] += kg
            q = thk_rows.setdefault(t, [0, 0.0, 0.0])
            q[0] += 1
            q[1] += m.get("qty", 0.0)
            q[2] += kg
        else:
            n_pr += 1
            s = secs.get(nm)
            mat = s["material"] if s else "?"
            kg = m.get("qty", 0.0) * sec_area(nm) * dens(mat) * 1e-9
            r = prof_rows.setdefault(nm, [0, 0.0, 0.0, mat])
            r[0] += 1
            r[1] += m.get("qty", 0.0)
            r[2] += kg
        mr = mat_rows.setdefault(mat, [0, 0, 0.0])
        mr[0 if m["kind"] == "plate" else 1] += 1
        mr[2] += kg
        total += kg

    def kgs(v):
        return "%.2f t" % (v / 1000.0) if v >= 1000.0 else "%.0f kg" % v
    groups = []
    if mode == "Material":
        rows = []
        for mat in sorted(mat_rows):
            c, p, kg = mat_rows[mat]
            col = mats[mat].get("color", "#7FA7C9") if mat in mats else "#B0B0B0"
            rows.append((col, mat, "%d plates  %d profiles  %s" % (c, p, kgs(kg)), False))
        groups.append(("MATERIALS", rows))
    elif mode == "Thickness":
        rows = []
        for t in sorted(thk_rows):
            c, a, kg = thk_rows[t]
            rows.append((thickness_color(t), "t = %g mm" % t, "%d pcs  %.1f m2  %s" % (c, a * 1e-6, kgs(kg)), False))
        groups.append(("PLATE THICKNESS", rows))
    else:
        rows = []
        order = [p["name"] for p in lib.get("plate_props", [])]
        for nm in sorted(plate_rows, key=lambda k: (order.index(k) if k in order else 1e9, k)):
            c, a, kg, mat, t = plate_rows[nm]
            col = (props[nm].get("color") or thickness_color(t)) if nm in props else "#B0B0B0"
            rows.append((col, nm if nm in props else nm + "  (NOT IN LIBRARY)", "%d pcs  %.1f m2  %s" % (c, a * 1e-6, kgs(kg)),
                         nm == active_prop))
        groups.append(("PLATES", rows))
    if mode != "Material":
        rows = []
        order = [s["name"] for s in lib.get("sections", [])]
        for nm in sorted(prof_rows, key=lambda k: (order.index(k) if k in order else 1e9, k)):
            c, L, kg, mat = prof_rows[nm]
            col = secs[nm].get("color", "#C9A227") if nm in secs else "#808080"
            lab = ("%s  %s" % (nm, mat)) if nm in secs else nm + "  (NOT IN LIBRARY)"
            rows.append((col, lab, "%d pcs  %.1f m  %s" % (c, L * 1e-3, kgs(kg)), nm == active_sec))
        groups.append(("PROFILES", rows))
    return dict(groups=groups, total_kg=total, counts=(n_pl, n_pr), total_text=kgs(total))


# =========================================================================== fast curved plating (v1.2)
def iso_params(ts, seg_len, step, seg_bend=None, shape_tol=None, max_n=600):
    """Parameters along one surface direction so that every interval is about 'step' long in 3D and, where the
    surface bends, short enough for the chord to stay within shape_tol (sagitta = L^2 k / 8).
    ts: sample parameters t0 < .. < tn; seg_len[i]: max 3D length of interval (t_i, t_i+1) over the other
    direction; seg_bend[i]: max curvature (1/mm) found there. Returns the new parameters (ends included)."""
    n = len(ts) - 1
    if n < 1:
        return list(ts)
    w = []
    for i in range(n):
        L = max(seg_len[i], 0.0)
        lim = step
        if seg_bend is not None and shape_tol and seg_bend[i] > 1e-12:
            # never finer than step / 8: a crease or a pole is not resolved by subdividing
            lim = max(min(lim, math.sqrt(8.0 * shape_tol / seg_bend[i])), step / 8.0)
        w.append(L / max(lim, 1e-9))
    tot = sum(w)
    m = max(1, min(int(math.ceil(tot - 1e-9)), max_n))
    cum = [0.0]
    for x in w:
        cum.append(cum[-1] + x)
    out = [ts[0]]
    j = 0
    for k in range(1, m):
        target = tot * k / m
        while j < n - 1 and cum[j + 1] < target:
            j += 1
        span = cum[j + 1] - cum[j]
        f = (target - cum[j]) / span if span > 1e-15 else 0.0
        out.append(ts[j] + f * (ts[j + 1] - ts[j]))
    out.append(ts[-1])
    return out


def grid_lengths(P):
    """P[i][j] sample points (mm) of a surface grid. Returns (len_u[i], len_v[j], bend_u[i], bend_v[j]):
    the largest interval length and curvature of every u- / v-interval over the other direction."""
    nu, nv = len(P), len(P[0])
    lu = [0.0] * (nu - 1)
    lv = [0.0] * (nv - 1)
    bu = [0.0] * (nu - 1)
    bv = [0.0] * (nv - 1)
    for i in range(nu - 1):
        for j in range(nv):
            d = v_dist(P[i][j], P[i + 1][j])
            if d > lu[i]:
                lu[i] = d
    for j in range(nv - 1):
        for i in range(nu):
            d = v_dist(P[i][j], P[i][j + 1])
            if d > lv[j]:
                lv[j] = d

    def bend(a, b, c):
        e1, e2 = v_sub(b, a), v_sub(c, b)
        l1, l2 = v_len(e1), v_len(e2)
        # very short or very uneven chords (poles, collapsed rows) give no usable curvature
        if l1 < 1e-3 or l2 < 1e-3 or min(l1, l2) < 0.25 * max(l1, l2):
            return 0.0
        cs = max(-1.0, min(1.0, v_dot(e1, e2) / (l1 * l2)))
        return math.acos(cs) / (0.5 * (l1 + l2))
    for i in range(1, nu - 1):
        for j in range(nv):
            k = bend(P[i - 1][j], P[i][j], P[i + 1][j])
            bu[i - 1] = max(bu[i - 1], k)
            bu[i] = max(bu[i], k)
    for j in range(1, nv - 1):
        for i in range(nu):
            k = bend(P[i][j - 1], P[i][j], P[i][j + 1])
            bv[j - 1] = max(bv[j - 1], k)
            bv[j] = max(bv[j], k)
    return lu, lv, bu, bv


class GridIndex(object):
    """Uniform 3D grid of bounding boxes for fast 'what is near here' queries."""

    def __init__(self, cell):
        self.cell = max(float(cell), 1e-6)
        self.cells = {}

    def _rng(self, lo, hi):
        c = self.cell
        return [range(int(math.floor(lo[k] / c)), int(math.floor(hi[k] / c)) + 1) for k in range(3)]

    def add(self, key, lo, hi):
        rx, ry, rz = self._rng(lo, hi)
        if len(rx) * len(ry) * len(rz) > 200000:          # huge item: keep it in a list checked always
            self.cells.setdefault("big", set()).add(key)
            return
        for gx in rx:
            for gy in ry:
                for gz in rz:
                    self.cells.setdefault((gx, gy, gz), set()).add(key)

    def query(self, lo, hi):
        out = set(self.cells.get("big", ()))
        rx, ry, rz = self._rng(lo, hi)
        if len(rx) * len(ry) * len(rz) > 200000:
            for k, s in self.cells.items():
                out |= s
            return out
        for gx in rx:
            for gy in ry:
                for gz in rz:
                    s = self.cells.get((gx, gy, gz))
                    if s:
                        out |= s
        return out


def bbox_of(points, grow=0.0):
    lo = [min(p[k] for p in points) - grow for k in range(3)]
    hi = [max(p[k] for p in points) + grow for k in range(3)]
    return lo, hi


def closest_on_triangle(p, a, b, c):
    """Closest point to p on triangle abc (Ericson). Returns (point, distance)."""
    ab, ac, ap = v_sub(b, a), v_sub(c, a), v_sub(p, a)
    d1, d2 = v_dot(ab, ap), v_dot(ac, ap)
    if d1 <= 0.0 and d2 <= 0.0:
        return list(a), v_dist(p, a)
    bp = v_sub(p, b)
    d3, d4 = v_dot(ab, bp), v_dot(ac, bp)
    if d3 >= 0.0 and d4 <= d3:
        return list(b), v_dist(p, b)
    vc = d1 * d4 - d3 * d2
    if vc <= 0.0 and d1 >= 0.0 and d3 <= 0.0:
        t = d1 / (d1 - d3)
        q = v_add(a, v_mul(ab, t))
        return q, v_dist(p, q)
    cp = v_sub(p, c)
    d5, d6 = v_dot(ab, cp), v_dot(ac, cp)
    if d6 >= 0.0 and d5 <= d6:
        return list(c), v_dist(p, c)
    vb = d5 * d2 - d1 * d6
    if vb <= 0.0 and d2 >= 0.0 and d6 <= 0.0:
        t = d2 / (d2 - d6)
        q = v_add(a, v_mul(ac, t))
        return q, v_dist(p, q)
    va = d3 * d6 - d5 * d4
    if va <= 0.0 and (d4 - d3) >= 0.0 and (d5 - d6) >= 0.0:
        t = (d4 - d3) / ((d4 - d3) + (d5 - d6))
        q = v_add(b, v_mul(v_sub(c, b), t))
        return q, v_dist(p, q)
    den = va + vb + vc
    if abs(den) < 1e-300:
        return list(a), v_dist(p, a)
    v, w = vb / den, vc / den
    q = v_add(a, v_add(v_mul(ab, v), v_mul(ac, w)))
    return q, v_dist(p, q)


class ShellMesh(object):
    """Conforming triangle mesh of the curved plating (mm), cut along the planes of the webs / decks landing on
    it - the fast replacement of splitting dense NURBS surfaces with full planes. All work is local (grid
    index), so the time grows with the number of facets, not with facets x planes.

    V: vertices, T: triangles (vertex index triples, consistently oriented per owner), owners: per triangle."""

    def __init__(self, V, T, owners, cell):
        self.V = [list(p) for p in V]
        self.T = [tuple(t) for t in T]
        self.owner = list(owners)
        self.alive = [True] * len(self.T)
        self.idx = GridIndex(cell)
        self.vt = {}                     # vertex -> set of live triangles
        ecount = {}
        for i, t in enumerate(self.T):
            self._index(i)
            for k in range(3):
                self.vt.setdefault(t[k], set()).add(i)
                e = (min(t[k], t[(k + 1) % 3]), max(t[k], t[(k + 1) % 3]))
                ecount[e] = ecount.get(e, 0) + 1
        self.naked = set(e for e, c in ecount.items() if c == 1)
        self.boundary = set()
        for a, b in self.naked:
            self.boundary.add(a)
            self.boundary.add(b)
        self.on = {}                     # vertex -> {plane id: (o, n)}
        self.n_slid = 0
        self.n_cut = 0

    # ---------------------------------------------------------------- queries
    def _index(self, i):
        lo, hi = bbox_of([self.V[k] for k in self.T[i]])
        self.idx.add(i, lo, hi)

    def tris_in_box(self, lo, hi):
        out = []
        for i in self.idx.query(lo, hi):
            if not self.alive[i]:
                continue
            tlo, thi = bbox_of([self.V[k] for k in self.T[i]])
            if all(tlo[k] <= hi[k] and thi[k] >= lo[k] for k in range(3)):
                out.append(i)
        return out

    def bbox(self):
        pts = [self.V[k] for i, t in enumerate(self.T) if self.alive[i] for k in t]
        return bbox_of(pts) if pts else ([0, 0, 0], [0, 0, 0])

    def closest(self, p, r):
        """(distance, triangle) of the nearest triangle within r of p, or (None, None)."""
        lo = [p[k] - r for k in range(3)]
        hi = [p[k] + r for k in range(3)]
        best, bt = None, None
        for ti in self.tris_in_box(lo, hi):
            a, b, c = (self.V[k] for k in self.T[ti])
            q, d = closest_on_triangle(p, a, b, c)
            if d <= r and (best is None or d < best):
                best, bt = d, ti
        return best, bt

    def naked_index(self, cell):
        g = GridIndex(cell)
        segs = []
        for a, b in self.naked:
            segs.append((a, b))
            lo, hi = bbox_of([self.V[a], self.V[b]])
            g.add(len(segs) - 1, lo, hi)
        return g, segs

    def dist_to_boundary(self, p, r, g, segs):
        lo = [p[k] - r for k in range(3)]
        hi = [p[k] + r for k in range(3)]
        best = None
        for si in g.query(lo, hi):
            a, b = segs[si]
            c, _ = seg_closest3d(p, self.V[a], self.V[b])
            d = v_dist(p, c)
            if best is None or d < best:
                best = d
        return best

    # ---------------------------------------------------------------- edits
    def _tri_normal(self, t, pos=None):
        P = [pos.get(k, self.V[k]) if pos else self.V[k] for k in t]
        return v_cross(v_sub(P[1], P[0]), v_sub(P[2], P[0]))

    def _move_ok(self, vi, q):
        """Moving vertex vi to q must not flip or collapse any of its triangles."""
        pos = {vi: q}
        for ti in self.vt.get(vi, ()):
            t = self.T[ti]
            n0 = self._tri_normal(t)
            n1 = self._tri_normal(t, pos)
            a0 = v_len(n0)
            if a0 < 1e-12:
                continue
            if v_dot(n0, n1) <= 0.0 or v_len(n1) < 0.1 * a0:
                return False
        return True

    def _put_on(self, vi, pid, o, n, max_move):
        planes = dict(self.on.get(vi, {}))
        planes[pid] = (o, n)
        q = list(self.V[vi])
        for _ in range(60 if len(planes) > 1 else 1):
            for oo, nn in planes.values():
                q = v_sub(q, v_mul(nn, v_dot(v_sub(q, oo), nn)))
        if v_dist(q, self.V[vi]) > max_move:
            return False
        self.V[vi] = q
        self.on[vi] = planes
        self._reindex_vertex(vi)
        return True

    def _reindex_vertex(self, vi):
        for ti in self.vt.get(vi, ()):
            self._index(ti)

    def snap_plane(self, pid, o, n, lo, hi, tol):
        """Vertices within tol of the plane (inside the box) are moved onto it. Returns their indices."""
        got = []
        seen = set()
        for ti in self.tris_in_box([x - tol for x in lo], [x + tol for x in hi]):
            for vi in self.T[ti]:
                if vi in seen:
                    continue
                seen.add(vi)
                if pid in self.on.get(vi, {}):
                    got.append(vi)
                    continue
                p = self.V[vi]
                if all(lo[k] - tol <= p[k] <= hi[k] + tol for k in range(3)) and abs(v_dot(v_sub(p, o), n)) <= tol:
                    if self._put_on(vi, pid, o, n, 4.0 * tol):
                        got.append(vi)
        return got

    def cut_plane(self, pid, o, n, lo, hi, tol, slide=0.3):
        """Cut the triangles along the plane inside the box. Vertices within tol are snapped onto the plane,
        vertices close to the cut (fraction < slide of an edge) slide along that edge onto it (no slivers),
        the rest of the crossing edges get a new vertex exactly on the plane; triangles sharing a cut edge are
        all cut, so the mesh stays conforming. Returns the indices of the vertices on the plane."""
        self.snap_plane(pid, o, n, lo, hi, tol)
        glo = [x - tol for x in lo]
        ghi = [x + tol for x in hi]

        def d(vi):
            return 0.0 if pid in self.on.get(vi, {}) else v_dot(v_sub(self.V[vi], o), n)

        def crossings(cand):
            out = {}
            for ti in cand:
                if not self.alive[ti]:
                    continue
                t = self.T[ti]
                for k in range(3):
                    a, b = t[k], t[(k + 1) % 3]
                    key = (min(a, b), max(a, b))
                    if key in out:
                        continue
                    da, db = d(key[0]), d(key[1])
                    if da * db < 0.0:
                        f = da / (da - db)
                        A, B = self.V[key[0]], self.V[key[1]]
                        p = v_add(A, v_mul(v_sub(B, A), f))
                        if all(glo[m] <= p[m] <= ghi[m] for m in range(3)):
                            out[key] = (f, p)
            return out
        cand = self.tris_in_box(glo, ghi)
        cr = crossings(cand)
        # slide vertices that are close to the cut along their edge onto the plane
        if slide > 0.0 and cr:
            order = sorted(cr.items(), key=lambda kv: min(kv[1][0], 1.0 - kv[1][0]))
            moved = set()
            for (a, b), (f, p) in order:
                vi, other = (a, b) if f <= 0.5 else (b, a)
                if min(f, 1.0 - f) > slide or vi in moved:
                    continue
                if d(a) * d(b) >= 0.0:          # no longer crossing (an end already moved)
                    continue
                # a vertex on other planes may only slide along an edge lying in those planes, a boundary
                # vertex only along the boundary - so earlier cuts and the shell outline stay exact
                pv, po = self.on.get(vi, {}), self.on.get(other, {})
                if any(k not in po for k in pv):
                    continue
                if vi in self.boundary and (a, b) not in self.naked:
                    continue
                if not self._move_ok(vi, p):
                    continue
                self.V[vi] = list(p)
                planes = dict(pv)
                planes[pid] = (o, n)
                self.on[vi] = planes
                self._reindex_vertex(vi)
                moved.add(vi)
                self.n_slid += 1
            if moved:
                cr = crossings(cand)
        if cr:
            newv = {}
            for key, (f, p) in cr.items():
                self.V.append(list(p))
                vi = len(self.V) - 1
                newv[key] = vi
                a, b = key
                pa, pb = self.on.get(a, {}), self.on.get(b, {})
                planes = dict((k, pa[k]) for k in pa if k in pb)
                planes[pid] = (o, n)
                self.on[vi] = planes
                if key in self.naked:
                    self.naked.discard(key)
                    self.naked.add((min(a, vi), max(a, vi)))
                    self.naked.add((min(b, vi), max(b, vi)))
                    self.boundary.add(vi)
            self.n_cut += len(newv)
            self._apply_splits(cand, newv)
        out = []
        seen = set()
        for ti in self.tris_in_box(glo, ghi):
            for vi in self.T[ti]:
                if vi not in seen:
                    seen.add(vi)
                    if pid in self.on.get(vi, {}):
                        out.append(vi)
        return out

    def _apply_splits(self, cand, newv):
        """Split the triangles of cand at the new edge vertices newv {(a, b): vertex} (1, 2 or 3 per triangle)."""
        made = []
        for ti in cand:
            if not self.alive[ti]:
                continue
            t = self.T[ti]
            ms = []
            for k in range(3):
                a, b = t[k], t[(k + 1) % 3]
                m = newv.get((min(a, b), max(a, b)))
                if m is not None:
                    ms.append((k, m))
            if not ms:
                continue
            parts = self._split(t, ms)
            own = self.owner[ti]
            self.alive[ti] = False
            for vi in t:
                self.vt.get(vi, set()).discard(ti)
            for pt in parts:
                if len(set(pt)) < 3:
                    continue
                self.T.append(tuple(pt))
                self.owner.append(own)
                self.alive.append(True)
                ni = len(self.T) - 1
                self._index(ni)
                made.append(ni)
                for vi in pt:
                    self.vt.setdefault(vi, set()).add(ni)
        return made

    def refine(self, project, tol, max_levels=4, job=None):
        """Split every edge whose middle is more than tol off the real surface, at the real surface point
        (project(owner, point) -> point), level by level - so the facets follow the plating within tol even if
        the mesher left them too coarse. Returns the number of new vertices."""
        added = 0
        edges = None
        for level in range(max_levels):
            if edges is None:
                tris = [i for i in range(len(self.T)) if self.alive[i]]
            else:
                tris = edges
            seen = {}
            for ti in tris:
                if not self.alive[ti]:
                    continue
                t = self.T[ti]
                for k in range(3):
                    a, b = t[k], t[(k + 1) % 3]
                    e = (min(a, b), max(a, b))
                    if e not in seen:
                        seen[e] = self.owner[ti]
            newv = {}
            n = 0
            for e, own in seen.items():
                n += 1
                if job is not None and n % 500 == 0:
                    job.tick(added)
                mid = v_lerp(self.V[e[0]], self.V[e[1]], 0.5)
                q = project(own, mid)
                # a far 'closest point' is another part of the surface (fold, other side of a bulb): ignore it
                if q is not None and tol < v_dist(q, mid) <= 0.3 * v_dist(self.V[e[0]], self.V[e[1]]):
                    self.V.append(list(q))
                    newv[e] = len(self.V) - 1
            if not newv:
                break
            for e, vi in newv.items():
                if e in self.naked:
                    self.naked.discard(e)
                    self.naked.add((min(e[0], vi), max(e[0], vi)))
                    self.naked.add((min(e[1], vi), max(e[1], vi)))
                    self.boundary.add(vi)
            cand = set()
            for (a, b) in newv:
                cand |= (self.vt.get(a, set()) & self.vt.get(b, set()))
            edges = self._apply_splits(sorted(cand), newv)
            added += len(newv)
        self.n_refined = added
        return added

    def _split(self, t, ms):
        if len(ms) == 3:
            m0, m1, m2 = ms[0][1], ms[1][1], ms[2][1]
            return [(t[0], m0, m2), (m0, t[1], m1), (m2, m1, t[2]), (m0, m1, m2)]
        if len(ms) == 1:
            k, m = ms[0]
            a, b, c = t[k], t[(k + 1) % 3], t[(k + 2) % 3]
            return [(a, m, c), (m, b, c)]
        (k1, m1), (k2, m2) = ms[0], ms[1]
        if (k1 + 1) % 3 == k2:
            A, P, Q = t[k2], t[k1], t[(k2 + 1) % 3]
            # P -> m1 -> A -> m2 -> Q ; quad P m1 m2 Q split along the shorter diagonal
            if v_dist(self.V[P], self.V[m2]) <= v_dist(self.V[m1], self.V[Q]):
                return [(m1, A, m2), (P, m1, m2), (P, m2, Q)]
            return [(m1, A, m2), (P, m1, Q), (m1, m2, Q)]
        A, B, Cc = t[k1], t[(k1 + 1) % 3], t[k2]
        # A -> m1 -> B -> Cc -> m2 ; quad m1 B Cc m2
        if v_dist(self.V[m1], self.V[Cc]) <= v_dist(self.V[B], self.V[m2]):
            return [(A, m1, m2), (m1, B, Cc), (m1, Cc, m2)]
        return [(A, m1, m2), (m1, B, m2), (B, Cc, m2)]

    # ---------------------------------------------------------------- output
    def plane_points(self, pid, lo, hi, grow=0.0):
        """Coordinates of the vertices lying on plane pid inside the box (after all cuts)."""
        glo = [x - grow for x in lo]
        ghi = [x + grow for x in hi]
        out, seen = [], set()
        for ti in self.tris_in_box(glo, ghi):
            for vi in self.T[ti]:
                if vi not in seen:
                    seen.add(vi)
                    if pid in self.on.get(vi, {}):
                        out.append(list(self.V[vi]))
        return out

    def facets(self):
        out = []
        for i, t in enumerate(self.T):
            if self.alive[i]:
                pts = [list(self.V[k]) for k in t]
                if polygon_area3d(pts) > 1e-6:
                    out.append(dict(pts=pts, owner=self.owner[i]))
        return out

    def count(self):
        return sum(1 for a in self.alive if a)

    def decimate(self, target, max_len, tol, min_angle=12.0, job=None, max_absorbed=16):
        """Coarsen the shell where the mesher left it denser than needed (tensor-product grids of dense or
        unevenly parameterised NURBS): collapse edges shorter than target into a neighbour while every removed
        point stays within tol of the new facets, no edge gets longer than max_len, no facet flips or gets an
        angle below min_angle, and the outline (free edges, seams between plates) keeps its shape.
        Run it before the cuts. Returns the number of removed vertices."""
        import heapq
        V, T, vt = self.V, self.T, self.vt
        cos_flip = math.cos(math.radians(45.0))
        # feature edges: free edges and seams between different plates
        ecount = {}
        for i, t in enumerate(T):
            if not self.alive[i]:
                continue
            for k in range(3):
                a, b = t[k], t[(k + 1) % 3]
                e = (min(a, b), max(a, b))
                ecount.setdefault(e, []).append(i)
        feat = {}
        for e, ts in ecount.items():
            if len(ts) == 1 or (len(ts) == 2 and self.owner[ts[0]] != self.owner[ts[1]]) or len(ts) > 2:
                feat.setdefault(e[0], set()).add(e[1])
                feat.setdefault(e[1], set()).add(e[0])
        absorbed = {}

        def nbrs(v):
            out = set()
            for ti in vt.get(v, ()):
                out.update(T[ti])
            out.discard(v)
            return out

        def min_ang(P):
            out = 180.0
            for k in range(3):
                a, b, c = P[k], P[(k + 1) % 3], P[(k + 2) % 3]
                u, w = v_sub(b, a), v_sub(c, a)
                lu, lw = v_len(u), v_len(w)
                if lu < 1e-12 or lw < 1e-12:
                    return 0.0
                out = min(out, math.degrees(math.acos(max(-1.0, min(1.0, v_dot(u, w) / (lu * lw))))))
            return out

        def try_collapse(v, w):
            if v == w or v not in vt or w not in vt:
                return False
            if v in feat:
                fv = feat[v]
                if len(fv) != 2 or w not in fv:
                    return False
                a, b = sorted(fv)
                c, _ = seg_closest3d(V[v], V[a], V[b])
                if v_dist(c, V[v]) > 0.5 * tol:
                    return False
            sv = vt[v]
            shared = [ti for ti in sv if w in T[ti]]
            if not shared or len(shared) > 2:
                return False
            opp = set()
            for ti in shared:
                opp.update(x for x in T[ti] if x != v and x != w)
            if (nbrs(v) & nbrs(w)) != opp:
                return False
            new_tris = []
            for ti in sv:
                if ti in shared:
                    continue
                t = T[ti]
                nt = tuple(w if x == v else x for x in t)
                P0 = [V[x] for x in t]
                P1 = [V[x] for x in nt]
                n0 = v_cross(v_sub(P0[1], P0[0]), v_sub(P0[2], P0[0]))
                n1 = v_cross(v_sub(P1[1], P1[0]), v_sub(P1[2], P1[0]))
                l0, l1 = v_len(n0), v_len(n1)
                if l1 < 1e-9 or v_dot(n0, n1) < cos_flip * l0 * l1:
                    return False
                if min_ang(P1) < min(min_angle, min_ang(P0)):
                    return False
                for x in nt:
                    if x != w and v_dist(V[x], V[w]) > max_len:
                        return False
                new_tris.append(nt)
            star = new_tris + [T[ti] for ti in vt[w] if ti not in shared]
            pts = [V[v]] + absorbed.get(v, []) + absorbed.get(w, [])
            for p in pts:
                best = 1e30
                for t in star:
                    q, d = closest_on_triangle(p, V[t[0]], V[t[1]], V[t[2]])
                    if d < best:
                        best = d
                        if best <= tol:
                            break
                if best > tol:
                    return False
            # apply
            for ti in shared:
                self.alive[ti] = False
                for x in T[ti]:
                    vt.get(x, set()).discard(ti)
            for ti in list(sv):
                if ti in shared or not self.alive[ti]:
                    continue
                T[ti] = tuple(w if x == v else x for x in T[ti])
                vt.setdefault(w, set()).add(ti)
                self._index(ti)
            vt.pop(v, None)
            ab = absorbed.pop(v, []) + absorbed.get(w, []) + [list(V[v])]
            if len(ab) > max_absorbed:
                ab = ab[-max_absorbed:]
            absorbed[w] = ab
            if v in feat:
                for x in feat.pop(v):
                    feat[x].discard(v)
                    if x != w:
                        feat[x].add(w)
                        feat.setdefault(w, set()).add(x)
                feat[w].discard(w)
            if v in self.boundary:
                self.boundary.discard(v)
            return True
        heap = []
        for e in ecount:
            L = v_dist(V[e[0]], V[e[1]])
            if L < target:
                heap.append((L, e[0], e[1]))
        heapq.heapify(heap)
        removed = 0
        n = 0
        while heap:
            L, a, b = heapq.heappop(heap)
            n += 1
            if job is not None and n % 2000 == 0:
                job.tick(removed)
            if a not in vt or b not in vt:
                continue
            if v_dist(V[a], V[b]) != L:
                continue
            w = None
            if try_collapse(a, b):
                w = b
            elif try_collapse(b, a):
                w = a
            if w is not None:
                removed += 1
                for x in nbrs(w):
                    L2 = v_dist(V[w], V[x])
                    if L2 < target:
                        heapq.heappush(heap, (L2, min(w, x), max(w, x)))
        self.naked = set()
        ec = {}
        for i, t in enumerate(T):
            if self.alive[i]:
                for k in range(3):
                    e = (min(t[k], t[(k + 1) % 3]), max(t[k], t[(k + 1) % 3]))
                    ec[e] = ec.get(e, 0) + 1
        self.naked = set(e for e, c in ec.items() if c == 1)
        self.boundary = set()
        for a, b in self.naked:
            self.boundary.add(a)
            self.boundary.add(b)
        self.n_removed = removed
        return removed

    def locked_keys(self):
        """Edges lying on a cut / snap plane (facet_key pairs) - flat facets are not merged across them."""
        out = set()
        for i, t in enumerate(self.T):
            if not self.alive[i]:
                continue
            for k in range(3):
                a, b = t[k], t[(k + 1) % 3]
                pa, pb = self.on.get(a), self.on.get(b)
                if pa and pb and any(x in pb for x in pa):
                    ka, kb = facet_key(self.V[a]), facet_key(self.V[b])
                    out.add((min(ka, kb), max(ka, kb)))
        return out


def estimate_facets(area_mm2, facet_mm):
    """Rough number of shell facets (triangles) for a curved area at the given facet size."""
    return int(2.0 * area_mm2 / max(facet_mm * facet_mm, 1.0))


def facet_key(p):
    return (round(p[0], 6), round(p[1], 6), round(p[2], 6))


def merge_flat_facets(facets, tol=2e-7, max_tris=400, locked=None):
    """Join neighbouring facets of the same curved plate that lie in one plane (flat parts of a 'curved'
    surface, strips of cylinders / cones) into one planar polygon. Every boundary vertex is kept, so the
    shell stays conforming with its neighbours, webs and profiles; 'locked' edges (pairs of facet_key, e.g.
    the lines where webs / decks land) are never merged across. Regions that would get a hole or a pinched
    outline stay as triangles. tol is tiny on purpose: ALIEF FEAPRO / OpenCASCADE refuse a plate that is
    more than ~1e-6 mm out of plane. Returns the new facet list (pts, owner)."""
    key = facet_key
    locked = locked or set()
    keys = [[key(p) for p in f["pts"]] for f in facets]
    edge = {}
    for i, ks in enumerate(keys):
        m = len(ks)
        for j in range(m):
            e = (ks[j], ks[(j + 1) % m])
            edge.setdefault((min(e), max(e)), []).append(i)
    normals = [v_unit(newell_normal(f["pts"]), [0, 0, 1]) for f in facets]
    done = [False] * len(facets)
    out = []
    for i0 in range(len(facets)):
        if done[i0]:
            continue
        done[i0] = True
        o, n = facets[i0]["pts"][0], normals[i0]
        region = [i0]
        stack = [i0]
        while stack and len(region) < max_tris:
            i = stack.pop()
            ks = keys[i]
            for j in range(len(ks)):
                e = (ks[j], ks[(j + 1) % len(ks)])
                ek = (min(e), max(e))
                if ek in locked:
                    continue
                for nb in edge.get(ek, ()):
                    if done[nb] or facets[nb]["owner"] != facets[i0]["owner"] or v_dot(normals[nb], n) < 0.9999:
                        continue
                    if all(abs(v_dot(v_sub(q, o), n)) <= tol for q in facets[nb]["pts"]):
                        done[nb] = True
                        region.append(nb)
                        stack.append(nb)
                        if len(region) >= max_tris:
                            break
        if len(region) == 1:
            out.append(dict(pts=facets[i0]["pts"], owner=facets[i0]["owner"]))
            continue
        directed = {}
        pos = {}
        for i in region:
            ks = keys[i]
            for j in range(len(ks)):
                directed[(ks[j], ks[(j + 1) % len(ks)])] = True
                pos[ks[j]] = facets[i]["pts"][j]
        nxt = {}
        ok = True
        for (a, b) in directed:
            if (b, a) in directed:
                continue
            if a in nxt:
                ok = False
                break
            nxt[a] = b
        loop = []
        if ok and nxt:
            start = next(iter(nxt))
            cur = start
            while True:
                loop.append(cur)
                cur = nxt.get(cur)
                if cur is None or len(loop) > len(nxt):
                    ok = False
                    break
                if cur == start:
                    break
            ok = ok and len(loop) == len(nxt)
        if not ok or len(loop) < 3:
            for i in region:
                out.append(dict(pts=facets[i]["pts"], owner=facets[i]["owner"]))
            continue
        P = [list(pos[k]) for k in loop]
        out.append(dict(pts=P, owner=facets[i0]["owner"]))
    return out


# =========================================================================== cubic light surfaces (v1.2)
def distribute(ts, w, max_n=600, min_n=1):
    """New parameters along ts so that every new interval holds about one unit of weight w[i] (per old
    interval). Ends included."""
    n = len(ts) - 1
    tot = sum(w)
    m = max(min_n, min(int(math.ceil(tot - 1e-9)), max_n), 1)
    cum = [0.0]
    for x in w:
        cum.append(cum[-1] + x)
    out = [ts[0]]
    j = 0
    for k in range(1, m):
        target = tot * k / m
        while j < n - 1 and cum[j + 1] < target:
            j += 1
        span = cum[j + 1] - cum[j]
        f = (target - cum[j]) / span if span > 1e-15 else 0.0
        out.append(ts[j] + f * (ts[j + 1] - ts[j]))
    out.append(ts[-1])
    return out


def cubic_knots(ts):
    """Full clamped cubic knot vector (end knots 4x) for interpolation at ts (de Boor averaging)."""
    n = len(ts) - 1
    inner = [(ts[j] + ts[j + 1] + ts[j + 2]) / 3.0 for j in range(1, n - 2)]
    return [ts[0]] * 4 + inner + [ts[-1]] * 4


def bspline_span(k, p, ncp, t):
    if t >= k[ncp]:
        return ncp - 1
    if t <= k[p]:
        return p
    lo, hi = p, ncp
    mid = (lo + hi) // 2
    while t < k[mid] or t >= k[mid + 1]:
        if t < k[mid]:
            hi = mid
        else:
            lo = mid
        mid = (lo + hi) // 2
    return mid


def bspline_basis(k, p, span, t):
    """Non-zero basis functions N[0..p] (control points span-p .. span) at t."""
    N = [0.0] * (p + 1)
    N[0] = 1.0
    left = [0.0] * (p + 1)
    right = [0.0] * (p + 1)
    for j in range(1, p + 1):
        left[j] = t - k[span + 1 - j]
        right[j] = k[span + j] - t
        saved = 0.0
        for r in range(j):
            den = right[r + 1] + left[j - r]
            tmp = N[r] / den if den != 0.0 else 0.0
            N[r] = saved + right[r + 1] * tmp
            saved = left[j - r] * tmp
        N[j] = saved
    return N


class _BandLU(object):
    """LU (no pivoting - B-spline collocation matrices are totally positive) of the cubic interpolation matrix."""

    def __init__(self, ts, k):
        m = len(ts)
        self.m = m
        A = [dict() for _ in range(m)]
        for i, t in enumerate(ts):
            sp = bspline_span(k, 3, m, t)
            N = bspline_basis(k, 3, sp, t)
            for a in range(4):
                if N[a] != 0.0:
                    A[i][sp - 3 + a] = N[a]
        self.L = [dict() for _ in range(m)]
        for c in range(m):
            piv = A[c].get(c, 0.0)
            if abs(piv) < 1e-14:
                raise ValueError("singular interpolation matrix")
            for r in range(c + 1, min(m, c + 5)):
                v = A[r].get(c)
                if v:
                    f = v / piv
                    self.L[r][c] = f
                    for cc, vv in A[c].items():
                        if cc >= c:
                            A[r][cc] = A[r].get(cc, 0.0) - f * vv
                    A[r].pop(c, None)
        self.U = [sorted((cc, vv) for cc, vv in A[r].items() if cc >= r) for r in range(m)]

    def solve(self, b):
        """b: list of 3D points -> control points."""
        m = self.m
        y = [list(p) for p in b]
        for r in range(m):
            for c, f in self.L[r].items():
                yc = y[c]
                yr = y[r]
                yr[0] -= f * yc[0]
                yr[1] -= f * yc[1]
                yr[2] -= f * yc[2]
        x = [None] * m
        for r in range(m - 1, -1, -1):
            row = self.U[r]
            d = row[0][1]
            s = list(y[r])
            for c, v in row[1:]:
                xc = x[c]
                s[0] -= v * xc[0]
                s[1] -= v * xc[1]
                s[2] -= v * xc[2]
            x[r] = [s[0] / d, s[1] / d, s[2] / d]
        return x


def interp_surface(us, vs, P):
    """Bicubic B-spline through the grid P[i][j] = S(us[i], vs[j]) (>= 4 sites per direction).
    Returns (control points C[i][j], full knots ku, kv)."""
    ku, kv = cubic_knots(us), cubic_knots(vs)
    su, sv = _BandLU(us, ku), _BandLU(vs, kv)
    nu, nv = len(us), len(vs)
    cols = [su.solve([P[i][j] for i in range(nu)]) for j in range(nv)]
    Q = [[cols[j][i] for j in range(nv)] for i in range(nu)]
    Cp = [sv.solve(Q[i]) for i in range(nu)]
    return Cp, ku, kv


def eval_grid(Cp, ku, kv, ueval, veval):
    """Points of the bicubic at every (u, v) of ueval x veval."""
    nu, nv = len(Cp), len(Cp[0])
    bv = []
    for v in veval:
        sp = bspline_span(kv, 3, nv, v)
        bv.append((sp - 3, bspline_basis(kv, 3, sp, v)))
    out = []
    for u in ueval:
        sp = bspline_span(ku, 3, nu, u)
        N = bspline_basis(ku, 3, sp, u)
        r0, r1, r2, r3 = Cp[sp - 3], Cp[sp - 2], Cp[sp - 1], Cp[sp]
        n0, n1, n2, n3 = N
        R = [[n0 * r0[b][k] + n1 * r1[b][k] + n2 * r2[b][k] + n3 * r3[b][k] for k in range(3)] for b in range(nv)]
        line = []
        for b0, M in bv:
            m0, m1, m2, m3 = M
            q0, q1, q2, q3 = R[b0], R[b0 + 1], R[b0 + 2], R[b0 + 3]
            line.append([m0 * q0[k] + m1 * q1[k] + m2 * q2[k] + m3 * q3[k] for k in range(3)])
        out.append(line)
    return out


def _quantile(xs, q):
    xs = sorted(x for x in xs if x > 1e-9)
    if not xs:
        return 0.0
    return xs[min(len(xs) - 1, int(q * len(xs)))]


def fit_cubic_light(f, box, span_mm, fit_tol, max_sites=250, iters=4, max_samples=10000):
    """Light bicubic copy of a (dense) surface in its OWN parameter space, so the face's trims still fit.

    f(u, v) -> [x, y, z] mm of the original surface, box = (u0, u1, v0, v1) used part of the domain.
    Spans are about span_mm long on the SHORT side of the surface (the mesher refines locally to the facet
    size afterwards, so long sides do not spread fine spans over the whole surface), closer where the shape
    needs it; refined until the copy is within fit_tol of the original at all mid points.
    Returns dict(ku, kv (Rhino knots, no end duplicates), cp (mm), us, vs, err, spans)."""
    u0, u1, v0, v1 = box
    cache = {}

    def F(u, v):
        key = (u, v)
        p = cache.get(key)
        if p is None:
            p = cache[key] = list(f(u, v))
        return p

    def grid(nu, nv):
        us = [u0 + (u1 - u0) * i / (nu - 1.0) for i in range(nu)]
        vs = [v0 + (v1 - v0) * j / (nv - 1.0) for j in range(nv)]
        return us, vs, [[F(u, v) for v in vs] for u in us]
    us, vs, P = grid(9, 9)
    lu, lv, _, _ = grid_lengths(P)
    h = max(span_mm / 3.0, 1.0)
    nu = int(min(max(sum(lu) / h, 6.0), 300.0)) + 1
    nv = int(min(max(sum(lv) / h, 6.0), 300.0)) + 1
    if nu * nv > max_samples:
        k = math.sqrt(float(max_samples) / (nu * nv))
        nu, nv = max(7, int(nu * k)), max(7, int(nv * k))
    us, vs, P = grid(nu, nv)
    # interval lengths: a low quantile over the other direction (short side), and the curvature
    Lu_q = [_quantile([v_dist(P[i][j], P[i + 1][j]) for j in range(nv)], 0.2) for i in range(nu - 1)]
    Lv_q = [_quantile([v_dist(P[i][j], P[i][j + 1]) for i in range(nu)], 0.2) for j in range(nv - 1)]
    lu, lv, bu, bv = grid_lengths(P)

    def weights(Lq, Lmax, bend):
        w = []
        for i in range(len(Lq)):
            x = Lq[i] / span_mm
            if bend[i] > 1e-12:
                hk = (384.0 * fit_tol / (5.0 * bend[i] ** 3)) ** 0.25
                x = max(x, Lmax[i] / max(hk, span_mm / 8.0))
            w.append(x)
        return w
    su = distribute(us, weights(Lu_q, lu, bu), max_sites, 3)
    sv = distribute(vs, weights(Lv_q, lv, bv), max_sites, 3)
    err = 0.0
    for it in range(iters + 1):
        P = [[F(u, v) for v in sv] for u in su]
        Cp, ku, kv = interp_surface(su, sv, P)
        um = [0.5 * (su[i] + su[i + 1]) for i in range(len(su) - 1)]
        vm = [0.5 * (sv[j] + sv[j + 1]) for j in range(len(sv) - 1)]
        eu = [0.0] * len(um)
        ev = [0.0] * len(vm)
        A = eval_grid(Cp, ku, kv, um, sv)
        for i, u in enumerate(um):
            for j, v in enumerate(sv):
                eu[i] = max(eu[i], v_dist(A[i][j], F(u, v)))
        B = eval_grid(Cp, ku, kv, su, vm)
        for i, u in enumerate(su):
            for j, v in enumerate(vm):
                ev[j] = max(ev[j], v_dist(B[i][j], F(u, v)))
        # an error in the middle of a cell that shows on neither of its edge mid points is a twist: refine both
        Cm = eval_grid(Cp, ku, kv, um, vm)
        twist_u, twist_v = set(), set()
        ec = 0.0
        for i, u in enumerate(um):
            for j, v in enumerate(vm):
                d = v_dist(Cm[i][j], F(u, v))
                ec = max(ec, d)
                if d > fit_tol and eu[i] <= fit_tol and ev[j] <= fit_tol:
                    twist_u.add(i)
                    twist_v.add(j)
        for i in twist_u:
            eu[i] = 2.0 * fit_tol
        for j in twist_v:
            ev[j] = 2.0 * fit_tol
        err = max(eu + ev + [ec])
        bad_u = [i for i, e in enumerate(eu) if e > fit_tol]
        bad_v = [j for j, e in enumerate(ev) if e > fit_tol]
        if (not bad_u and not bad_v) or it == iters:
            break
        if len(su) + len(bad_u) > max_sites or len(sv) + len(bad_v) > max_sites:
            break
        su = sorted(set(su + [um[i] for i in bad_u]))
        sv = sorted(set(sv + [vm[j] for j in bad_v]))
    return dict(ku=ku[1:-1], kv=kv[1:-1], cp=Cp, us=su, vs=sv, err=err, spans=(len(su) - 3) * (len(sv) - 3),
                evals=len(cache))


# =========================================================================== export limits (v1.3)
def parse_limits(text):
    """'8000' / '-7200, 8000' / '' -> (lo, hi) mm or None. One number = upper limit."""
    if text is None:
        return None
    if isinstance(text, (list, tuple)):
        vals = [float(x) for x in text if x is not None and str(x).strip() != ""]
    else:
        vals = []
        for tok in str(text).replace(";", ",").replace("..", ",").replace(" to ", ",").split(","):
            tok = tok.strip()
            if tok:
                try:
                    vals.append(float(tok))
                except ValueError:
                    return None
    if not vals:
        return None
    if len(vals) == 1:
        return (-1e30, vals[0])
    return (min(vals[0], vals[1]), max(vals[0], vals[1]))


def clip_polygon_halfspace(P, o, n, tol=1e-6):
    """Part of the polygon with (p - o).n <= 0 (Sutherland-Hodgman). Returns the new point list ([] if nothing
    is left) and whether it was cut."""
    d = [v_dot(v_sub(p, o), n) for p in P]
    if all(x <= tol for x in d):
        return [list(p) for p in P], False
    if all(x >= -tol for x in d):
        return [], True
    out = []
    m = len(P)
    for i in range(m):
        a, b = P[i], P[(i + 1) % m]
        da, db = d[i], d[(i + 1) % m]
        if da <= tol:
            out.append(list(a))
        if (da < -tol and db > tol) or (da > tol and db < -tol):
            f = da / (da - db)
            out.append(v_add(a, v_mul(v_sub(b, a), f)))
    res = []
    for p in out:
        if not res or v_dist(res[-1], p) > 1e-6:
            res.append(p)
    if len(res) > 1 and v_dist(res[0], res[-1]) <= 1e-6:
        res.pop()
    return (res if len(res) >= 3 else []), True


def clip_polygon_slab(P, axis, lo, hi):
    """Polygon cut to lo <= coordinate[axis] <= hi. Returns (points, was_cut)."""
    n = [0.0, 0.0, 0.0]
    n[axis] = 1.0
    cut = False
    if hi < 1e29:
        o = [0.0, 0.0, 0.0]
        o[axis] = hi
        P, c = clip_polygon_halfspace(P, o, n)
        cut = cut or c
    if P and lo > -1e29:
        o = [0.0, 0.0, 0.0]
        o[axis] = lo
        P, c = clip_polygon_halfspace(P, o, v_mul(n, -1.0))
        cut = cut or c
    return P, cut


def clip_segment_slab(a, b, axis, lo, hi):
    """Part of segment a-b inside the slab, or None."""
    ta, tb = 0.0, 1.0
    da = b[axis] - a[axis]
    for lim, sign in ((hi, 1.0), (lo, -1.0)):
        if abs(lim) > 1e29:
            continue
        fa = sign * (a[axis] - lim)
        fb = sign * (b[axis] - lim)
        if fa > 0 and fb > 0:
            return None
        if fa > 0 or fb > 0:
            t = fa / (fa - fb)
            if fa > 0:
                ta = max(ta, t)
            else:
                tb = min(tb, t)
    if tb - ta <= 1e-9:
        return None
    return v_lerp(a, b, ta), v_lerp(a, b, tb)


def shell_clip_slab(sm, axis, lo, hi, tol=0.01):
    """Cut the ShellMesh at the slab faces and drop everything outside. Returns the number of removed triangles."""
    n = [0.0, 0.0, 0.0]
    n[axis] = 1.0
    blo, bhi = sm.bbox()
    big_lo = [x - 1.0 for x in blo]
    big_hi = [x + 1.0 for x in bhi]
    pid = -1000
    for lim in (lo, hi):
        if abs(lim) > 1e29 or lim <= blo[axis] or lim >= bhi[axis]:
            continue
        o = [0.0, 0.0, 0.0]
        o[axis] = lim
        pid -= 1
        sm.cut_plane(pid, o, n, big_lo, big_hi, tol)
    removed = 0
    for i, t in enumerate(sm.T):
        if not sm.alive[i]:
            continue
        c = (sm.V[t[0]][axis] + sm.V[t[1]][axis] + sm.V[t[2]][axis]) / 3.0
        if c < lo or c > hi:
            sm.alive[i] = False
            for vi in t:
                sm.vt.get(vi, set()).discard(i)
            removed += 1
    # the cut is a new free edge; forget the helper planes
    for vi in list(sm.on):
        keep = dict((k, v) for k, v in sm.on[vi].items() if k > -1000)
        if keep:
            sm.on[vi] = keep
        else:
            del sm.on[vi]
    ec = {}
    for i, t in enumerate(sm.T):
        if sm.alive[i]:
            for k in range(3):
                e = (min(t[k], t[(k + 1) % 3]), max(t[k], t[(k + 1) % 3]))
                ec[e] = ec.get(e, 0) + 1
    sm.naked = set(e for e, c in ec.items() if c == 1)
    sm.boundary = set()
    for a, b in sm.naked:
        sm.boundary.add(a)
        sm.boundary.add(b)
    return removed


def clip_polyline_slabs(pts, lims):
    """Runs of the polyline inside all limits [(axis, (lo, hi))] - each a list of points, cut exactly at the limits."""
    runs, cur = [], []
    for i in range(len(pts) - 1):
        seg = (pts[i], pts[i + 1])
        for axis, (lo, hi) in lims:
            if seg is not None:
                seg = clip_segment_slab(seg[0], seg[1], axis, lo, hi)
        if seg is None:
            if len(cur) > 1:
                runs.append(cur)
            cur = []
            continue
        if cur and v_dist(cur[-1], seg[0]) > 1e-6:
            if len(cur) > 1:
                runs.append(cur)
            cur = []
        if not cur:
            cur = [list(seg[0])]
        cur.append(list(seg[1]))
    if len(cur) > 1:
        runs.append(cur)
    return runs
