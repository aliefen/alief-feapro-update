# ALIEF FEA MODELER for Rhino 8 — v1.4.1

Plugin Rhinoceros 8 untuk memodelkan pelat, web, girder, profil, bracket, face plate dan lubang beserta materialnya,
lalu mengekspornya ke **ALIEF FEAPRO (.alfea)**. Di FEAPRO tinggal diberi mesh, support dan load.

PT. Alief Energy Utama — Naval Architect & Marine Engineer Consultant, Batam.

## Instalasi singkat
1. Salin folder `ALIEF_FEA_Rhino` ke `C:\RHINO\ALIEF_FEA_Rhino` (atau lokasi tetap lain).
2. Rhino 8 → perintah `RunPythonScript` → pilih `INSTALL_ALIEF_FEA.py` (sekali saja).
3. Installer langsung memasang tab **ALIEF FEA** (deretan 21 ikon) di bagian atas jendela Rhino, seperti tab Standard / Drafting — tanpa setting. Bila Rhino menampilkannya mengambang, seret tabnya sekali ke samping Drafting; Rhino mengingatnya. `AF_RhinoToolbar` = tampilkan lagi, `AF_Toolbar` = icon bar mengambang cadangan.
4. Update versi: tutup Rhino, timpa folder, buka Rhino, jalankan lagi `INSTALL_ALIEF_FEA.py` (ikon ikut diperbarui, tab tetap di tempatnya).

Panduan lengkap bergambar: **PANDUAN_PENGGUNAAN_ALIEF_FEA_MODELER.pdf**.

## Perintah
| Perintah | Fungsi |
|---|---|
| AF_Panel / AF_Library | Panel: properti aktif, pustaka plate property / section / material, ekspor |
| AF_Toolbar / AF_RhinoToolbar | Icon bar mengambang / toolbar Rhino 'ALIEF FEA' bergambar ikon |
| AF_Plate | Kurva tertutup → pelat (kurva di dalam = lubang) |
| AF_SurfaceToPlate | Surface / polysurface (juga kulit lengkung) → pelat |
| AF_Web | Web / girder / wrang dengan face plate atau profil tepi |
| AF_Profile | Kurva → profil (section, sisi web, flange, offset) |
| AF_3DView | 3D View ON/OFF: tebal pelat + penampang profil, selalu mengikuti model, tanpa menambah objek (AF_Preview / AF_PreviewOff / AF_3DProfiles = alias) |
| AF_Legend | Index properti mengambang di kiri atas (warna, jumlah, luas / panjang, berat) |
| AF_Sync, AF_SyncSetup | Sinkronisasi tim lewat folder bersama: zona per orang, publikasi saat Save, zona lain diperbarui otomatis |
| AF_Startup | Menyalakan 3D View, index dan sinkronisasi saat Rhino dibuka (ditambahkan installer) |
| AF_Stiffeners | Stiffener otomatis (spacing / jumlah / posisi), putus di lubang |
| AF_Bracket | Bracket: klik dua member (profil / pelat) dan langsung jadi, atau sudut + 2 titik; kaki otomatis 2 x tinggi profil |
| AF_Opening | Lubang: slot/manhole, persegi + radius, lingkaran, kurva bebas |
| AF_FacePlate | Face plate pada tepi bebas |
| AF_Assign | Jendela Properties & Assign gaya STAAD Pro: satu properti ke banyak kurva / kurva tertutup / surface sekaligus (Selected / Cursor / Layer / View) |
| AF_FlipSide, AF_FlipFlange, AF_Info | Ubah data FEA |
| AF_Check | Cek model (properti, planaritas, celah antar pelat, pelat mikro, surface rapat, perkiraan jumlah facet) |
| AF_Color | Pewarnaan: property, material, tebal, layer |
| AF_MTO | Daftar material & berat (CSV) |
| AF_Update | Periksa versi baru di internet, pasang, atau roll back |
| AF_Export, AF_ExportNow, AF_Import | Ekspor / impor ALIEF FEAPRO (model besar: per blok, progress, Esc) |
| AF_Reload | Muat ulang modul setelah update |

## Isi folder
- `alief_fea/` — kode plugin (core, rhinoio, ui, commands), ikon dan gambar dialog
- `commands/` — satu skrip per perintah (dipanggil oleh alias AF_…)
- `examples/` — `Winch_foundation_example.3dm`, `Bilge_shell_example.3dm` (kulit lengkung), `Winch_foundation_example.alfea`
- `INSTALL_ALIEF_FEA.py`, `UNINSTALL_ALIEF_FEA.py`

## Ekspor model besar / kompleks (baru di 1.2)
Model dengan surface lambung NURBS yang sangat rapat dulu bisa diekspor > 24 jam tanpa hasil. Versi 1.2:
- **Curved plating: Fast** — setiap face lengkung dibuat salinan ringan (bicubic di ruang parameter face itu sendiri, trim tetap cocok), di-mesh seukuran facet, dicek terhadap surface asli (ditambah node di bagian yang melengkung, digabung di bagian yang terlalu rapat), lalu kulit dipotong **lokal** di web / deck yang menempel. Bagian datar / lurus digabung menjadi pelat planar besar (tidak melewati garis web). Waktu sebanding jumlah facet: 100 000 facet + 150 web dalam hitungan detik (di luar Rhino).
- **Export: All / Visible / Selected** — ekspor per blok.
- **Shape tolerance**, **Skip plates smaller than** (hatch / sisa gambar 2D tidak ikut), **Ask when more facets than** (peringatan + saran facet size sebelum file besar dibuat).
- Progress di status bar, **Esc** membatalkan, waktu tiap tahap di laporan; file lama tidak pernah tertulis setengah jadi.
- **AF_Check** sekarang juga memeriksa pelat mikro, surface rapat dan perkiraan jumlah facet; cek celah antar pelat memakai indeks grid (20 000 pelat < 1 detik).
- Metode lama tetap ada (**Classic**) sebagai pembanding.

## Catatan
- Aturan profil, material dan offset identik dengan ALIEF FEAPRO (FB, L, T, H, C, HP, PIPE, RB, GEN).
- Pelat lengkung diekspor sebagai facet planar yang tersambung (web dan profil berbagi node dengan kulit).
- Ekspor ulang ke file yang sama dengan opsi *Keep supports / loads* mempertahankan support, load dan load case dari FEAPRO.
- Lubang bentuk bebas memakai opening `poly` (FEAPRO versi terbaru).

## Update otomatis (baru di 1.4)
Plugin memeriksa `https://raw.githubusercontent.com/aliefen/alief-feapro-update/main/rhino/latest.json` saat Rhino dibuka. Bila ada versi baru: tanya -> unduh -> cek SHA-256 -> cadangkan versi lama -> salin -> daftar perintah baru -> muat ulang. Manual: ikon **Update** / `AF_Update` (juga Roll back). Versi 1.4 masih dipasang sekali dengan `INSTALL_ALIEF_FEA.py`.

Merilis versi baru: unggah `latest.json` dan `ALIEF_FEA_Rhino_vX.Y.Z.zip` ke folder `rhino/` di repo `aliefen/alief-feapro-update` (zip dulu, baru `latest.json`).

## Riwayat
- 1.4.1 — Toolbar ALIEF FEA tidak muncul setelah memasang 1.4.0 (ikon Update menambah tombol; Rhino menyembunyikan toolbar yang filenya dibuka ulang): toolbar sekarang ditampilkan lagi setiap kali tombolnya berubah.
- 1.4.0 — Update otomatis lewat GitHub (cek saat Rhino dibuka, AF_Update, roll back, cadangan 3 versi).
- 1.3.0 — File .alfea yang membuat ALIEF FEAPRO not responding: jumlah facet kulit sekarang dibatasi (**Max. facets**, standar 5000) dan facet diperbesar otomatis sampai di bawah batas; **Limit X / Y / Z** mengekspor hanya satu blok (pelat, kulit dan profil dipotong tepat di batas, surface sepanjang kapal tidak ikut seluruhnya); toleransi kontak kulit disesuaikan dengan toleransi bentuk.
- 1.2.0 — Ekspor cepat model besar / kompleks: salinan ringan surface lengkung yang rapat, cek dan penyempurnaan facet terhadap surface asli, penyederhanaan bagian yang terlalu rapat, pemotongan kulit lokal (bukan Brep.Split dengan bidang tak hingga), penggabungan facet datar, indeks grid untuk pelat dan profil; pilihan Export (All / Visible / Selected), Shape tolerance, Skip plates smaller than, peringatan jumlah facet; progress + Esc + waktu tiap tahap; AF_Check memeriksa pelat mikro / surface rapat / perkiraan facet dan tidak lagi kuadratik; file .alfea besar ditulis ringkas dan aman (tidak setengah jadi).
- 1.1.2 — Export: pilih folder (tombol ...), nama file saja disimpan di folder .3dm / Documents, PermissionError ditangani; tombol Select ... / Assign di dialog AF_Plate (kurva tertutup dan surface), AF_SurfaceToPlate, AF_Profile, AF_Stiffeners (web 90 derajat, arah tegak lurus / sejajar tepi pelat), AF_FacePlate (dari kurva tepi bebas atau surface), AF_Opening (banyak pelat, otomatis di tengah pelat); tombol OK/Cancel tidak lagi memanjang.
- 1.1.1 — perbaikan: semua perintah gagal dengan `ExecuteException: '__module__'` (kelas tampilan 3D View / index dibuat dengan cara yang tidak diterima Python 3 Rhino 8; sekarang kelas biasa yang dibuat sekali per sesi Rhino, dan kegagalannya tidak lagi menghentikan perintah).
- 1.1.0 — sinkronisasi tim (folder bersama, zona per orang, otomatis saat Save); jendela Assign gaya STAAD Pro; bracket dengan klik dua member; index properti mengambang; 3D View sekali klik yang selalu terbarui dan digambar tanpa objek (ringan); pelat tanpa grid isocurve; katalog profil sendiri (+/- Catalogue, CSV); tab Team di panel; AF_Startup.
- 1.0.3 — tab 'ALIEF FEA' dipasang otomatis oleh installer, ter-dock di tepi atas Rhino seperti tab Drafting (ikon saja, 16/24/32 px); fallback `-ShowToolbar`; instal ulang tidak membuat tab ganda; pesan installer berbahasa Indonesia.
- 1.0.2 — tombol OK/Cancel & teks bawah dialog/panel tidak terpotong lagi (ukuran dialog eksplisit, teks dibungkus manual); profil 3D otomatis dibentuk dari section FEAPRO saat AF_Profile / AF_Stiffeners / AF_Web / AF_Assign, ikut diperbarui saat Flip / Info / edit pustaka, bisa diklik langsung; perintah AF_3DProfiles; offset 'none' = tanpa eksentrisitas (sama dengan solver FEAPRO).
- 1.0.1 — perbaikan error panel (`BorderType.None` di Python 3 Rhino); toolbar Rhino 'ALIEF FEA' (.rui) dengan ikon 16/24/32 px dibuat & dibuka otomatis oleh installer; perintah AF_Toolbar (icon bar mengambang) dan AF_RhinoToolbar.
- 1.0.0 — rilis pertama.
