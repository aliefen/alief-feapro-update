#! python3
# ALIEF FEA MODELER for Rhino 8 - AF_Reload: reload the modules after an update
# PT. Alief Energy Utama
import os
import sys


def _root():
    try:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except NameError:
        pass
    p = os.path.join(os.environ.get("APPDATA", ""), "AliefEnergy", "ALIEF_FEA_Rhino", "install_path.txt")
    if os.path.exists(p):
        with open(p) as f:
            return f.read().strip()
    return r"C:\RHINO\ALIEF_FEA_Rhino"


_r = _root()
if _r not in sys.path:
    sys.path.insert(0, _r)
for _m in [m for m in list(sys.modules) if m == "alief_fea" or m.startswith("alief_fea.")]:
    del sys.modules[_m]
import scriptcontext as sc  # noqa: E402
for _k in ("ALIEF_FEA_PANEL", "ALIEF_FEA_TOOLBAR"):
    _p = sc.sticky.get(_k)
    if _p is not None:
        try:
            _p.form.Close()
        except Exception:
            pass
from alief_fea import core  # noqa: E402
import Rhino  # noqa: E402
Rhino.RhinoApp.WriteLine("ALIEF FEA MODELER %s reloaded from %s - open AF_Panel / AF_Toolbar again" % (core.VERSION, _r))
