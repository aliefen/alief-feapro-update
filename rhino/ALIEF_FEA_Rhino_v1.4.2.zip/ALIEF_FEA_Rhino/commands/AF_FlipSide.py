#! python3
# ALIEF FEA MODELER for Rhino 8 - AF_FlipSide: Flip the web side of profiles
# PT. Alief Energy Utama
import os
import sys


def _root():
    try:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except NameError:
        pass
    p = os.path.join(os.environ.get("APPDATA", ""), "AliefEnergy", "ALIEF_FEA_Rhino", "install_path.txt")
    if os.path.exists(p):
        with open(p) as f:
            return f.read().strip()
    return r"C:\RHINO\ALIEF_FEA_Rhino"


_r = _root()
if _r not in sys.path:
    sys.path.insert(0, _r)
from alief_fea import commands  # noqa: E402

commands.flip_side()
