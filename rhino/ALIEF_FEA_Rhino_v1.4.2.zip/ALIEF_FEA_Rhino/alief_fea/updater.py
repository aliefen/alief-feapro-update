# ALIEF FEA MODELER for Rhino 8 - automatic update from GitHub (v1.4)
# PT. Alief Energy Utama
"""The plugin looks at  <repo>/rhino/latest.json  when Rhino starts. If a newer version is there it asks,
downloads the zip, checks size and SHA-256, keeps a backup of the installed version, copies the new files
over the plugin folder, registers new commands and reloads itself - no copy / paste, no RunPythonScript.

Layout in the repository (branch main, folder rhino/):
    latest.json                      {"product": "ALIEF_FEA_RHINO", "version": "1.4.0", "file": "...zip",
                                      "sha256": "...", "size": 123, "date": "...", "notes": "..."}
    ALIEF_FEA_Rhino_v1.4.0.zip       the same zip that is given to users (top folder ALIEF_FEA_Rhino/)
"""
import hashlib
import json
import os
import re
import shutil
import sys
import tempfile
import time
import zipfile

PRODUCT = "ALIEF_FEA_RHINO"
BASE_URL = "https://raw.githubusercontent.com/aliefen/alief-feapro-update/main/rhino/"
LATEST = "latest.json"
KEEP_BACKUPS = 3
STICKY = "ALIEF_FEA_UPDATE"
MAX_ZIP = 200 * 1024 * 1024


class UpdateError(Exception):
    pass


# --------------------------------------------------------------------------- small helpers
def cfg_dir():
    d = os.path.join(os.environ.get("APPDATA", tempfile.gettempdir()), "AliefEnergy", "ALIEF_FEA_Rhino")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return d


def load_prefs():
    p = dict(auto=True, skip="", last_check=0.0)
    try:
        with open(os.path.join(cfg_dir(), "update.json")) as f:
            p.update(json.load(f))
    except Exception:
        pass
    return p


def save_prefs(p):
    try:
        with open(os.path.join(cfg_dir(), "update.json"), "w") as f:
            json.dump(p, f)
    except Exception:
        pass


def vtuple(v):
    out = []
    for tok in re.split(r"[.\-_ ]", str(v).strip().lstrip("vV")):
        m = re.match(r"\d+", tok)
        out.append(int(m.group(0)) if m else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out)


def installed_version(root):
    try:
        with open(os.path.join(root, "alief_fea", "core.py"), encoding="utf-8") as f:
            m = re.search(r'^VERSION\s*=\s*"([^"]+)"', f.read(20000), re.M)
        return m.group(1) if m else "0"
    except Exception:
        return "0"


def install_root():
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return here


def http_get(url, timeout=10.0, limit=MAX_ZIP):
    """Bytes of url (https or, for tests, file). urllib first, .NET WebClient when Python has no certificates."""
    if not (url.startswith("https://") or url.startswith("file:")):
        raise UpdateError("only https downloads are allowed")
    err = None
    try:
        import urllib.request
        req = urllib.request.Request(url, headers={"User-Agent": "ALIEF-FEA-Rhino-Updater", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read(limit + 1)
        if len(data) > limit:
            raise UpdateError("download is larger than expected")
        return data
    except UpdateError:
        raise
    except Exception as ex:
        err = ex
    try:                                            # inside Rhino: Windows certificate store
        import System
        wc = System.Net.WebClient()
        wc.Headers.Add("User-Agent", "ALIEF-FEA-Rhino-Updater")
        return bytes(wc.DownloadData(url))
    except Exception:
        raise UpdateError("cannot reach the update server (%s)" % err)


def fetch_latest(base=None, timeout=6.0):
    """The latest.json of the repository as a dict (checked)."""
    base = base or BASE_URL
    raw = http_get(base + LATEST + ("?t=%d" % int(time.time()) if base.startswith("https://") else ""), timeout, 1024 * 1024)
    try:
        info = json.loads(raw.decode("utf-8-sig"))
    except Exception:
        raise UpdateError("latest.json cannot be read")
    if info.get("product") != PRODUCT:
        raise UpdateError("latest.json is not for ALIEF FEA MODELER")
    name = str(info.get("file", ""))
    if not re.match(r"^[A-Za-z0-9_.\-]+\.zip$", name):
        raise UpdateError("latest.json names an invalid file")
    if not re.match(r"^[0-9a-fA-F]{64}$", str(info.get("sha256", ""))):
        raise UpdateError("latest.json has no SHA-256")
    info["_base"] = base
    return info


def is_newer(info, root=None):
    return vtuple(info.get("version", "0")) > vtuple(installed_version(root or install_root()))


# --------------------------------------------------------------------------- install
def _safe_extract(zf, dest):
    dest_abs = os.path.abspath(dest)
    for m in zf.infolist():
        name = m.filename.replace("\\", "/")
        if name.startswith("/") or re.match(r"^[A-Za-z]:", name) or ".." in name.split("/"):
            raise UpdateError("the update zip contains an unsafe path: %s" % m.filename)
        target = os.path.abspath(os.path.join(dest_abs, name))
        if not (target == dest_abs or target.startswith(dest_abs + os.sep)):
            raise UpdateError("the update zip contains an unsafe path: %s" % m.filename)
    zf.extractall(dest_abs)


def _find_plugin(folder):
    for base, dirs, files in os.walk(folder):
        if os.path.exists(os.path.join(base, "alief_fea", "core.py")) and os.path.isdir(os.path.join(base, "commands")):
            return base
    return None


def backup(root):
    """Zip of the installed plugin code in the settings folder. Returns the path."""
    bdir = os.path.join(cfg_dir(), "backup")
    os.makedirs(bdir, exist_ok=True)
    path = os.path.join(bdir, "ALIEF_FEA_Rhino_v%s_%s.zip" % (installed_version(root), time.strftime("%Y%m%d_%H%M%S")))
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for sub in ("alief_fea", "commands"):
            for base, dirs, files in os.walk(os.path.join(root, sub)):
                dirs[:] = [d for d in dirs if d != "__pycache__"]
                for fn in files:
                    if fn.endswith(".pyc"):
                        continue
                    full = os.path.join(base, fn)
                    z.write(full, os.path.join("ALIEF_FEA_Rhino", os.path.relpath(full, root)))
        for fn in ("INSTALL_ALIEF_FEA.py", "UNINSTALL_ALIEF_FEA.py", "README.md", "VERIFICATION.md"):
            if os.path.exists(os.path.join(root, fn)):
                z.write(os.path.join(root, fn), os.path.join("ALIEF_FEA_Rhino", fn))
    old = sorted(f for f in os.listdir(bdir) if f.startswith("ALIEF_FEA_Rhino_v") and f.endswith(".zip"))
    for f in old[:-KEEP_BACKUPS]:
        try:
            os.remove(os.path.join(bdir, f))
        except OSError:
            pass
    return path


def backups():
    bdir = os.path.join(cfg_dir(), "backup")
    if not os.path.isdir(bdir):
        return []
    return [os.path.join(bdir, f) for f in sorted(os.listdir(bdir)) if f.startswith("ALIEF_FEA_Rhino_v") and f.endswith(".zip")]


def _copy_over(src, root):
    n = 0
    for base, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        rel = os.path.relpath(base, src)
        tgt = root if rel == "." else os.path.join(root, rel)
        os.makedirs(tgt, exist_ok=True)
        for fn in files:
            if fn.endswith(".pyc"):
                continue
            shutil.copy2(os.path.join(base, fn), os.path.join(tgt, fn))
            n += 1
    for sub in ("alief_fea", "commands"):                 # compiled files of the old version
        shutil.rmtree(os.path.join(root, sub, "__pycache__"), ignore_errors=True)
    return n


def _apply_zip(zip_path, root, expect_version=None):
    tmp = tempfile.mkdtemp(prefix="alief_fea_upd_")
    try:
        try:
            with zipfile.ZipFile(zip_path) as zf:
                if zf.testzip() is not None:
                    raise UpdateError("the update zip is damaged")
                _safe_extract(zf, tmp)
        except zipfile.BadZipFile:
            raise UpdateError("the update file is not a zip")
        src = _find_plugin(tmp)
        if not src:
            raise UpdateError("the update zip does not contain the plugin (alief_fea / commands)")
        if expect_version and vtuple(installed_version(src)) != vtuple(expect_version):
            raise UpdateError("the update zip is version %s, latest.json says %s" % (installed_version(src), expect_version))
        probe = os.path.join(root, "alief_fea", ".write_test")
        try:
            with open(probe, "w") as f:
                f.write("x")
            os.remove(probe)
        except OSError:
            raise UpdateError("no write permission in the plugin folder %s" % root)
        return _copy_over(src, root)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def download(info, timeout=120.0):
    """Download the zip of info to a temp file; size and SHA-256 are checked. Returns the path."""
    data = http_get(info["_base"] + info["file"], timeout)
    if info.get("size") and int(info["size"]) != len(data):
        raise UpdateError("download incomplete (%d of %d bytes)" % (len(data), int(info["size"])))
    if hashlib.sha256(data).hexdigest().lower() != str(info["sha256"]).lower():
        raise UpdateError("the downloaded file does not match its SHA-256 - not installed")
    fd, path = tempfile.mkstemp(prefix="alief_fea_", suffix=".zip")
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    return path


def install(info, root=None, log=None):
    """Download + verify + back up + copy. Returns (old version, new version, backup path)."""
    root = root or install_root()
    log = log or (lambda m: None)
    old = installed_version(root)
    log("downloading %s ..." % info["file"])
    zpath = download(info)
    try:
        bpath = backup(root)
        log("backup of %s: %s" % (old, bpath))
        try:
            n = _apply_zip(zpath, root, info.get("version"))
        except UpdateError:
            raise
        except Exception as ex:                      # half copied: put the old version back
            try:
                _apply_zip(bpath, root)
            except Exception:
                pass
            raise UpdateError("update failed while copying (%s) - the previous version was restored" % ex)
        log("%d files updated" % n)
    finally:
        try:
            os.remove(zpath)
        except OSError:
            pass
    return old, installed_version(root), bpath


def rollback(root=None):
    """Put the newest backup back. Returns its version, or None when there is no backup."""
    root = root or install_root()
    bs = backups()
    if not bs:
        return None
    _apply_zip(bs[-1], root)
    return installed_version(root)


# --------------------------------------------------------------------------- Rhino side
def register(root):
    """Remember the folder and (re)create the AF_ command aliases - what the installer does."""
    import Rhino
    try:
        with open(os.path.join(cfg_dir(), "install_path.txt"), "w") as f:
            f.write(root)
    except Exception:
        pass
    with open(os.path.join(root, "alief_fea", "commands.json")) as f:
        cmds = json.load(f)
    aliases = Rhino.ApplicationSettings.CommandAliasList
    made = []
    for name, desc in cmds:
        script = os.path.join(root, "commands", name + ".py")
        if not os.path.exists(script):
            continue
        macro = '! _-RunPythonScript "%s"' % script
        if aliases.IsAlias(name):
            aliases.SetMacro(name, macro)
        else:
            aliases.Add(name, macro)
        made.append((name, desc))
    return made


def reload_plugin(root):
    """Drop the loaded modules and start the new files: aliases, toolbar, live display."""
    import scriptcontext as sc
    for key in ("ALIEF_FEA_PANEL", "ALIEF_FEA_TOOLBAR"):
        p = sc.sticky.get(key)
        if p is not None:
            try:
                p.form.Close()
            except Exception:
                pass
    if root not in sys.path:
        sys.path.insert(0, root)
    for mod in [m for m in list(sys.modules) if m == "alief_fea" or m.startswith("alief_fea.")]:
        del sys.modules[mod]
    from alief_fea import updater as fresh, ui, live, core
    fresh.register(root)
    msg = ""
    try:
        msg = ui.open_rhino_toolbar(root)[1]
    except Exception as ex:
        msg = "toolbar not reopened (%s) - run AF_RhinoToolbar" % ex
    try:
        sc.sticky[fresh.STICKY] = dict(checked=True)
        live.ensure()
    except Exception:
        pass
    return core.VERSION, msg


def _say(text):
    try:
        import Rhino
        Rhino.RhinoApp.WriteLine("ALIEF FEA update: %s" % text)
    except Exception:
        print(text)


def _ask(info, current):
    """6 = update now, 7 = later, 2 = skip this version."""
    text = ("ALIEF FEA MODELER %s is available (installed: %s).\n\n%s\n\nYes = update now (about %.1f MB, Rhino stays open)\n"
            "No = remind me next time\nCancel = skip this version"
            % (info.get("version"), current, info.get("notes", ""), float(info.get("size", 0)) / 1e6))
    try:
        import rhinoscriptsyntax as rs
        return rs.MessageBox(text, 3 | 32, "ALIEF FEA MODELER - update")
    except Exception:
        return 7


def run_update(info, root=None, quiet=False):
    """Install info and reload. Returns True when the new version runs."""
    import Rhino
    root = root or install_root()
    try:
        old, new, bpath = install(info, root, _say)
        ver, msg = reload_plugin(root)
    except UpdateError as ex:
        _say(str(ex))
        if not quiet:
            Rhino.UI.Dialogs.ShowMessage("Update not installed:\n%s\n\nThe installed version keeps working." % ex,
                                         "ALIEF FEA MODELER - update")
        return False
    _say("updated %s -> %s" % (old, ver))
    Rhino.UI.Dialogs.ShowMessage(
        "ALIEF FEA MODELER updated: %s -> %s\n\n%s\n\nThe new version is active now (open AF_Panel again if it was open).\n"
        "Previous version kept in:\n%s   (AF_Update > Roll back)" % (old, ver, info.get("notes", ""), bpath),
        "ALIEF FEA MODELER - update")
    return True


def check_now():
    """AF_Update: check by hand, with messages; offers a roll back when already up to date."""
    import Rhino
    root = install_root()
    cur = installed_version(root)
    try:
        info = fetch_latest()
    except UpdateError as ex:
        Rhino.UI.Dialogs.ShowMessage("Cannot check for updates:\n%s\n\nInstalled version: %s" % (ex, cur),
                                     "ALIEF FEA MODELER - update")
        return
    prefs = load_prefs()
    prefs["last_check"] = time.time()
    if is_newer(info, root):
        ans = _ask(info, cur)
        if ans == 6:
            prefs["skip"] = ""
            save_prefs(prefs)
            run_update(info, root)
            return
        prefs["skip"] = info.get("version", "") if ans == 2 else ""
        save_prefs(prefs)
        return
    save_prefs(prefs)
    bs = backups()
    text = "ALIEF FEA MODELER %s is up to date (latest on the server: %s)." % (cur, info.get("version"))
    if bs:
        try:
            import rhinoscriptsyntax as rs
            if rs.MessageBox(text + "\n\nRoll back to the previous version (%s)?" % os.path.basename(bs[-1]),
                             4 | 256 | 32, "ALIEF FEA MODELER - update") == 6:
                ver = rollback(root)
                reload_plugin(root)
                Rhino.UI.Dialogs.ShowMessage("Rolled back to %s." % ver, "ALIEF FEA MODELER - update")
            return
        except Exception:
            pass
    Rhino.UI.Dialogs.ShowMessage(text, "ALIEF FEA MODELER - update")


def auto_check():
    """Once per Rhino session, in the background; the question appears when Rhino is idle."""
    try:
        import Rhino
        import scriptcontext as sc
    except Exception:
        return
    state = sc.sticky.get(STICKY)
    if isinstance(state, dict) and state.get("checked"):
        return
    sc.sticky[STICKY] = state = dict(checked=True, info=None)
    prefs = load_prefs()
    if not prefs.get("auto", True):
        return
    root = install_root()

    def work():
        try:
            info = fetch_latest(timeout=6.0)
            if is_newer(info, root) and info.get("version") != prefs.get("skip"):
                state["info"] = info
        except Exception:
            pass
        state["done"] = True
    import threading
    th = threading.Thread(target=work)
    th.daemon = True
    th.start()
    t0 = time.time()

    def on_idle(sender, e):
        if not state.get("done") and time.time() - t0 < 30.0:
            return
        try:
            Rhino.RhinoApp.Idle -= on_idle
        except Exception:
            pass
        info = state.get("info")
        if not info:
            return
        try:
            if Rhino.Commands.Command.InCommand():
                state["checked"] = False            # busy: ask at the next start of a command of ours
                return
        except Exception:
            pass
        ans = _ask(info, installed_version(root))
        p = load_prefs()
        p["last_check"] = time.time()
        p["skip"] = info.get("version", "") if ans == 2 else ""
        save_prefs(p)
        if ans == 6:
            run_update(info, root)
    try:
        Rhino.RhinoApp.Idle += on_idle
    except Exception:
        pass
