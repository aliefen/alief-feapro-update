"""Team sync for ALIEF FEA MODELER.

Several people model one structure at the same time on different computers / offices.
The model is divided into ZONES (e.g. DECK, SHELL, BHD-FR40, DB). Each person owns one zone and
models it in his own .3dm; the work of the other zones appears in his file as locked reference
members (layer ALIEF_SYNC::<zone>), so everybody sees and snaps to the whole model and any of the
files can be exported to ALIEF FEAPRO as one connected model.

Exchange goes through ONE SHARED FOLDER (Google Drive / OneDrive / Dropbox desktop folder, or a
network share):

    <folder>/project.json          project information
    <folder>/library.json          shared materials, plate properties, sections, user catalogue
    <folder>/zones/<ZONE>.3dm      members of a zone (written by its owner)
    <folder>/zones/<ZONE>.json     revision, owner, time, file hash
    <folder>/zones/<ZONE>.owner    who owns the zone

Saving the .3dm (Ctrl+S) publishes the own zone; the other zones are refreshed automatically when
their owner saves (checked every minute and right after a save). Two people never write the same
file, so nothing is overwritten; a zone can be taken over explicitly.
"""
import hashlib
import json
import os
import socket
import time
import uuid

import System
import Rhino
import Rhino.Geometry as rg
import scriptcontext as sc

from . import core as C
from . import rhinoio as io

K_SYNC = "AF_SYNC_ZONE"      # imported member: zone it came from
K_REV = "AF_SYNC_REV"        # imported member: file hash of that zone
K_UID = io.K_UID             # stable member id (FEAPRO ids stay the same in every file)
K_LAYER = "AF_LAYER"         # layer path in the owner's file
SYNC_LAYER = "ALIEF_SYNC"
ENTRY = "sync"
FORMAT = "ALIEF_FEA_SYNC"
_STATE = {"pending": False, "last_poll": 0.0, "last_push": 0.0, "last_pull": 0.0, "doc": None, "cfg": None,
          "warned": set(), "busy": False}


# =========================================================================== configuration
def default_cfg():
    return dict(folder="", zone="", user=os.environ.get("USERNAME", "") or "", auto=True, interval=60)


def load_cfg():
    cfg = default_cfg()
    try:
        d = json.loads(io._data(ENTRY) or "{}")
        if isinstance(d, dict):
            cfg.update({k: v for k, v in d.items() if k in cfg})
    except ValueError:
        pass
    return cfg


def save_cfg(cfg):
    io._set_data(ENTRY, json.dumps(cfg))
    _STATE["cfg"] = dict(cfg)


def _cfg():
    """Configuration of the active document (cached; re-read when the document changes)."""
    d = Rhino.RhinoDoc.ActiveDoc
    sn = d.RuntimeSerialNumber if d is not None else None
    if _STATE["doc"] != sn or _STATE["cfg"] is None:
        _STATE["doc"] = sn
        _STATE["cfg"] = load_cfg()
    return _STATE["cfg"]


_ISDIR = {}


def configured(cfg):
    """Folder + zone set and the folder reachable (the folder test is cached 30 s - an offline network share
    must not freeze Rhino)."""
    folder = cfg.get("folder")
    if not (folder and cfg.get("zone")):
        return False
    now = time.time()
    hit = _ISDIR.get(folder)
    if hit is None or now - hit[1] > 30.0:
        hit = (os.path.isdir(folder), now)
        _ISDIR[folder] = hit
    return hit[0]


def computer():
    return os.environ.get("COMPUTERNAME") or socket.gethostname() or "PC"


def zones_dir(cfg):
    return os.path.join(cfg["folder"], "zones")


def _p(cfg, zone, ext):
    return os.path.join(zones_dir(cfg), C.safe_zone(zone) + ext)


def _read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def _write_atomic(path, data):
    tmp = "%s.tmp-%s" % (path, uuid.uuid4().hex[:6])
    mode = "wb" if isinstance(data, bytes) else "w"
    kw = {} if isinstance(data, bytes) else {"encoding": "utf-8"}
    try:
        with open(tmp, mode, **kw) as f:
            f.write(data)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass


def _md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _base_path(cfg):
    key = hashlib.md5(("%s|%s" % (os.path.normcase(cfg["folder"]), C.safe_zone(cfg["zone"]))).encode("utf-8")).hexdigest()[:12]
    from . import ui
    return os.path.join(ui.cfg_dir(), "sync_base_%s.json" % key)


# =========================================================================== zones / ownership
def zone_owner(cfg, zone):
    try:
        with open(_p(cfg, zone, ".owner"), "r", encoding="utf-8") as f:
            parts = f.read().strip().split("|")
        return dict(user=parts[0], computer=parts[1] if len(parts) > 1 else "", since=parts[2] if len(parts) > 2 else "")
    except OSError:
        return None


def is_mine(cfg, zone=None):
    o = zone_owner(cfg, zone or cfg["zone"])
    return o is None or (o["user"].lower() == (cfg.get("user") or "").lower() and o["computer"].lower() == computer().lower())


def claim_zone(cfg):
    os.makedirs(zones_dir(cfg), exist_ok=True)
    _write_atomic(_p(cfg, cfg["zone"], ".owner"), "%s|%s|%s" % (cfg.get("user") or "?", computer(), time.strftime("%Y-%m-%d %H:%M")))


def ensure_project(cfg):
    os.makedirs(zones_dir(cfg), exist_ok=True)
    pj = os.path.join(cfg["folder"], "project.json")
    if not os.path.exists(pj):
        st = io.load_settings()
        _write_atomic(pj, json.dumps(dict(format=FORMAT, version=1, project=st.get("project", ""), ship=st.get("ship", ""),
                                          units=str(sc.doc.ModelUnitSystem), created_by=cfg.get("user", ""),
                                          created=time.strftime("%Y-%m-%d %H:%M")), indent=1))


def manifests(cfg):
    out = []
    try:
        names = os.listdir(zones_dir(cfg))
    except OSError:
        return out
    for nm in sorted(names):
        if nm.lower().endswith(".json") and ".tmp-" not in nm:
            m = _read_json(os.path.join(zones_dir(cfg), nm))
            if m and m.get("zone") and nm == C.safe_zone(m["zone"]) + ".json":
                out.append(m)
    return out


def imported_zones():
    """Zones that have reference members in this document."""
    return set(o.Attributes.GetUserString(K_SYNC) for o in io.af_objects() if o.Attributes.GetUserString(K_SYNC))


def imported_revs():
    """{zone: file hash / signature} of the zones imported into this document (kept in the document data, so a
    zone with 0 members or a half-deleted zone is never imported twice)."""
    try:
        d = json.loads(io._data("sync_revs") or "{}")
    except ValueError:
        d = {}
    revs = d if isinstance(d, dict) else {}
    for z in imported_zones():
        revs.setdefault(z, "")
    return revs


def _set_rev(zone, rev):
    try:
        d = json.loads(io._data("sync_revs") or "{}")
    except ValueError:
        d = {}
    if not isinstance(d, dict):
        d = {}
    if rev is None:
        d.pop(zone, None)
    else:
        d[zone] = rev
    io._set_data("sync_revs", json.dumps(d))


# =========================================================================== library
def _merge_library(cfg, write_shared=True, apply_mine=True):
    lp = os.path.join(cfg["folder"], "library.json")
    shared = _read_json(lp)
    if shared is None and os.path.exists(lp):
        return ["library.json is being copied by the cloud folder - library sync next time"], 0, 0
    shared = shared or {}
    mine = io.load_library()
    base = _read_json(_base_path(cfg)) or {}
    new_mine, new_shared, conflicts, n_in, n_out = C.merge3_library(base, mine, shared)
    changed_shared = C.library_to_json(new_shared) != C.library_to_json(shared) if shared else True
    if write_shared and (changed_shared or not os.path.exists(lp)):
        _write_atomic(lp, C.library_to_json(new_shared))
    if apply_mine:
        if C.library_to_json(new_mine) != C.library_to_json(mine):
            io.save_library(new_mine)
            try:
                from . import live
                live.invalidate_all()
            except Exception:
                pass
        try:      # merge base = the shared state this document has taken over (my unpublished edits stay 'mine')
            _write_atomic(_base_path(cfg), C.library_to_json(new_shared if write_shared else shared))
        except OSError:
            pass
    return conflicts, n_in, n_out


# =========================================================================== push (publish my zone)
def _file_layer(f, name, color):
    """Layer index in a File3dm (RhinoCommon names differ a little between versions)."""
    for tab in ("AllLayers", "Layers"):
        try:
            return int(getattr(f, tab).AddLayer(name, color))
        except Exception:
            pass
    try:
        L = Rhino.DocObjects.Layer()
        L.Name = name
        L.Color = color
        f.AllLayers.Add(L)
        return f.AllLayers.Count - 1
    except Exception:
        return 0


def _clean_attr(a):
    """No groups / materials / linetypes of another file travel with a member."""
    for fn in ("RemoveFromAllGroups",):
        try:
            getattr(a, fn)()
        except Exception:
            pass
    try:
        a.MaterialSource = Rhino.DocObjects.ObjectMaterialSource.MaterialFromLayer
    except Exception:
        pass
    try:
        a.LinetypeSource = Rhino.DocObjects.ObjectLinetypeSource.LinetypeFromLayer
    except Exception:
        pass


def _signature(objs):
    """Content fingerprint of the own members (geometry + FEA data + layer), so saving without changes
    does not make the team re-import the zone."""
    h = hashlib.md5()
    rows = []
    for o in objs:
        g = o.Geometry
        a = o.Attributes
        parts = [str(o.Id), a.GetUserString(io.K_KIND) or "", a.GetUserString(io.K_PROP) or "", a.GetUserString(io.K_SEC) or "",
                 a.GetUserString(io.K_SIDE) or "", a.GetUserString(io.K_FLANGE) or "", a.GetUserString(io.K_OFFSET) or "",
                 a.GetUserString(io.K_ORIENT) or "", a.GetUserString(io.K_MESH) or "", a.GetUserString(io.K_ROLE) or "",
                 a.Name or "", str(a.LayerIndex)]
        try:
            bb = g.GetBoundingBox(True)
            parts.append("%.4f,%.4f,%.4f,%.4f,%.4f,%.4f" % (bb.Min.X, bb.Min.Y, bb.Min.Z, bb.Max.X, bb.Max.Y, bb.Max.Z))
        except Exception:
            pass
        try:
            if isinstance(g, rg.Curve):
                parts.append("%.4f" % g.GetLength())
                for t in (0.0, 0.25, 0.5, 0.75, 1.0):
                    p = g.PointAtNormalizedLength(t)
                    parts.append("%.4f,%.4f,%.4f" % (p.X, p.Y, p.Z))
            else:
                b = io.brep_of(g)
                if b is not None:
                    parts.append("F%d E%d V%d" % (b.Faces.Count, b.Edges.Count, b.Vertices.Count))
                    for i in range(b.Vertices.Count):
                        p = b.Vertices[i].Location
                        parts.append("%.4f,%.4f,%.4f" % (p.X, p.Y, p.Z))
                    for i in range(b.Edges.Count):
                        parts.append("%.4f" % b.Edges[i].GetLength())
        except Exception:
            pass
        rows.append("|".join(parts))
    for r in sorted(rows):
        h.update(r.encode("utf-8"))
    return h.hexdigest()


def own_members():
    return [o for o in io.af_objects() if not o.Attributes.GetUserString(K_SYNC)]


def push(cfg, quiet=False):
    """Write the own zone to the shared folder. Returns a message."""
    if not configured(cfg):
        return "Team sync is not set up (AF_SyncSetup)."
    zone = C.safe_zone(cfg["zone"])
    if not is_mine(cfg):
        o = zone_owner(cfg, zone)
        return "Zone %s now belongs to %s (%s) - your changes were NOT published. Run AF_SyncSetup." % (zone, o["user"], o["computer"])
    ensure_project(cfg)
    if zone_owner(cfg, zone) is None:
        claim_zone(cfg)
    objs = own_members()
    f = Rhino.FileIO.File3dm()
    try:
        f.Settings.ModelUnitSystem = sc.doc.ModelUnitSystem
        f.Settings.ModelAbsoluteTolerance = sc.doc.ModelAbsoluteTolerance
    except Exception:
        pass
    sig = _signature(objs)
    old = _read_json(_p(cfg, zone, ".json")) or {}
    if old.get("sig") == sig and os.path.exists(_p(cfg, zone, ".3dm")) and old.get("owner", "").lower() == (cfg.get("user") or "").lower():
        conflicts, n_in, n_out = _merge_library(cfg, write_shared=True, apply_mine=False)
        _STATE["last_push"] = time.time()
        return "Zone %s unchanged (rev %s) - nothing to publish%s" % (zone, old.get("rev", "?"),
                                                                     (", %d library item(s) shared" % n_out) if n_out else "")
    layers = {}
    seen = set()
    n_pl = n_pr = 0
    for o in objs:
        path = sc.doc.Layers[o.Attributes.LayerIndex].FullPath
        if path not in layers:
            layers[path] = _file_layer(f, path.replace("::", " - ")[:250], sc.doc.Layers[o.Attributes.LayerIndex].Color)
        a = o.Attributes.Duplicate()
        a.SetUserString(K_UID, io.uid_of(o, seen))
        a.SetUserString(K_LAYER, path)
        a.LayerIndex = layers[path]
        _clean_attr(a)
        f.Objects.Add(o.Geometry.Duplicate(), a)
        if io.is_plate(o):
            n_pl += 1
        else:
            n_pr += 1
    part = _p(cfg, zone, ".3dm")
    tmp = "%s.tmp-%s.3dm" % (part[:-4], uuid.uuid4().hex[:6])
    ok = False
    try:
        ok = f.Write(tmp, 0)
    except Exception:
        ok = False
    if not ok:
        try:
            ok = f.Write(tmp, 7)
        except Exception:
            ok = False
    try:
        f.Dispose()
    except Exception:
        pass
    if not ok or not os.path.exists(tmp):
        return "Could not write %s" % part
    try:
        os.replace(tmp, part)
    except OSError as ex:
        try:
            os.remove(tmp)
        except OSError:
            pass
        return "Zone %s not published - %s is in use (cloud folder busy?). It is tried again at the next save. (%s)" % (zone, part, ex)
    man = dict(format=FORMAT, zone=zone, owner=cfg.get("user", ""), computer=computer(), rev=int(old.get("rev", 0)) + 1,
               saved=time.strftime("%Y-%m-%d %H:%M:%S"), saved_epoch=time.time(), plates=n_pl, profiles=n_pr,
               units=str(sc.doc.ModelUnitSystem), hash=_md5(part), sig=sig, app=C.VERSION,
               file=os.path.basename(sc.doc.Path or "") if sc.doc.Path else "")
    _write_atomic(_p(cfg, zone, ".json"), json.dumps(man, indent=1))
    conflicts, n_in, n_out = _merge_library(cfg, write_shared=True, apply_mine=False)
    _STATE["last_push"] = time.time()
    msg = "Zone %s published: rev %d, %d plates, %d profiles%s" % (zone, man["rev"], n_pl, n_pr,
                                                                     (", %d library item(s) shared" % n_out) if n_out else "")
    if conflicts:
        msg += "\n" + "\n".join(conflicts)
    return msg


# =========================================================================== pull (refresh the other zones)
def _delete_zone(zone):
    """Delete the reference members of a zone - also when the ALIEF_SYNC layer is hidden or locked.
    Returns (deleted, left over)."""
    objs = [o for o in io.af_objects() if o.Attributes.GetUserString(K_SYNC) == zone]
    n = io.delete_objects(objs)
    left = len([o for o in io.af_objects() if o.Attributes.GetUserString(K_SYNC) == zone])
    return n, left


def _zone_color(zone):
    k = int(hashlib.md5(zone.encode("utf-8")).hexdigest()[:6], 16)
    return C.SECTION_PALETTE[k % len(C.SECTION_PALETTE)]


def _add(geo, attr):
    try:
        return sc.doc.Objects.Add(geo, attr)
    except Exception:
        pass
    if isinstance(geo, rg.Brep):
        return sc.doc.Objects.AddBrep(geo, attr)
    if isinstance(geo, rg.Extrusion):
        return sc.doc.Objects.AddExtrusion(geo, attr)
    if isinstance(geo, rg.Surface):
        return sc.doc.Objects.AddSurface(geo, attr)
    if isinstance(geo, rg.Curve):
        return sc.doc.Objects.AddCurve(geo, attr)
    if isinstance(geo, rg.Mesh):
        return sc.doc.Objects.AddMesh(geo, attr)
    return System.Guid.Empty


def import_zone(cfg, man):
    zone = man["zone"]
    part = _p(cfg, zone, ".3dm")
    if not os.path.exists(part):
        return None
    if man.get("hash") and _md5(part) != man["hash"]:
        return None        # the cloud folder has not finished copying - try again later
    f = Rhino.FileIO.File3dm.Read(part)
    if f is None:
        return None
    try:
        k = 1.0
        try:
            k = Rhino.RhinoMath.UnitScale(f.Settings.ModelUnitSystem, sc.doc.ModelUnitSystem)
        except Exception:
            k = 1.0
        xf = rg.Transform.Scale(rg.Point3d.Origin, k) if abs(k - 1.0) > 1e-12 else None
        gone, left = _delete_zone(zone)
        if left:
            return -1          # old copy could not be removed - never import a second copy
        ensure_zone_layer(zone)
        n = 0
        for fo in f.Objects:
            geo = fo.Geometry
            if geo is None:
                continue
            geo = geo.Duplicate()
            if xf is not None:
                geo.Transform(xf)
            a = fo.Attributes.Duplicate()
            path = a.GetUserString(K_LAYER) or "Default"
            a.LayerIndex = io.ensure_layer("%s::%s::%s" % (SYNC_LAYER, zone, path))
            a.SetUserString(K_SYNC, zone)
            a.SetUserString(K_REV, man.get("hash", ""))
            a.Mode = Rhino.DocObjects.ObjectMode.Locked
            _clean_attr(a)
            if _add(geo, a) != System.Guid.Empty:
                n += 1
        _set_rev(zone, man.get("sig") or man.get("hash", ""))
        return n
    finally:
        try:
            f.Dispose()
        except Exception:
            pass


def ensure_zone_layer(zone):
    io.ensure_layer(SYNC_LAYER, "#7F8C8D")
    return io.ensure_layer("%s::%s" % (SYNC_LAYER, zone), _zone_color(zone))


def pull(cfg, force=False):
    """Import new revisions of the other zones. Returns (updated zones, messages)."""
    if not configured(cfg):
        return 0, ["Team sync is not set up (AF_SyncSetup)."]
    me = C.safe_zone(cfg["zone"])
    have = imported_revs()
    msgs = []
    done = 0
    mans = manifests(cfg)
    live_zones = set(C.safe_zone(m["zone"]) for m in mans)
    for z in sorted(have):
        if z not in live_zones and z != me and os.path.isdir(zones_dir(cfg)):
            n, left = _delete_zone(z)          # the zone was removed / renamed by its owner
            if not left:
                _set_rev(z, None)
            done += 1
            msgs.append("Zone %s no longer exists in the team folder - %d reference members removed" % (z, n))
    for m in mans:
        z = C.safe_zone(m["zone"])
        if z == me:
            continue
        o = zone_owner(cfg, z)
        if o is not None and is_mine(cfg, z) and z not in have:
            continue           # a previous zone of mine - its members are my own members now
        if not force and have.get(z) in (m.get("sig"), m.get("hash")) and have.get(z):
            continue
        n = import_zone(cfg, dict(m, zone=z))
        if n is None:
            msgs.append("Zone %s: new version is still being copied by the cloud folder - next check" % z)
            continue
        if n < 0:
            msgs.append("Zone %s: the old reference members could not be removed (locked?) - not imported again" % z)
            continue
        done += 1
        msgs.append("Zone %s updated from %s (%s, rev %s): %d members" % (z, m.get("owner", "?"), m.get("saved", "?"),
                                                                        m.get("rev", "?"), n))
    conflicts, n_in, n_out = _merge_library(cfg, write_shared=False, apply_mine=True)
    if n_in:
        msgs.append("%d library item(s) received from the team" % n_in)
    msgs += conflicts
    if done:
        sc.doc.Views.Redraw()
        try:
            from . import ui
            ui.refresh_panel()
        except Exception:
            pass
    _STATE["last_pull"] = time.time()
    return done, msgs


def retire_zone(cfg, zone):
    """Remove a zone of mine from the team folder (used when I move to another zone name, so its members
    are not published twice). Returns True when files were removed."""
    zone = C.safe_zone(zone)
    if not is_mine(cfg, zone):
        return False
    gone = False
    for ext in (".3dm", ".json", ".owner"):
        try:
            os.remove(_p(cfg, zone, ext))
            gone = True
        except OSError:
            pass
    return gone


def adopt_zone(zone):
    """Take over a zone: its imported members become own members (unlocked, original layers, same ids)."""
    _set_rev(zone, None)
    n = 0
    for o in io.af_objects():
        if o.Attributes.GetUserString(K_SYNC) != zone:
            continue
        a = o.Attributes.Duplicate()
        a.LayerIndex = io.ensure_layer(a.GetUserString(K_LAYER) or "Default")
        a.DeleteUserString(K_SYNC)
        a.DeleteUserString(K_REV)
        a.Mode = Rhino.DocObjects.ObjectMode.Normal
        sc.doc.Objects.ModifyAttributes(o, a, True)
        n += 1
    return n


def status_rows(cfg):
    """[(zone, owner, saved, rev, members, state)] for the panel / report."""
    rows = []
    if not configured(cfg):
        return rows
    me = C.safe_zone(cfg["zone"])
    have = imported_revs()
    for m in manifests(cfg):
        z = C.safe_zone(m["zone"])
        n = int(m.get("plates", 0)) + int(m.get("profiles", 0))
        if z == me:
            state = "mine" if is_mine(cfg) else "TAKEN OVER by %s" % (zone_owner(cfg, z) or {}).get("user", "?")
        elif z not in have:
            state = "new - not loaded yet"
        elif have[z] and have[z] in (m.get("sig"), m.get("hash")):
            state = "up to date"
        else:
            state = "newer version available"
        rows.append((z, "%s (%s)" % (m.get("owner", "?"), m.get("computer", "?")), m.get("saved", "?"), m.get("rev", "?"), n, state))
    if me not in [r[0] for r in rows]:
        rows.insert(0, (me, "%s (%s)" % (cfg.get("user", "?"), computer()), "-", 0, len(own_members()), "mine - not published yet"))
    return rows


def status_text():
    cfg = _cfg()
    if not cfg.get("folder") or not cfg.get("zone"):
        return ""
    t = _STATE["last_pull"] or _STATE["last_push"]
    return "Team: %s (%s)%s" % (C.safe_zone(cfg["zone"]), cfg.get("user", ""),
                                ("  synced %s" % time.strftime("%H:%M", time.localtime(t))) if t else "")


# =========================================================================== automatic
def on_saved(e):
    """EndSaveDocument: publish the own zone (no change to the document), refresh the others on idle."""
    try:
        if e.ExportSelected:
            return
        name = (e.FileName or "").lower()
        if "autosave" in name or name.endswith(".rhl") or not name.endswith(".3dm"):
            return
    except Exception:
        pass
    cfg = load_cfg()
    _STATE["cfg"] = cfg
    if not configured(cfg) or not cfg.get("auto", True):
        return
    try:
        Rhino.RhinoApp.WriteLine("ALIEF FEA team sync: " + push(cfg).replace("\n", " | "))
    except Exception as ex:
        Rhino.RhinoApp.WriteLine("ALIEF FEA team sync: publishing failed - %s" % ex)
    _STATE["pending"] = True


def idle(now):
    """Called by the live service on Rhino's Idle event (never during a command)."""
    if _STATE["busy"]:
        return
    cfg = _cfg()
    if not cfg.get("folder") or not cfg.get("auto", True):
        return
    interval = max(15.0, float(cfg.get("interval", 60) or 60))
    if not _STATE["pending"] and now - _STATE["last_poll"] < interval:
        return
    if not configured(cfg):
        _STATE["last_poll"] = now
        return
    _STATE["pending"] = False
    _STATE["last_poll"] = now
    _STATE["busy"] = True
    try:
        n, msgs = pull(cfg)
        for m in msgs:
            if n or m not in _STATE["warned"]:
                Rhino.RhinoApp.WriteLine("ALIEF FEA team sync: " + m)
                _STATE["warned"].add(m)
    except Exception as ex:
        key = "pull:%s" % ex
        if key not in _STATE["warned"]:
            _STATE["warned"].add(key)
            Rhino.RhinoApp.WriteLine("ALIEF FEA team sync: %s" % ex)
    finally:
        _STATE["busy"] = False


def forget_cache():
    _STATE["cfg"] = None
