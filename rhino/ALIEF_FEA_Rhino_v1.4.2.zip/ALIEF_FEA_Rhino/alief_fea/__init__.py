"""ALIEF FEA MODELER for Rhino 8 - structure modelling for ALIEF FEAPRO.
PT. Alief Energy Utama - Naval Architect & Marine Engineer Consultant, Batam."""
from .core import APP, VERSION  # noqa
