"""AF_ commands of ALIEF FEA MODELER for Rhino 8."""
import csv
import math
import os

import Rhino
import Rhino.Geometry as rg
import scriptcontext as sc
import rhinoscriptsyntax as rs

from . import core as C
from . import rhinoio as io
from . import ui
from . import live

SRF_FILTER = rs.filter.surface | rs.filter.polysurface | rs.filter.extrusion
_CLEANED = set()


def _start():
    """Every command: make sure the live display / index / team watcher run, and remove the 3D solids
    that versions 1.0.2 / 1.0.3 put into the model (the 3D view is drawn without objects now)."""
    try:
        live.ensure()
    except Exception as ex:
        _say("live display not started: %s" % ex)
    sn = sc.doc.RuntimeSerialNumber
    if sn not in _CLEANED:
        _CLEANED.add(sn)
        try:
            n = io.clear_preview()
            if n:
                _say("%d old 3D preview solids removed - the 3D view is now drawn live (AF_3DView)" % n)
        except Exception:
            pass
    return io.load_library(), io.load_settings()


def _say(text):
    Rhino.RhinoApp.WriteLine("ALIEF FEA: " + text)


def _names(lib, key):
    return [x["name"] for x in lib.get(key, [])]


def _member(rhino_object):
    if rhino_object.Attributes.GetUserString(io.K_PREVIEW):
        src = rhino_object.Attributes.GetUserString(io.K_SRC)
        return io.find(src) if src else None
    return rhino_object


def _plate_filter(rhino_object, geometry, component_index):
    return io.is_plate(_member(rhino_object))


def _profile_filter(rhino_object, geometry, component_index):
    return io.is_profile(_member(rhino_object))


def _member_filter(rhino_object, geometry, component_index):
    m = _member(rhino_object)
    return io.is_plate(m) or io.is_profile(m)


def _no_solid_filter(rhino_object, geometry, component_index):
    """Ordinary geometry only (not the ALIEF 3D profiles / preview solids)."""
    return not rhino_object.Attributes.GetUserString(io.K_PREVIEW)


def _members(ids):
    """Unique FEA members behind picked ids (a click on a 3D profile selects its curve)."""
    out, seen = [], set()
    for i in ids or []:
        m = io.member_obj(i)
        if m is not None and str(m.Id) not in seen:
            seen.add(str(m.Id))
            out.append(m)
    return out


def _solids(lib, st, objs):
    """3D view refresh - the live display follows every change by itself; this only makes sure it runs."""
    try:
        lv = live.ensure()
        if objs is None:
            lv.invalidate_all()
    except Exception as ex:
        _say("3D view not updated: %s" % ex)


PLATE_ROLES = ["Plate", "Shell", "Deck", "Bulkhead", "Web", "Girder", "Floor", "Bracket", "Face plate"]


def _pick(button, prompt, flt, what, custom_filter=None, hint="press the button to select them in Rhino"):
    return dict(button=button, prompt=prompt, filter=flt, what=what, custom_filter=custom_filter, hint=hint, icon=None)


def _ids_or_get(r, prompt, flt, custom_filter=None):
    """Objects chosen with the dialog's Select button, otherwise ask now (preselection works too)."""
    ids = [i for i in (r.get("_ids") or []) if io.find(i) is not None]
    if ids:
        return ids
    return rs.GetObjects(prompt, flt, preselect=True, custom_filter=custom_filter) or []


def _surfaces_to_plates(ids, prop, role, lib, st):
    """Surfaces / polysurfaces -> plates (one plate per face). Returns (plates, curved faces)."""
    t = io.tol()
    n = curved = 0
    for oid in ids:
        obj = io.find(oid)
        if obj is None or obj.Attributes.GetUserString("AF_SYNC_ZONE"):
            continue
        b = io.brep_of(obj.Geometry)
        if b is None:
            continue
        for i in range(b.Faces.Count):
            if not b.Faces[i].IsPlanar(t):
                curved += 1
        if b.Faces.Count == 1 and isinstance(obj.Geometry, rg.Brep):
            io.tag_plate(obj.Id, lib, prop, role)
            n += 1
        else:
            for i in range(b.Faces.Count):
                io.add_plate(b.Faces[i].DuplicateFace(False), prop, lib, st, name=obj.Attributes.Name or "",
                             role=role, layer_index=obj.Attributes.LayerIndex)
                n += 1
            io.delete_objects([obj])
    return n, curved


def _need(lib, key, what):
    if not lib.get(key):
        ui.message("Add a %s first (ALIEF FEA panel > %s)." % (what, "Plates" if key == "plate_props" else "Profiles"))
        return False
    return True


def _done(lib=None):
    sc.doc.Views.Redraw()
    ui.refresh_panel()


def _host_normal(pt, s):
    """Normal (oriented like the Rhino surface) of the AF plate under pt, or None."""
    best, bd = None, 1e30
    for obj in io.af_objects("plate"):
        b = io.brep_of(obj.Geometry)
        if b is None:
            continue
        cp = b.ClosestPoint(pt)
        d = cp.DistanceTo(pt)
        if d < bd:
            bd, best = d, (b, cp)
    if best is None or bd * s > max(1.0, io.tol() * s * 10):
        return None
    b, cp = best
    fi, fbest = 0, 1e30
    for i in range(b.Faces.Count):
        f = b.Faces[i]
        rc, u, v = f.ClosestPoint(cp)
        if rc:
            d = f.PointAt(u, v).DistanceTo(cp)
            if d < fbest:
                fi, fbest = i, d
    return io.face_normal(b.Faces[fi], cp)


def _web_dir(side, pt, s):
    if side in C.AXES:
        return list(C.AXES[side])
    n = _host_normal(pt, s)
    if n is None:
        return None
    return C.v_mul(n, 1.0 if side == "+N" else -1.0)


def _add_planar(pts_model, prop, lib, st, role, name=""):
    """Plate from a list of model points: quad / triangle / polygon; non-planar quads -> 2 triangles."""
    s = io.scale()
    P = [io.P2L(p, s) for p in pts_model]
    t = io.tol()
    out = []
    groups = [pts_model]
    if len(P) == 4 and C.planarity(P) > max(t * s, 1e-3):
        groups = [[pts_model[0], pts_model[1], pts_model[2]], [pts_model[0], pts_model[2], pts_model[3]]]
    for g in groups:
        if len(g) in (3, 4):
            b = rg.Brep.CreateFromCornerPoints(*(list(g) + [t]))
        else:
            b = None
        if b is None:
            bs = rg.Brep.CreatePlanarBreps([rg.PolylineCurve(list(g) + [g[0]])], t)
            b = bs[0] if bs else None
        if b is not None:
            out.append(io.add_plate(b, prop, lib, st, name=name, role=role))
    return out


def _pt(p):
    return rg.Point3d(p[0], p[1], p[2])


def _pl(p):
    return [p.X, p.Y, p.Z]


# =========================================================================== plates
def plate():
    lib, st = _start()
    if not _need(lib, "plate_props", "plate property"):
        return
    props = _names(lib, "plate_props")
    flt = rs.filter.curve | SRF_FILTER
    r = ui.ask("AF_Plate - plates from closed curves or surfaces", [
        dict(key="prop", label="Plate property", kind="choice", choices=props, value=st["active_prop"]),
        dict(key="role", label="Member type", kind="choice", choices=PLATE_ROLES, value="Plate"),
        dict(key="keep", label="Keep the input curves", kind="bool", value=True),
        dict(key="mesh", label="Local mesh size [mm] (0 = global)", kind="float", value=0.0, min=0.0)],
        image="img_plate",
        intro="Select closed planar curves (polylines, rectangles, arcs ...) and / or surfaces / polysurfaces, then "
              "Assign. A curve lying inside another curve becomes an opening of that plate; a polysurface gives one "
              "plate per face.",
        pick=_pick("Select curves / surfaces...", "Select closed curves and / or surfaces for the plates", flt,
                   "object(s)", _no_solid_filter))
    if not r:
        return
    ids = _ids_or_get(r, "Select closed planar curves and / or surfaces for the plates", flt, _no_solid_filter)
    if not ids:
        return
    crv_ids = [i for i in ids if rs.IsCurve(i)]
    srf_ids = [i for i in ids if not rs.IsCurve(i)]
    crvs = [c for c in (rs.coercecurve(i) for i in crv_ids) if c is not None and c.IsClosed]
    n = 0
    if crvs:
        breps = rg.Brep.CreatePlanarBreps(crvs, io.tol()) or []
        for b in breps:
            for i in range(b.Faces.Count):
                io.add_plate(b.Faces[i].DuplicateFace(False), r["prop"], lib, st, role=r["role"], mesh_size=r["mesh"])
                n += 1
        if not breps:
            _say("the closed curves are not planar - no plate made from them")
        elif not r["keep"]:
            rs.DeleteObjects(crv_ids)
    n_srf, curved = _surfaces_to_plates(srf_ids, r["prop"], r["role"], lib, st) if srf_ids else (0, 0)
    if not n and not n_srf:
        ui.message("No plate could be made - select closed planar curves or surfaces.")
        return
    st["active_prop"] = r["prop"]
    io.save_settings(st)
    _say("%d plate(s) from curves, %d from surfaces - %s" % (n, n_srf, r["prop"]))
    _done()


def surface_to_plate():
    lib, st = _start()
    if not _need(lib, "plate_props", "plate property"):
        return
    props = _names(lib, "plate_props")
    r = ui.ask("AF_SurfaceToPlate - surfaces become plates", [
        dict(key="prop", label="Plate property", kind="choice", choices=props, value=st["active_prop"]),
        dict(key="role", label="Member type", kind="choice", choices=PLATE_ROLES, value="Plate"),
        dict(key="facet", label="Facet size for curved surfaces [mm]", kind="float", value=st.get("facet_size", 300.0), min=10.0)],
        image="img_srf2plate",
        intro="Select surfaces or polysurfaces modelled in Rhino or imported (Maxsurf, IGES, STEP), then Assign. "
              "Polysurfaces are split into one plate per face. Curved faces (shell plating) are exported as conformal "
              "planar facets.",
        pick=_pick("Select surfaces...", "Select surfaces / polysurfaces to become plates", SRF_FILTER, "surface(s)",
                   _no_solid_filter))
    if not r:
        return
    ids = _ids_or_get(r, "Select surfaces / polysurfaces", SRF_FILTER, _no_solid_filter)
    if not ids:
        return
    n, curved = _surfaces_to_plates(ids, r["prop"], r["role"], lib, st)
    st["facet_size"] = r["facet"]
    st["active_prop"] = r["prop"]
    io.save_settings(st)
    _say("%d plate(s) assigned (%d curved -> facets on export)" % (n, curved))
    _done()


# =========================================================================== web / girder
def web():
    lib, st = _start()
    if not _need(lib, "plate_props", "plate property"):
        return
    props = _names(lib, "plate_props")
    secs = _names(lib, "sections") or ["(none)"]
    tops = ["None", "Face plate (shell)", "Edge profile (beam)"]
    r = ui.ask("AF_Web - web / girder / floor / frame", [
        dict(key="h", label="Web height h [mm]", kind="float", value=st.get("web_height", 500.0), min=1.0),
        dict(key="prop", label="Web plate property", kind="choice", choices=props, value=st.get("web_prop") or st["active_prop"]),
        dict(key="side", label="Web direction", kind="choice", choices=C.WEB_SIDES, labels=C.WEB_SIDE_LABELS, value="+N",
             tip="+N: along the normal of the plate under the base line; or a fixed global axis"),
        dict(key="top", label="Free edge", kind="choice", choices=tops, value=st.get("top", tops[1]),
             images={"None": "img_web_none", "Face plate (shell)": "img_web", "Edge profile (beam)": "img_web_edge"}),
        dict(key="fpw", label="Face plate width bf [mm]", kind="float", value=st.get("fp_width", 150.0), min=1.0),
        dict(key="fpp", label="Face plate property", kind="choice", choices=props, value=st.get("fp_prop") or st["active_prop"]),
        dict(key="fps", label="Face plate position", kind="choice", choices=["Centred", "One side (+)", "One side (-)"],
             value=st.get("fp_side", "Centred")),
        dict(key="esec", label="Edge profile section", kind="choice", choices=secs, value=st.get("edge_section") or secs[0]),
        dict(key="piece", label="Max. piece length on curved paths [mm]", kind="float", value=500.0, min=10.0)],
        image="img_web",
        intro="Select the base line(s) of the web lying on the plating (line, polyline or curve), or press Enter and "
              "pick two points. The web plate rises by h in the chosen direction.")
    if not r:
        return
    st.update(web_height=r["h"], web_prop=r["prop"], top=r["top"], fp_width=r["fpw"], fp_prop=r["fpp"], fp_side=r["fps"],
              edge_section=r["esec"])
    io.save_settings(st)
    s = io.scale()
    paths = []
    ids = rs.GetObjects("Select web base lines (Enter = pick two points)", rs.filter.curve, preselect=True)
    if ids:
        for i in ids:
            crv = rs.coercecurve(i)
            if crv is not None:
                pts = io.curve_points(crv, float(st.get("chord_tol", 1.0)) / s, r["piece"] / s)
                if crv.IsClosed:
                    pts = pts + [pts[0]]
                paths.append(pts)
    else:
        a = rs.GetPoint("Web start point (on the plating)")
        if a is None:
            return
        b = rs.GetPoint("Web end point", a)
        if b is None:
            return
        paths.append([a, b])
    h = r["h"] / s
    made = 0
    for pts in paths:
        if len(pts) < 2:
            continue
        P = [_pl(p) for p in pts]
        k = (len(P) - 1) // 2
        mid = C.v_lerp(P[k], P[k + 1], 0.5)
        w0 = _web_dir(r["side"], _pt(mid), s)
        if w0 is None:
            w0 = [0.0, 0.0, 1.0]
            _say("no plate found under the base line - web direction set to +Z")
        exs = [C.v_unit(C.v_sub(P[i + 1], P[i])) for i in range(len(P) - 1)]
        wp = []
        for ex in exs:
            w = C.v_sub(w0, C.v_mul(ex, C.v_dot(w0, ex)))
            wp.append(C.v_unit(w, [0, 0, 1]))
        wv = []
        for i in range(len(P)):
            cand = [wp[j] for j in (i - 1, i) if 0 <= j < len(wp)]
            wv.append(C.v_unit([sum(c[k] for c in cand) for k in range(3)], wp[0]))
        T = [C.v_add(P[i], C.v_mul(wv[i], h)) for i in range(len(P))]
        for i in range(len(P) - 1):
            made += len(_add_planar([_pt(P[i]), _pt(P[i + 1]), _pt(T[i + 1]), _pt(T[i])], r["prop"], lib, st, "Web"))
        if r["top"].startswith("Face plate"):
            bw = r["fpw"] / s
            o1, o2 = {"Centred": (-bw / 2, bw / 2), "One side (+)": (0.0, bw), "One side (-)": (-bw, 0.0)}[r["fps"]]
            sp = [C.v_unit(C.v_cross(exs[i], wp[i])) for i in range(len(exs))]
            miter = []
            for i in range(len(P)):
                cand = [sp[j] for j in (i - 1, i) if 0 <= j < len(sp)]
                m = C.v_unit([sum(c[k] for c in cand) for k in range(3)], sp[0])
                ref = sp[min(i, len(sp) - 1)]
                d = C.v_dot(m, ref)
                miter.append(C.v_mul(m, 1.0 / d if abs(d) > 0.2 else 1.0))
            for i in range(len(P) - 1):
                q = [C.v_add(T[i], C.v_mul(miter[i], o1)), C.v_add(T[i + 1], C.v_mul(miter[i + 1], o1)),
                     C.v_add(T[i + 1], C.v_mul(miter[i + 1], o2)), C.v_add(T[i], C.v_mul(miter[i], o2))]
                made += len(_add_planar([_pt(x) for x in q], r["fpp"], lib, st, "Face plate"))
        elif r["top"].startswith("Edge") and r["esec"] in _names(lib, "sections"):
            gid = io.add_curve(rg.PolylineCurve([_pt(x) for x in T]))
            io.tag_profile(gid, lib, r["esec"], side="V", flange=1, offset="auto", role="Edge profile", orient=w0)
            _solids(lib, st, [io.find(gid)])
    _say("%d web / face plate(s) created" % made)
    _done()


# =========================================================================== profiles
def profile():
    lib, st = _start()
    if not _need(lib, "sections", "profile section"):
        return
    secs = _names(lib, "sections")
    r = ui.ask("AF_Profile - curves become profiles", [
        dict(key="sec", label="Section", kind="choice", choices=secs, value=st["active_section"]),
        dict(key="side", label="Web side", kind="choice", choices=C.WEB_SIDES, labels=C.WEB_SIDE_LABELS, value=st["web_side"]),
        dict(key="flange", label="Flange (L / HP / C)", kind="choice", choices=["+1", "-1"],
             value="+1" if int(st.get("flange", 1)) >= 0 else "-1"),
        dict(key="off", label="Offset mode", kind="choice", choices=["section default"] + C.OFFSET_MODES,
             labels=dict(C.OFFSET_LABELS, **{"section default": "section default (auto / pipe: centroid)"}), value="section default")],
        image="img_profile",
        intro="Select the lines / polylines / curves drawn ON the plating (the line is the toe of the profile), then "
              "Assign. +N / -N put the web at 90 deg to the plate, on the side the plate normal points to (see Rhino "
              "'Dir') or the other side. With 3D View on the profile is shown in 3D at once.",
        pick=_pick("Select curves...", "Select the curves that become profiles", rs.filter.curve, "curve(s)", _no_solid_filter))
    if not r:
        return
    ids = _ids_or_get(r, "Select profile curves (lines / polylines / curves on the plating)", rs.filter.curve, _no_solid_filter)
    if not ids:
        return
    off = None if r["off"] == "section default" else r["off"]
    for i in ids:
        io.tag_profile(i, lib, r["sec"], r["side"], int(r["flange"]), off, role="Profile")
    st.update(active_section=r["sec"], web_side=r["side"], flange=int(r["flange"]))
    io.save_settings(st)
    _solids(lib, st, [io.find(i) for i in ids])
    _say("%d profile(s) assigned %s" % (len(ids), r["sec"]))
    _done()


STF_DIRS = ["X", "Y", "Z", "Square to a plate edge (90 deg)", "Parallel to a plate edge", "Pick two points"]


def _pick_edge(prompt):
    """Direction (unit vector) of a clicked plate edge, or None."""
    go = Rhino.Input.Custom.GetObject()
    go.SetCommandPrompt(prompt)
    go.GeometryFilter = Rhino.DocObjects.ObjectType.EdgeFilter | Rhino.DocObjects.ObjectType.Curve
    go.SubObjectSelect = True
    go.EnablePreSelect(False, True)
    if go.Get() != Rhino.Input.GetResult.Object:
        return None
    ref = go.Object(0)
    crv = ref.Edge() or ref.Curve()
    if crv is None:
        return None
    pt = ref.SelectionPoint()
    if pt.IsValid:
        rc, t = crv.ClosestPoint(pt)
        tan = crv.TangentAt(t)
    else:
        tan = crv.PointAtEnd - crv.PointAtStart
    d = [tan.X, tan.Y, tan.Z]
    return C.v_unit(d) if C.v_len(d) > 1e-9 else None


def stiffeners():
    lib, st = _start()
    if not _need(lib, "sections", "profile section"):
        return
    secs = _names(lib, "sections")
    r = ui.ask("AF_Stiffeners - stiffeners across a plate", [
        dict(key="sec", label="Section", kind="choice", choices=secs, value=st["active_section"]),
        dict(key="side", label="Web side (90 deg to the plate)", kind="choice", choices=["+N", "-N"], labels=C.WEB_SIDE_LABELS,
             value=st.get("stf_side", "+N")),
        dict(key="flange", label="Flange (L / HP / C)", kind="choice", choices=["+1", "-1"], value="+1"),
        dict(key="dir", label="Stiffeners run along", kind="choice", choices=STF_DIRS,
             value=st.get("stf_dir", "X") if st.get("stf_dir", "X") in STF_DIRS else "X"),
        dict(key="mode", label="Placing", kind="choice", choices=["Spacing", "Count", "Positions"], value=st.get("stf_mode", "Spacing"),
             images={"Spacing": "img_stiffeners", "Count": "img_stiffeners_count", "Positions": "img_stiffeners_pos"}),
        dict(key="sp", label="Spacing [mm]", kind="float", value=st.get("stf_spacing", 600.0), min=1.0),
        dict(key="n", label="Count", kind="int", value=st.get("stf_count", 4), min=1),
        dict(key="a", label="Start offset from plate edge [mm]", kind="float", value=st.get("stf_start", 0.0), min=0.0),
        dict(key="b", label="End offset from plate edge [mm]", kind="float", value=st.get("stf_end", 0.0), min=0.0),
        dict(key="pos", label="Positions [mm] (global coordinate, comma separated)", kind="text", value=st.get("stf_positions", "")),
        dict(key="margin", label="End clearance (snipe) [mm]", kind="float", value=st.get("stf_margin", 0.0), min=0.0),
        dict(key="planes", label="Curved plates: section planes normal to", kind="choice", choices=["X", "Y", "Z"], value=st.get("stf_planes", "Z"))],
        image="img_stiffeners",
        intro="Select the plates, then Assign. The stiffener web always stands at 90 deg to the plate (also on curved "
              "plates). Stiffeners stop at the plate edges and are interrupted at openings. 'Square to a plate edge' / "
              "'Parallel to a plate edge': click the edge after Assign.",
        pick=_pick("Select plates...", "Select the plates to stiffen", SRF_FILTER, "plate(s)", _plate_filter))
    if not r:
        return
    st.update(stf_side=r["side"], stf_dir=r["dir"], stf_mode=r["mode"], stf_spacing=r["sp"], stf_count=r["n"], stf_start=r["a"],
              stf_end=r["b"], stf_positions=r["pos"], stf_margin=r["margin"], stf_planes=r["planes"], active_section=r["sec"])
    io.save_settings(st)
    ids = _ids_or_get(r, "Select the plates to stiffen", SRF_FILTER, _plate_filter)
    if not ids:
        return
    s = io.scale()
    t = io.tol()
    dvec = None
    edge_mode = None
    if r["dir"] in ("Square to a plate edge (90 deg)", "Parallel to a plate edge"):
        e = _pick_edge("Click the plate edge the stiffeners are %s" % ("square to" if r["dir"].startswith("Square") else "parallel to"))
        if e is None:
            return
        dvec = e
        edge_mode = "square" if r["dir"].startswith("Square") else "parallel"
    elif r["dir"] == "Pick two points":
        a = rs.GetPoint("Direction - first point")
        b = rs.GetPoint("Direction - second point", a) if a else None
        if a is None or b is None:
            return
        dvec = C.v_unit(C.v_sub(_pl(b), _pl(a)))
    elif dvec is None:
        dvec = list(C.AXES["+" + r["dir"]])
    positions = []
    if r["mode"] == "Positions":
        for x in r["pos"].replace(";", ",").split(","):
            v = ui.to_float(x)
            if v is not None:
                positions.append(v / s)
        if not positions:
            ui.message("Enter the positions, e.g. 600, 1200, 1800")
            return
    made = 0
    new_ids = []
    for oid in ids:
        obj = io.member_obj(oid)
        for face in io.plate_faces(obj):
            fb = face.DuplicateFace(False)
            if face.IsPlanar(t):
                outer, holes, n = io.planar_face_data(face, 1.0, float(st.get("chord_tol", 1.0)) / s, t)
                dv = C.v_cross(n, dvec) if edge_mode == "square" else dvec    # square (90 deg) to the edge, in the plate
                d = C.v_sub(dv, C.v_mul(n, C.v_dot(dv, n)))
                if C.v_len(d) < 1e-6:
                    _say("direction is normal to a plate - skipped")
                    continue
                d = C.v_unit(d)
                perp = C.v_unit(C.v_cross(n, d))
            else:
                perp = list(C.AXES["+" + r["planes"]])
                bb = fb.GetBoundingBox(True)
                outer = [_pl(bb.Min), _pl(bb.Max)]
            o = outer[0]
            proj = [C.v_dot(C.v_sub(p, o), perp) for p in outer]
            smin, smax = min(proj), max(proj)
            if r["mode"] == "Positions":
                ax = C.argmax_abs(perp)
                offs = [(v - o[ax]) / perp[ax] for v in positions]
            else:
                s0 = smin + r["a"] / s
                s1 = smax - r["b"] / s
                if r["mode"] == "Count":
                    stp = (s1 - s0) / (r["n"] + 1)
                    offs = [s0 + stp * (k + 1) for k in range(r["n"])]
                else:
                    stp = r["sp"] / s
                    offs = []
                    x = s0 + stp
                    while x < s1 - 1e-6:
                        offs.append(x)
                        x += stp
            for off in offs:
                pl = rg.Plane(_pt(C.v_add(o, C.v_mul(perp, off))), rg.Vector3d(perp[0], perp[1], perp[2]))
                rc, crvs, pts = rg.Intersect.Intersection.BrepPlane(fb, pl, t)
                if not rc or not crvs:
                    continue
                for crv in rg.Curve.JoinCurves(crvs, t) or crvs:
                    L = crv.GetLength()
                    m = r["margin"] / s
                    if m > 0 and L > 2 * m + t:
                        rc0, t0 = crv.LengthParameter(m)
                        rc1, t1 = crv.LengthParameter(L - m)
                        if rc0 and rc1:
                            crv = crv.Trim(t0, t1) or crv
                    if crv.GetLength() < 10 * t:
                        continue
                    if crv.IsLinear(t):
                        crv = rg.LineCurve(crv.PointAtStart, crv.PointAtEnd)
                    gid = io.add_curve(crv)
                    io.tag_profile(gid, lib, r["sec"], r["side"], int(r["flange"]), None, role="Stiffener", name="STF")
                    new_ids.append(gid)
                    made += 1
    _say("%d stiffener(s) created (%s)" % (made, r["sec"]))
    _solids(lib, st, [io.find(i) for i in new_ids])
    _done()


# =========================================================================== bracket / face plate / opening
def _pick_member(prompt, exclude=None):
    """Click a profile (curve) or a plate (surface). Returns dict for core.bracket_corner (mm) + info, or None."""
    go = Rhino.Input.Custom.GetObject()
    go.SetCommandPrompt(prompt)
    go.GeometryFilter = (Rhino.DocObjects.ObjectType.Curve | Rhino.DocObjects.ObjectType.Surface |
                         Rhino.DocObjects.ObjectType.PolysrfFilter | Rhino.DocObjects.ObjectType.Extrusion)
    go.SubObjectSelect = True
    go.EnablePreSelect(False, True)
    go.DeselectAllBeforePostSelect = True
    go.AcceptNothing(True)
    if go.Get() != Rhino.Input.GetResult.Object:
        return None
    ref = go.Object(0)
    obj = ref.Object()
    if obj is None:
        return None
    m = io.member_obj(obj.Id) or obj
    s = io.scale()
    pick = ref.SelectionPoint()
    has_pick = pick.IsValid
    geo = m.Geometry
    if isinstance(geo, rg.Curve):
        crv = geo
        if not has_pick:
            pick = crv.PointAt(crv.Domain.Mid)
        if crv.IsLinear(io.tol()):
            a, b = crv.PointAtStart, crv.PointAtEnd
        else:
            rc, t = crv.ClosestPoint(pick)
            p = crv.PointAt(t)
            tan = crv.TangentAt(t)
            L = crv.GetLength()
            a, b = p - tan * L, p + tan * L
        web, height = None, 0.0
        if io.is_profile(m):
            mid = crv.PointAt(crv.Domain.Mid)
            side = io.af(m, io.K_SIDE, "+N")
            if side == "V":
                try:
                    web = [float(x) for x in io.af(m, io.K_ORIENT, "0,0,1").split(",")]
                except ValueError:
                    web = None
            else:
                web = _web_dir(side, mid, s)
            sec = C.library_index(io.load_library())[2].get(io.af(m, io.K_SEC))
            if sec:
                height = C.section_height(sec["stype"], sec["dims"])
        return dict(kind="profile", a=io.P2L(a, s), b=io.P2L(b, s), web=web, pick=io.P2L(pick, s) if has_pick else None,
                    height=height, id=m.Id)
    brep = io.brep_of(geo)
    if brep is None:
        return None
    face = ref.Face()
    if face is None:
        face = brep.Faces[0]
        if brep.Faces.Count > 1 and has_pick:
            best = 1e30
            for i in range(brep.Faces.Count):
                f = brep.Faces[i]
                rc, u, v = f.ClosestPoint(pick)
                if rc and f.PointAt(u, v).DistanceTo(pick) < best:
                    best, face = f.PointAt(u, v).DistanceTo(pick), f
    if not has_pick:
        amp = rg.AreaMassProperties.Compute(face.DuplicateFace(False))
        pick = amp.Centroid if amp else face.PointAt(face.Domain(0).Mid, face.Domain(1).Mid)
    rc, u, v = face.ClosestPoint(pick)
    o = face.PointAt(u, v)
    n = io.face_normal(face, o)
    return dict(kind="plate", o=io.P2L(o, s), n=list(n), pick=io.P2L(o, s), height=0.0, id=m.Id)


def _make_bracket(C0, u1, u2, r, lib, st, s):
    """Bracket plate (+ face plate) from a corner and two leg directions (mm)."""
    a, b, toe = r["a_mm"], r["b_mm"], r["toe"]
    poly, Ap, Bp, n = C.bracket_polygon(C0, u1, u2, a, b, toe)
    pts = [io.L2P(p, s) for p in poly]
    bs = rg.Brep.CreatePlanarBreps([rg.PolylineCurve(pts + [pts[0]])], io.tol())
    made = 0
    if bs:
        io.add_plate(bs[0], r["prop"], lib, st, role="Bracket")
        made = 1
    if r["edge"].startswith("Face"):
        w = r["fpw"] / 2.0
        q = [C.v_sub(Ap, C.v_mul(n, w)), C.v_sub(Bp, C.v_mul(n, w)), C.v_add(Bp, C.v_mul(n, w)), C.v_add(Ap, C.v_mul(n, w))]
        _add_planar([io.L2P(x, s) for x in q], r["fpp"], lib, st, "Face plate")
    return made


def bracket():
    lib, st = _start()
    if not _need(lib, "plate_props", "plate property"):
        return
    props = _names(lib, "plate_props")
    methods = ["Click two members", "Pick corner + 2 points"]
    r = ui.ask("AF_Bracket - bracket plate", [
        dict(key="method", label="Method", kind="choice", choices=methods, value=st.get("bkt_method", methods[0]),
             images={methods[0]: "img_bracket_auto", methods[1]: "img_bracket"}),
        dict(key="auto", label="Auto arm length (2 x deepest profile, min 150)", kind="bool", value=bool(st.get("bkt_auto", False))),
        dict(key="a", label="Leg a [mm] (0 = to the picked point)", kind="float", value=st.get("bkt_a", 400.0), min=0.0),
        dict(key="b", label="Leg b [mm] (0 = to the picked point)", kind="float", value=st.get("bkt_b", 400.0), min=0.0),
        dict(key="toe", label="Toe (nose) height [mm]", kind="float", value=st.get("bkt_toe", 20.0), min=0.0),
        dict(key="prop", label="Bracket property", kind="choice", choices=props, value=st.get("bkt_prop") or st["active_prop"]),
        dict(key="edge", label="Free edge", kind="choice", choices=["None", "Face plate (shell)"], value=st.get("bkt_edge", "None"),
             images={"None": "img_bracket", "Face plate (shell)": "img_bracket_fp"}),
        dict(key="fpw", label="Face plate width [mm]", kind="float", value=st.get("bkt_fp_width", 100.0), min=1.0),
        dict(key="fpp", label="Face plate property", kind="choice", choices=props, value=st.get("fp_prop") or st["active_prop"])],
        image="img_bracket_auto",
        intro="Click two members: the bracket is made at once where they meet. Profile + plate: in the web plane of the "
              "profile, on its web side. Profile + profile: in the plane of both. Plate + plate: square to their "
              "intersection, at the point you clicked on the first plate. Repeat for more brackets, Enter to finish.")
    if not r:
        return
    st.update(bkt_method=r["method"], bkt_auto=bool(r["auto"]), bkt_a=r["a"], bkt_b=r["b"], bkt_toe=r["toe"],
              bkt_prop=r["prop"], bkt_edge=r["edge"], bkt_fp_width=r["fpw"], fp_prop=r["fpp"])
    io.save_settings(st)
    s = io.scale()
    made = 0
    if r["method"] == methods[0]:
        while True:
            m1 = _pick_member("Bracket %d: click the FIRST member - profile or plate (Enter = finish)" % (made + 1))
            if m1 is None:
                break
            m2 = _pick_member("Bracket %d: click the SECOND member" % (made + 1))
            if m2 is None:
                break
            if m1["id"] == m2["id"] and m1["kind"] == "profile":
                _say("pick two different members")
                continue
            hmax = max(m1.get("height", 0.0), m2.get("height", 0.0))
            res = C.bracket_corner(m1, m2, tol=max(io.tol() * s, 0.01), max_gap=max(50.0, hmax))
            if isinstance(res, str):
                _say(res)
                continue
            C0, u1, u2 = res
            if r["auto"]:
                leg = C.bracket_auto_leg([m1.get("height", 0.0), m2.get("height", 0.0)])
                a_mm = b_mm = leg
            else:
                a_mm = r["a"] if r["a"] > 0 else 400.0
                b_mm = r["b"] if r["b"] > 0 else 400.0
            made += _make_bracket(C0, u1, u2, dict(r, a_mm=a_mm, b_mm=b_mm), lib, st, s)
            _say("bracket %d: arms %g x %g mm at (%.0f, %.0f, %.0f)" % (made, a_mm, b_mm, C0[0], C0[1], C0[2]))
            sc.doc.Views.Redraw()
    else:
        while True:
            c = rs.GetPoint("Bracket corner (Enter to finish)")
            if c is None:
                break
            p1 = rs.GetPoint("Point along leg a", c)
            if p1 is None:
                break
            p2 = rs.GetPoint("Point along leg b", c)
            if p2 is None:
                break
            C0, A0, B0 = io.P2L(c, s), io.P2L(p1, s), io.P2L(p2, s)
            d1 = C.v_unit(C.v_sub(A0, C0))
            d2 = C.v_unit(C.v_sub(B0, C0))
            if C.v_len(C.v_cross(d1, d2)) < 1e-9:
                ui.message("The three points are in line.")
                continue
            a_mm = r["a"] if r["a"] > 0 else C.v_dist(A0, C0)
            b_mm = r["b"] if r["b"] > 0 else C.v_dist(B0, C0)
            made += _make_bracket(C0, d1, d2, dict(r, a_mm=a_mm, b_mm=b_mm), lib, st, s)
            sc.doc.Views.Redraw()
    _say("%d bracket(s) made" % made)
    _done()


def _host_plate(crv):
    """The AF plate a curve lies on (free edge of a web / bracket) and the plate normal at its middle."""
    s = io.scale()
    tol_mu = max(io.tol() * 10, 2.0 / s)
    mid = crv.PointAt(crv.Domain.Mid)
    test = [crv.PointAtStart, mid, crv.PointAtEnd]
    best = None
    for obj in io.af_objects("plate"):
        b = io.brep_of(obj.Geometry)
        if b is None:
            continue
        bb = b.GetBoundingBox(False)
        if bb.ClosestPoint(mid).DistanceTo(mid) > tol_mu:
            continue
        d = max(b.ClosestPoint(p).DistanceTo(p) for p in test)
        if d <= tol_mu and (best is None or d < best[0]):
            best = (d, obj, b)
    if best is None:
        return None, None
    b = best[2]
    cp = b.ClosestPoint(mid)
    fi, fbest = 0, 1e30
    for i in range(b.Faces.Count):
        rc, u, v = b.Faces[i].ClosestPoint(cp)
        if rc and b.Faces[i].PointAt(u, v).DistanceTo(cp) < fbest:
            fi, fbest = i, b.Faces[i].PointAt(u, v).DistanceTo(cp)
    return best[1], io.face_normal(b.Faces[fi], cp)


def _face_plates_from(ids, r, lib, st):
    """Face plates from free-edge curves (strip of width bf square to the web) and from existing surfaces."""
    s = io.scale()
    n_c = n_s = n_skip = 0
    srf = []
    for oid in ids:
        obj = io.find(oid)
        if obj is None:
            continue
        g = obj.Geometry
        if not isinstance(g, rg.Curve):
            srf.append(oid)
            continue
        host, n = _host_plate(g)
        if host is None:
            n_skip += 1
            _say("curve %s is not on a web / bracket plate - skipped" % str(oid)[:8])
            continue
        w = r["w"] / s
        o1, o2 = {"Centred": (-w / 2, w / 2), "One side (+)": (0.0, w), "One side (-)": (-w, 0.0)}[r["side"]]
        if g.IsLinear(io.tol()):
            A, B = _pl(g.PointAtStart), _pl(g.PointAtEnd)
            q = [C.v_add(A, C.v_mul(n, o1)), C.v_add(B, C.v_mul(n, o1)), C.v_add(B, C.v_mul(n, o2)), C.v_add(A, C.v_mul(n, o2))]
            if _add_planar([_pt(x) for x in q], r["prop"], lib, st, "Face plate"):
                n_c += 1
        else:
            base = g.DuplicateCurve()
            base.Translate(rg.Vector3d(n[0] * o1, n[1] * o1, n[2] * o1))
            ext = rg.Surface.CreateExtrusion(base, rg.Vector3d(n[0] * (o2 - o1), n[1] * (o2 - o1), n[2] * (o2 - o1)))
            br = rg.Brep.CreateFromSurface(ext) if ext is not None else None
            if br is not None:
                io.add_plate(br, r["prop"], lib, st, role="Face plate")
                n_c += 1
    if srf:
        n_s = _surfaces_to_plates(srf, r["prop"], "Face plate", lib, st)[0]
    _say("face plates: %d from free-edge curves, %d from surfaces%s" % (n_c, n_s, (", %d curve(s) skipped" % n_skip) if n_skip else ""))
    _done()


def face_plate():
    lib, st = _start()
    if not _need(lib, "plate_props", "plate property"):
        return
    props = _names(lib, "plate_props")
    r = ui.ask("AF_FacePlate - face plate on a free edge", [
        dict(key="w", label="Face plate width bf [mm]", kind="float", value=st.get("fp_width", 150.0), min=1.0),
        dict(key="prop", label="Face plate property", kind="choice", choices=props, value=st.get("fp_prop") or st["active_prop"]),
        dict(key="side", label="Position", kind="choice", choices=["Centred", "One side (+)", "One side (-)"], value=st.get("fp_side", "Centred"))],
        image="img_faceplate",
        intro="Select the FREE-EDGE CURVES of webs / brackets (a face plate of width bf is built on each, square to its "
              "web) and / or SURFACES that are face plates already, then Assign. Nothing selected: pick the web and the "
              "two ends of its free edge.",
        pick=_pick("Select curves / surfaces...", "Select free-edge curves and / or face plate surfaces",
                   rs.filter.curve | SRF_FILTER, "object(s)", _no_solid_filter))
    if not r:
        return
    st.update(fp_width=r["w"], fp_prop=r["prop"], fp_side=r["side"])
    io.save_settings(st)
    if r.get("_ids"):
        _face_plates_from(r["_ids"], r, lib, st)
        return
    oid = rs.GetObject("Select the web or bracket", SRF_FILTER, preselect=True, custom_filter=_plate_filter)
    if not oid:
        return
    a = rs.GetPoint("Free edge - start point")
    b = rs.GetPoint("Free edge - end point", a) if a else None
    if a is None or b is None:
        return
    s = io.scale()
    obj = io.member_obj(oid)
    face = io.plate_faces(obj)[0]
    mid = rg.Point3d((a.X + b.X) / 2.0, (a.Y + b.Y) / 2.0, (a.Z + b.Z) / 2.0)
    n = io.face_normal(face, mid)
    w = r["w"] / s
    o1, o2 = {"Centred": (-w / 2, w / 2), "One side (+)": (0.0, w), "One side (-)": (-w, 0.0)}[r["side"]]
    A, B = _pl(a), _pl(b)
    q = [C.v_add(A, C.v_mul(n, o1)), C.v_add(B, C.v_mul(n, o1)), C.v_add(B, C.v_mul(n, o2)), C.v_add(A, C.v_mul(n, o2))]
    _add_planar([_pt(x) for x in q], r["prop"], lib, st, "Face plate")
    _done()


OPENING_KINDS = ["Slot / manhole", "Rectangle", "Circle", "Closed curves"]
OPENING_PLACES = ["Pick the centre on each plate", "Centre of each selected plate"]


def _plate_centre(obj):
    """Area centroid of a plate, put back onto its surface."""
    if obj is None:
        return None
    fb = io.plate_faces(obj)[0].DuplicateFace(False)
    amp = rg.AreaMassProperties.Compute(fb)
    if amp is None:
        return None
    return fb.ClosestPoint(amp.Centroid)


def _centre_points(oid, fixed, k, n):
    if fixed:
        for c in fixed:
            yield c
        return
    while True:
        c = rs.GetPointOnSurface(oid, "Plate %d of %d: centre of the opening (Enter = next plate)" % (k + 1, n))
        if c is None:
            return
        yield c


def _opening_curve(kind, centre, u, v, a, b, rr, ang):
    k = {"Slot / manhole": "slot", "Rectangle": "rect", "Circle": "circle"}[kind]
    segs = C.opening_segments(k, (0.0, 0.0), a, b, rr, ang)

    def P(q):
        return _pt(C.v_add(C.v_add(centre, C.v_mul(u, q[0])), C.v_mul(v, q[1])))
    parts = []
    for sg in segs:
        if sg[0] == "L":
            if C.dist2d(sg[1], sg[2]) > 1e-9:
                parts.append(rg.LineCurve(P(sg[1]), P(sg[2])))
        else:
            p0, c, p1 = sg[1], sg[2], sg[3]
            rad = C.dist2d(p0, c)
            a0 = math.atan2(p0[1] - c[1], p0[0] - c[0])
            a1 = math.atan2(p1[1] - c[1], p1[0] - c[0])
            da = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi
            m = (c[0] + rad * math.cos(a0 + da / 2), c[1] + rad * math.sin(a0 + da / 2))
            parts.append(rg.ArcCurve(rg.Arc(P(p0), P(m), P(p1))))
    j = rg.Curve.JoinCurves(parts, io.tol())
    return j[0] if j else None


def _cut_hole(obj, hole):
    """Cut the closed curve 'hole' into the plate object. Returns True on success."""
    t = io.tol()
    b = io.brep_of(obj.Geometry)
    face = b.Faces[0]
    if face.IsPlanar(t):
        loops = [face.Loops[i].To3dCurve() for i in range(face.Loops.Count)]
        nb = rg.Brep.CreatePlanarBreps(loops + [hole], t)
        if not nb or nb[0].Faces[0].Loops.Count <= face.Loops.Count:
            return False
        return sc.doc.Objects.Replace(obj.Id, nb[0])
    mid = hole.PointAt(hole.Domain.Mid)
    n = io.face_normal(face, mid)
    proj = rg.Curve.ProjectToBrep(hole, b, rg.Vector3d(n[0], n[1], n[2]), t)
    if not proj:
        return False
    sp = face.Split(proj, t)
    if sp is None or sp.Faces.Count < 2:
        return False
    best, area = None, -1.0
    for i in range(sp.Faces.Count):
        f = sp.Faces[i].DuplicateFace(False)
        amp = rg.AreaMassProperties.Compute(f)
        if amp and amp.Area > area:
            best, area = f, amp.Area
    return sc.doc.Objects.Replace(obj.Id, best) if best is not None else False


def opening():
    lib, st = _start()
    r = ui.ask("AF_Opening - opening in a plate", [
        dict(key="kind", label="Opening type", kind="choice", choices=OPENING_KINDS, value=st.get("op_kind", OPENING_KINDS[0]),
             images={"Slot / manhole": "img_opening_slot", "Rectangle": "img_opening_rect", "Circle": "img_opening_circle",
                     "Closed curves": "img_opening_curve"}),
        dict(key="a", label="Length L / diameter D [mm]", kind="float", value=st.get("op_a", 600.0), min=1.0),
        dict(key="b", label="Height H [mm]", kind="float", value=st.get("op_b", 400.0), min=1.0),
        dict(key="r", label="Corner radius r [mm] (rectangle)", kind="float", value=st.get("op_r", 0.0), min=0.0),
        dict(key="ang", label="Rotation in the plate [deg]", kind="float", value=st.get("op_angle", 0.0)),
        dict(key="where", label="Position", kind="choice", choices=OPENING_PLACES, value=st.get("op_where", OPENING_PLACES[0]))],
        image="img_opening_slot",
        intro="Select the plates / webs, then Assign. 'Pick the centre' asks for the centre on each plate (repeat, Enter "
              "= next plate); 'Centre of each plate' cuts the same opening in all selected plates at once. L runs along "
              "the plate u-axis (X for decks and longitudinal plates, Y for transverse plates) - as in ALIEF FEAPRO.",
        pick=_pick("Select plates / webs...", "Select the plates / webs that get the opening", SRF_FILTER, "plate(s)",
                   _plate_filter))
    if not r:
        return
    st.update(op_kind=r["kind"], op_a=r["a"], op_b=r["b"], op_r=r["r"], op_angle=r["ang"], op_where=r["where"])
    io.save_settings(st)
    picked = _ids_or_get(r, "Select the plates / webs", SRF_FILTER, _plate_filter)
    plates, seen = [], set()
    for i in picked:
        m = io.member_obj(i)
        if m is not None and str(m.Id) not in seen:
            seen.add(str(m.Id))
            plates.append(m.Id)
    if not plates:
        return
    s = io.scale()
    t = io.tol()
    n_ok = 0
    if r["kind"] == "Closed curves":
        ids = rs.GetObjects("Select closed curves lying on the plates", rs.filter.curve)
        for i in ids or []:
            crv = rs.coercecurve(i)
            if crv is None or not crv.IsClosed:
                continue
            for oid in plates:
                if _cut_hole(io.find(oid), crv):
                    n_ok += 1
                    break
    else:
        for k, oid in enumerate(plates):
            fixed = []
            if r["where"] == OPENING_PLACES[1]:
                c0 = _plate_centre(io.find(oid))
                if c0 is not None:
                    fixed = [c0]
            for c in _centre_points(oid, fixed, k, len(plates)):
                obj = io.find(oid)
                face = io.plate_faces(obj)[0]
                if face.IsPlanar(t):
                    outer, holes, nrm = io.planar_face_data(face, 1.0, 1.0 / s, t)
                    fr = C.plate_frame(outer)
                    u, v = fr[1], fr[2]
                else:
                    nrm = io.face_normal(face, c)
                    ax = C.argmax_abs(nrm)
                    u0 = [0.0, 1.0, 0.0] if ax == 0 else [1.0, 0.0, 0.0]
                    u = C.v_unit(C.v_sub(u0, C.v_mul(nrm, C.v_dot(u0, nrm))))
                    v = C.v_cross(nrm, u)
                hole = _opening_curve(r["kind"], _pl(c), u, v, r["a"] / s, (r["a"] if r["kind"] == "Circle" else r["b"]) / s,
                                      r["r"] / s, r["ang"])
                if hole is not None and _cut_hole(obj, hole):
                    n_ok += 1
                    sc.doc.Views.Redraw()
                else:
                    _say("opening could not be cut (does it lie inside the plate?)")
    _say("%d opening(s) cut" % n_ok)
    if n_ok:
        _solids(lib, st, None)
    _done()


# =========================================================================== assign / edit
ASSIGN_KEY = "ALIEF_FEA_ASSIGN"
ASSIGN_METHODS = ["Assign To Selected", "Use Cursor To Assign", "Assign To Layer", "Assign To View"]


def assign():
    """STAAD-style property window: choose a plate property or a section, then assign it to many objects."""
    _start()
    ui.show_assign()


def _assign_ids(ids, req, lib, st):
    """Give the property / section of 'req' to objects: closed curves / surfaces -> plates, curves -> profiles,
    existing members -> new property. Returns (plates, profiles, skipped, new ids)."""
    kind, name = req["kind"], req["name"]
    n_pl = n_pr = n_skip = 0
    new = []
    done = set()
    curves, curve_ids = [], []
    for oid in ids:
        obj = io.member_obj(oid)
        if obj is None or str(obj.Id) in done:
            continue
        done.add(str(obj.Id))
        if obj.Attributes.GetUserString("AF_SYNC_ZONE") or _locked(obj):
            n_skip += 1              # a team member's zone (locked reference) or a locked object / layer
            continue
        g = obj.Geometry
        if kind == "plate":
            if isinstance(g, rg.Curve):
                if not io.is_profile(obj) and g.IsClosed and g.IsPlanar(io.tol()):
                    curves.append(g)
                    curve_ids.append(obj.Id)
                else:
                    n_skip += 1
                continue
            b = io.brep_of(g)
            if b is None:
                n_skip += 1
                continue
            if io.is_plate(obj) or (b.Faces.Count == 1 and isinstance(g, rg.Brep)):
                role = None if io.is_plate(obj) and not req.get("set_role") else req.get("role", "Plate")
                io.tag_plate(obj.Id, lib, name, role)
                n_pl += 1
            elif b.IsSolid and not req.get("solids", False):
                n_skip += 1          # closed solids (machinery, blocks ...) are not exploded into plates
            else:
                for i in range(b.Faces.Count):
                    new.append(io.add_plate(b.Faces[i].DuplicateFace(False), name, lib, st, name=obj.Attributes.Name or "",
                                            role=req.get("role", "Plate"), layer_index=obj.Attributes.LayerIndex))
                    n_pl += 1
                io.delete_objects([obj])
        else:
            if not isinstance(g, rg.Curve):
                n_skip += 1
                continue
            off = None if req.get("offset", "auto") in ("section default", None) else req["offset"]
            if io.is_profile(obj) and not req.get("apply_side"):
                io.set_af(obj, {io.K_SEC: name}, color=io.section_color(lib, name))
            else:
                io.tag_profile(obj.Id, lib, name, req.get("side", "+N"), int(req.get("flange", 1)), off,
                               role=io.af(obj, io.K_ROLE, req.get("role_p", "Profile")) if io.is_profile(obj) else "Profile")
            n_pr += 1
    if curves:
        breps = rg.Brep.CreatePlanarBreps(curves, io.tol()) or []
        for b in breps:
            for i in range(b.Faces.Count):
                new.append(io.add_plate(b.Faces[i].DuplicateFace(False), name, lib, st, role=req.get("role", "Plate")))
                n_pl += 1
        if breps and not req.get("keep", True):
            io.delete_objects([io.find(i) for i in curve_ids])
        if not breps:
            n_skip += len(curves)
    return n_pl, n_pr, n_skip, new


def _locked(obj):
    try:
        if obj.Attributes.Mode == Rhino.DocObjects.ObjectMode.Locked:
            return True
        return bool(sc.doc.Layers[obj.Attributes.LayerIndex].IsLocked)
    except Exception:
        return False


def assign_now():
    """Runs the assignment prepared in the Assign window (a normal Rhino command, so Undo works)."""
    lib, st = _start()
    req = sc.sticky.get(ASSIGN_KEY)
    if not req:
        req = dict(kind="plate" if st["active_prop"] else "profile", name=st["active_prop"], method=ASSIGN_METHODS[0])
    names = _names(lib, "plate_props" if req["kind"] == "plate" else "sections")
    if req["name"] not in names:
        ui.message("'%s' is not in the library any more." % req["name"])
        return
    flt = (rs.filter.curve | SRF_FILTER) if req["kind"] == "plate" else rs.filter.curve
    what = "closed curves / surfaces / plates" if req["kind"] == "plate" else "lines / curves / profiles"
    method = req.get("method", ASSIGN_METHODS[0])
    tot = [0, 0, 0]

    def run(ids):
        r = _assign_ids(ids, req, lib, st)
        for k in range(3):
            tot[k] += r[k]
        sc.doc.Views.Redraw()
    if method == "Use Cursor To Assign":
        while True:
            oid = rs.GetObject("Click %s to get %s (Enter = finish)" % (what, req["name"]), flt, preselect=False, select=False,
                               custom_filter=_no_solid_filter)
            if not oid:
                break
            run([oid])
    elif method == "Assign To Layer":
        lay = req.get("layer") or ""
        ids = [i for i in (rs.ObjectsByLayer(lay) or []) if rs.ObjectType(i) & flt] if lay else []
        if not ids:
            ui.message("Nothing to assign on layer '%s'." % lay)
            return
        run(ids)
    elif method == "Assign To View":
        ids = [i for i in (rs.NormalObjects() or []) if rs.ObjectType(i) & flt]
        ids = [i for i in ids if not (io.find(i) and io.find(i).Attributes.GetUserString(io.K_PREVIEW))]
        if not ids:
            ui.message("No visible %s." % what)
            return
        if rs.MessageBox("Assign %s to ALL %d visible %s?\n\nClosed solids and locked objects are skipped; "
                         "open polysurfaces are split into one plate per face." % (req["name"], len(ids), what), 4 | 32, "AF_Assign") != 6:
            return
        run(ids)
    else:
        ids = rs.SelectedObjects() or []
        if not ids:
            ids = rs.GetObjects("Select %s for %s" % (what, req["name"]), flt, preselect=True, custom_filter=_no_solid_filter)
        if not ids:
            return
        run(ids)
    if req["kind"] == "plate":
        st["active_prop"] = req["name"]
    else:
        st.update(active_section=req["name"], web_side=req.get("side", st["web_side"]), flange=int(req.get("flange", 1)))
    io.save_settings(st)
    _say("Assigned %s: %d plate(s), %d profile(s)%s" % (req["name"], tot[0], tot[1],
                                                       ("  (%d object(s) skipped - wrong type / team zone)" % tot[2]) if tot[2] else ""))
    _done()


_FLIP = {"+N": "-N", "-N": "+N", "+X": "-X", "-X": "+X", "+Y": "-Y", "-Y": "+Y", "+Z": "-Z", "-Z": "+Z"}


def flip_side():
    lib, st = _start()
    ids = rs.GetObjects("Select profiles (curve or 3D profile) to flip the web side", rs.filter.curve | SRF_FILTER,
                        preselect=True, custom_filter=_profile_filter)
    objs = _members(ids)
    for obj in objs:
        sd = io.af(obj, io.K_SIDE, "+N")
        if sd == "V":
            v = [float(x) for x in io.af(obj, io.K_ORIENT, "0,0,1").split(",")]
            io.set_af(obj, {io.K_ORIENT: "%.9g,%.9g,%.9g" % (-v[0], -v[1], -v[2])})
        else:
            io.set_af(obj, {io.K_SIDE: _FLIP.get(sd, "-N")})
    _say("%d profile(s) flipped" % len(objs))
    _solids(lib, st, [io.find(o.Id) for o in objs])
    _done()


def flip_flange():
    lib, st = _start()
    ids = rs.GetObjects("Select profiles (curve or 3D profile) to mirror the flange", rs.filter.curve | SRF_FILTER,
                        preselect=True, custom_filter=_profile_filter)
    objs = _members(ids)
    for obj in objs:
        f = int(float(io.af(obj, io.K_FLANGE, "1")))
        io.set_af(obj, {io.K_FLANGE: -1 if f >= 0 else 1})
    _say("%d profile(s) mirrored" % len(objs))
    _solids(lib, st, [io.find(o.Id) for o in objs])
    _done()


def info():
    lib, st = _start()
    ids = rs.GetObjects("Select FEA members", rs.filter.curve | SRF_FILTER, preselect=True, custom_filter=_member_filter)
    if not ids:
        return
    objs = _members(ids)
    plates = [o for o in objs if io.is_plate(o)]
    profs = [o for o in objs if io.is_profile(o)]
    mats, props, secs = C.library_index(lib)
    fields, lines = [], []
    if plates:
        o = plates[0]
        pp = props.get(io.af(o, io.K_PROP), {})
        b = io.brep_of(o.Geometry)
        amp = rg.AreaMassProperties.Compute(b) if b else None
        area = (amp.Area if amp else 0) * io.scale() ** 2 * 1e-6
        lines.append("PLATE: %s | %s | t = %s mm | %s | area %.3f m2 | %s" % (
            o.Attributes.Name or "-", io.af(o, io.K_PROP), pp.get("thickness", "?"), pp.get("material", "?"), area,
            "planar" if b and b.Faces[0].IsPlanar(io.tol()) else "curved (facets on export)"))
        plist = list(props) or ["-"]
        fields += [dict(key="prop", label="Plate property", kind="choice", choices=plist, value=io.af(o, io.K_PROP)),
                   dict(key="mesh", label="Local mesh size [mm] (0 = global)", kind="float", value=float(io.af(o, io.K_MESH, "0") or 0), min=0.0)]
    if profs:
        o = profs[0]
        sname = io.af(o, io.K_SEC)
        sd = io.af(o, io.K_SIDE, "+N")
        s_ = secs.get(sname)
        L = o.Geometry.GetLength() * io.scale() if isinstance(o.Geometry, rg.Curve) else 0.0
        lines.append("PROFILE: %s | %s (%s) | web %s | flange %s | offset %s | length %.0f mm" % (
            o.Attributes.Name or "-", sname, s_["material"] if s_ else "?", sd, io.af(o, io.K_FLANGE, "1"), io.af(o, io.K_OFFSET, "auto"), L))
        slist = list(secs) or ["-"]
        sides = C.WEB_SIDES + (["V"] if sd == "V" else [])
        fields += [dict(key="sec", label="Section", kind="choice", choices=slist, value=sname),
                   dict(key="side", label="Web side", kind="choice", choices=sides, labels=dict(C.WEB_SIDE_LABELS, V="vector (%s)" % io.af(o, io.K_ORIENT)), value=sd),
                   dict(key="flange", label="Flange", kind="choice", choices=["+1", "-1"], value="+1" if int(float(io.af(o, io.K_FLANGE, "1"))) >= 0 else "-1"),
                   dict(key="off", label="Offset mode", kind="choice", choices=C.OFFSET_MODES, labels=C.OFFSET_LABELS, value=io.af(o, io.K_OFFSET, "auto"))]
    fields.append(dict(key="name", label="Name (blank = keep)", kind="text",
                       value=(objs[0].Attributes.Name or "") if len(objs) == 1 else ""))
    intro = "\n".join(lines) + ("\n%d plate(s), %d profile(s) selected - the values are applied to all of them." % (len(plates), len(profs))
                                if len(objs) > 1 else "")
    r = ui.ask("AF_Info - FEA data", fields, intro=intro, ok_text="Apply")
    if not r:
        return
    nm = r.get("name", "").strip() or None
    for o in plates:
        if r["prop"] in props:
            io.set_af(o, {io.K_PROP: r["prop"], io.K_MESH: ("%g" % r["mesh"]) if r["mesh"] else None},
                      color=io.plate_color(lib, r["prop"]), name=nm)
    for o in profs:
        if r["sec"] in secs:
            io.set_af(o, {io.K_SEC: r["sec"], io.K_SIDE: r["side"], io.K_FLANGE: int(r["flange"]), io.K_OFFSET: r["off"]},
                      color=io.section_color(lib, r["sec"]), name=nm)
    if plates:
        _solids(lib, st, None)
    elif profs:
        _solids(lib, st, [io.find(o.Id) for o in profs])
    _done()


# =========================================================================== check / colour / preview / list
def check():
    lib, st = _start()
    plates, beams = io.gather_for_check(lib, st)
    if not plates and not beams:
        ui.message("No FEA members in this model yet - use Plate / Profile / Srf -> Plate first.")
        return
    issues = C.check_model(plates, beams, lib, gap_tol=float(st.get("gap_tol", 5.0)))
    try:
        pre = io.export_preflight(lib, st)
    except Exception as ex:
        pre = [("INFO", "export pre-check skipped (%s)" % ex, [])]
    if pre:
        issues = [i for i in issues if i[0] != "OK"] + pre
        if not any(i[0] in ("ERROR", "WARNING") for i in issues):
            issues.insert(0, ("OK", "Model check passed - ready to export to ALIEF FEAPRO", []))
    n_err = sum(1 for i in issues if i[0] == "ERROR")
    n_w = sum(1 for i in issues if i[0] == "WARNING")
    head = "%d plate faces, %d profiles  |  %d error(s), %d warning(s)\n\n" % (len(plates), len(beams), n_err, n_w)
    text = head + "\n".join("%-8s %s" % (lv, m) for lv, m, k in issues)
    items = ["%s  %s" % (lv, m) for lv, m, k in issues]

    def sel(i):
        keys = issues[i][2]
        rs.UnselectAllObjects()
        if keys:
            rs.SelectObjects(keys)
            sc.doc.Views.Redraw()
    ui.report("AF_Check - model check", text, items, sel)


def color():
    lib, st = _start()
    r = ui.ask("AF_Color - colour the members", [
        dict(key="mode", label="Colour by", kind="choice", choices=["Property", "Material", "Thickness", "Layer"],
             value=st.get("color_by", "Property"))])
    if not r:
        return
    st["color_by"] = r["mode"]
    io.save_settings(st)
    n = io.recolor_all(lib, st)
    live.invalidate_all()
    _say("%d members coloured by %s - the property index shows the colours" % (n, r["mode"]))
    _done()


def _set_view(key, value):
    st = io.load_settings()
    st[key] = value
    io.save_settings(st)
    lv = live.refresh_now()
    lv.settings_changed()
    ui.refresh_panel()
    return st


def view3d():
    """3D View on / off: plate thickness and profile sections, kept up to date automatically."""
    _start()
    on = not io.load_settings().get("show_3d", True)
    _set_view("show_3d", on)
    _say("3D View %s%s" % ("ON - plates and profiles are shown with their real thickness / section and follow every change"
                           if on else "OFF", "" if on else " (members shown as surfaces / lines)"))


def legend():
    """Floating property index (colours, counts, weights) at the top left of the view - on / off."""
    _start()
    on = not io.load_settings().get("legend", True)
    _set_view("legend", on)
    _say("Property index %s" % ("ON (top left of the active view)" if on else "OFF"))


def preview():
    _start()
    _set_view("show_3d", True)
    _say("3D View ON (AF_3DView switches it off)")


def show3d():
    view3d()


def preview_off():
    _start()
    n = io.clear_preview()
    _set_view("show_3d", False)
    _say("3D View OFF%s" % ((" - %d old preview solids deleted" % n) if n else ""))


def update():
    """AF_Update: look for a newer version on the update server, install it and reload (or roll back)."""
    from . import updater
    updater.check_now()


def startup():
    """Run at Rhino start (Options > General > Run these commands): live display, index and team sync."""
    live.ensure()
    _say("ALIEF FEA MODELER %s ready - 3D View, property index and team sync are active" % C.VERSION)


def mto():
    lib, st = _start()
    rows_pl, rows_pr, tot = io.takeoff(lib)
    lines = ["PLATES", "%-24s %6s %-14s %5s %10s %10s" % ("Property", "t mm", "Material", "Qty", "Area m2", "Weight t")]
    lines += ["%-24s %6s %-14s %5s %10s %10s" % tuple(r) for r in rows_pl]
    lines += ["%-24s %50s" % ("Total plates", "%.3f t" % tot[0]), "", "PROFILES",
              "%-24s %-14s %5s %10s %8s %10s" % ("Section", "Material", "Qty", "Length m", "kg/m", "Weight t")]
    lines += ["%-24s %-14s %5s %10s %8s %10s" % tuple(r) for r in rows_pr]
    lines += ["%-24s %50s" % ("Total profiles", "%.3f t" % tot[1]), "", "TOTAL STEEL WEIGHT  %.3f t" % (tot[0] + tot[1])]

    def save():
        fn = rs.SaveFileName("Save material list", "CSV (*.csv)|*.csv||", None, "ALIEF_FEA_material_list.csv", "csv")
        if not fn:
            return
        with open(fn, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["PLATES"])
            w.writerow(["Property", "t [mm]", "Material", "Qty", "Area [m2]", "Weight [t]"])
            w.writerows(rows_pl)
            w.writerow([])
            w.writerow(["PROFILES"])
            w.writerow(["Section", "Material", "Qty", "Length [m]", "kg/m", "Weight [t]"])
            w.writerows(rows_pr)
            w.writerow([])
            w.writerow(["Total plates [t]", "%.3f" % tot[0]])
            w.writerow(["Total profiles [t]", "%.3f" % tot[1]])
        _say("material list saved: %s" % fn)
    ui.report("AF_MTO - material list", "\n".join(lines), on_save=save)


# =========================================================================== export / import
def _export_dir():
    p = sc.doc.Path
    if p and os.path.isdir(os.path.dirname(p)):
        return os.path.dirname(p)
    d = os.path.join(os.path.expanduser("~"), "Documents")
    return d if os.path.isdir(d) else os.path.expanduser("~")


def _default_export_path(st):
    nm = (st.get("project") or os.path.splitext(sc.doc.Name or "Rhino_model")[0] or "Rhino_model").replace(" ", "_")
    return os.path.join(_export_dir(), nm + ".alfea")


def _resolve_export_path(path):
    """A bare file name is saved next to the .3dm (or in Documents) - never in Rhino's program folder."""
    path = os.path.expandvars(os.path.expanduser((path or "").strip().strip('"')))
    if not path:
        return ""
    if not os.path.isabs(path):
        path = os.path.join(_export_dir(), path)
    if not path.lower().endswith(".alfea"):
        path += ".alfea"
    return path


def _ask_export_path(st, why=""):
    nm = os.path.basename(st.get("export_path") or _default_export_path(st))
    path = rs.SaveFileName("Export to ALIEF FEAPRO" + (" - " + why if why else ""), "ALIEF FEAPRO project (*.alfea)|*.alfea||",
                           _export_dir(), nm, "alfea")
    if not path:
        return ""
    if not path.lower().endswith(".alfea"):
        path += ".alfea"
    st["export_path"] = path
    io.save_settings(st)
    return path


def _export(lib, st):
    path = _resolve_export_path(st.get("export_path", ""))
    if path and not os.path.isdir(os.path.dirname(path)):
        path = ""
    if path and path != st.get("export_path"):
        st["export_path"] = path
        io.save_settings(st)
    if not path:
        nm = (st.get("project") or os.path.splitext(sc.doc.Name or "Rhino_model")[0] or "Rhino_model").replace(" ", "_")
        path = rs.SaveFileName("Export to ALIEF FEAPRO", "ALIEF FEAPRO project (*.alfea)|*.alfea||", None, nm + ".alfea", "alfea")
        if not path:
            return
        if not path.lower().endswith(".alfea"):
            path += ".alfea"
        st["export_path"] = path
        io.save_settings(st)
    job = io.Job(_say)

    def ask_facets(n, f_new):
        return ui.confirm(
            "The curved plating gives %d facets - every facet becomes a plate in ALIEF FEAPRO. Above about %d plates "
            "ALIEF FEAPRO opens and meshes the file very slowly or stops responding.\n\nBetter: tick 'Keep below "
            "automatically' in AF_Export, use a facet size of about %g mm (now %g mm), or export a part of the model "
            "(Limit X / Y / Z, Export: Selected members only).\n\nYes = export anyway    No = cancel"
            % (n, int(float(st.get("max_facets", 5000) or 5000)), f_new, float(st.get("facet_size", 300.0))),
            "AF_Export - too many facets")
    try:
        res = io.collect_model(lib, st, job=job, confirm=ask_facets)
    except io.Cancelled as ex:
        job.close()
        _say("export cancelled (%s) - nothing written" % ex)
        ui.message("Export cancelled - nothing was written.\n\n%s" % "\n".join(job.lines[-8:]))
        return
    except Exception:
        job.close()
        raise
    job.close()
    log = list(job.lines)
    if not res.plates and not res.beams:
        if res.scope != io.SCOPES[0]:
            ui.message("Nothing to export - no FEA members in the export scope '%s'.\n\nSelect the members first, "
                       "or set 'Export' to '%s' in AF_Export." % (res.scope, io.SCOPES[0]))
        else:
            ui.message("Nothing to export - no FEA members (AF plates / profiles) in this model.")
        return
    existing = None
    if st.get("keep_existing", True) and os.path.exists(path):
        try:
            existing = C.read_project(path)
        except Exception as ex:
            _say("existing file not readable (%s) - written as a new project" % ex)
    d = C.build_project(res.plates, res.beams, lib, st, res.layers, existing)
    while True:
        try:
            C.write_project(d, path)
            break
        except (OSError, IOError) as ex:
            ui.message("The file could not be written:\n%s\n\n%s\n\nChoose another folder (e.g. Documents or the folder of "
                       "the .3dm file)." % (path, ex))
            path = _ask_export_path(st, "choose a folder you can write to")
            if not path:
                _say("export cancelled")
                return
    io.save_library(lib)
    groups = {}
    for p in res.plates:
        groups.setdefault(p["group"], [0, 0])[0] += 1
    for b in res.beams:
        groups.setdefault(b["group"], [0, 0])[1] += 1
    lines = ["File: %s" % path,
             "Mode: %s" % ("UPDATED - supports, loads and load cases of the existing file kept" if existing else "new ALIEF FEAPRO project"),
             "Scope: %s%s   |   curved plating: %s, facet %g mm, shape tolerance %g mm   |   time %.1f s"
             % (res.scope, (" within " + io.limits_text(st)) if io.limits_text(st) else "", res.method,
                getattr(res, "facet_used", 0.0), getattr(res, "shape_used", 0.0), job.total()),
             "", "Plates: %d   (curved faces: %d -> %d planar facets)" % (len(res.plates), res.n_curved, res.n_facets),
             "Profiles (beam pieces): %d" % len(res.beams),
             "Materials %d | plate properties %d | sections %d" % (len(lib["materials"]), len(lib["plate_props"]), len(lib["sections"])),
             "", "Layers / groups:"]
    for g, (a, b) in sorted(groups.items()):
        lines.append("   %-40s plates %5d   profiles %5d" % (g, a, b))
    msgs = list(res.messages)
    if existing:
        msgs += C.dangling_references(d)
    if msgs:
        lines += ["", "Notes:"] + ["   - " + m for m in msgs]
    lines += ["", "Next: open the file in ALIEF FEAPRO (File > Open), then Mesh, Supports, Loads and Run."]
    ui.report("AF_Export - ALIEF FEAPRO", "\n".join(log + [""] + lines))
    _say("exported %d plates and %d profiles to %s" % (len(res.plates), len(res.beams), path))


def export(interactive=True):
    lib, st = _start()
    if interactive:
        r = ui.ask("AF_Export - export to ALIEF FEAPRO", [
            dict(key="project", label="Project name", kind="text", value=st.get("project", "")),
            dict(key="ship", label="Ship name", kind="text", value=st.get("ship", "")),
            dict(key="path", label="File (.alfea) - '...' = choose folder", kind="savefile",
                 value=st.get("export_path") or _default_export_path(st), filter=("ALIEF FEAPRO project", ".alfea")),
            dict(key="keep", label="Keep supports / loads of an existing file", kind="bool", value=st.get("keep_existing", True)),
            dict(key="scope", label="Export", kind="choice", choices=io.SCOPES, value=st.get("export_scope", io.SCOPES[0]),
                 tip="Part of the model only (e.g. one block): select it, or hide the rest, and choose it here"),
            dict(key="method", label="Curved plating", kind="choice", choices=io.CURVED_METHODS, labels=io.CURVED_LABELS,
                 value="Classic" if str(st.get("curved_method", "Fast")).startswith("Classic") else "Fast"),
            dict(key="facet", label="Facet size, curved plates [mm]", kind="float", value=st.get("facet_size", 300.0), min=10.0),
            dict(key="shell", label="Shape tolerance, curved plates [mm]", kind="float", value=st.get("shell_tol", 2.0), min=0.05,
                 tip="Largest distance between a facet and the real surface - bigger = fewer facets"),
            dict(key="merge", label="Flat / ruled parts", kind="bool", value=st.get("merge_flat", True),
                 text="merge into larger planar plates"),
            dict(key="chord", label="Chord tolerance, curves [mm]", kind="float", value=st.get("chord_tol", 1.0), min=0.05),
            dict(key="minarea", label="Skip plates smaller than [mm2]", kind="float", value=st.get("min_plate_area", 100.0), min=0.0,
                 tip="Hatch fills and slivers from a 2D drawing cannot be meshed - they are left out and listed"),
            dict(key="warn", label="Max. facets for ALIEF FEAPRO", kind="int", value=st.get("max_facets", 5000), min=0,
                 tip="Every facet is a plate in ALIEF FEAPRO; tens of thousands make it stop responding"),
            dict(key="auto", label="When more", kind="bool", value=st.get("auto_coarsen", True),
                 text="keep below automatically (larger facets)"),
            dict(key="limx", label="Limit X [mm] (from, to)", kind="text", value=st.get("limit_x", ""),
                 tip="Export only this part of the ship, e.g.  -7200, 8000  - plates and shell are cut at the limit. Empty = all"),
            dict(key="limy", label="Limit Y [mm] (from, to)", kind="text", value=st.get("limit_y", "")),
            dict(key="limz", label="Limit Z [mm] (from, to)", kind="text", value=st.get("limit_z", "")),
            dict(key="mesh", label="Global mesh size for a new file [mm]", kind="float", value=st.get("global_mesh", 100.0), min=1.0)],
            image="img_export",
            intro="Writes an ALIEF FEAPRO project with materials, plate properties, sections, plates, profiles and layers. "
                  "Open it in ALIEF FEAPRO and add the mesh, supports and loads. Big models: progress in the status bar, "
                  "Esc cancels.", ok_text="Export")
        if not r:
            return
        st.update(project=r["project"], ship=r["ship"], export_path=_resolve_export_path(r["path"]), keep_existing=r["keep"],
                  export_scope=r["scope"], curved_method=r["method"], facet_size=r["facet"], shell_tol=r["shell"],
                  merge_flat=r["merge"], chord_tol=r["chord"], min_plate_area=r["minarea"], max_facets=int(r["warn"]),
                  auto_coarsen=r["auto"], limit_x=r["limx"], limit_y=r["limy"], limit_z=r["limz"],
                  global_mesh=r["mesh"])
        io.save_settings(st)
    _export(lib, st)
    ui.refresh_panel()


def import_project():
    st = io.load_settings()
    fn = rs.OpenFileName("Open ALIEF FEAPRO project", "ALIEF FEAPRO project (*.alfea)|*.alfea||")
    if not fn:
        return
    try:
        n_pl, n_bm, n_cad, d = io.import_project(fn, st)
    except Exception as ex:
        ui.message("Import failed:\n%s" % ex)
        return
    msg = "%d plates, %d profiles imported" % (n_pl, n_bm)
    if n_cad:
        msg += ", %d CAD surfaces as reference meshes" % n_cad
    if d.get("constraints") or d.get("loads"):
        msg += ("\n\nThe file has %d support(s) and %d load(s). Export back to the SAME file with 'keep supports / loads' "
                "ticked to keep them." % (len(d.get("constraints", [])), len(d.get("loads", []))))
    st["export_path"] = fn
    if d.get("name"):
        st["project"] = d["name"]
    io.save_settings(st)
    live.invalidate_all()
    ui.message(msg)
    _done()


def panel():
    _start()
    ui.show_panel()


def library():
    _start()
    ui.show_panel(1)


def toolbar():
    _start()
    ui.show_toolbar()


def rhino_toolbar():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    path, msg, ok = ui.open_rhino_toolbar(root, show=True)
    _say(msg)
    if not ok:
        ui.show_toolbar()
    ui.message(msg)


# =========================================================================== team sync
def sync_setup():
    from . import sync as S
    _start()
    cfg = S.load_cfg()
    folder = cfg.get("folder") or ""
    if not folder or not os.path.isdir(folder):
        folder = rs.BrowseForFolder(message="Shared TEAM folder (Google Drive / OneDrive / Dropbox / network) - the same for everybody")
        if not folder:
            return
    zones = []
    try:
        zones = [m["zone"] + " (" + m.get("owner", "?") + ")" for m in S.manifests(dict(cfg, folder=folder))]
    except Exception:
        zones = []
    r = ui.ask("AF_SyncSetup - team sync (several people, one model)", [
        dict(key="folder", label="Shared team folder", kind="text", value=folder),
        dict(key="user", label="Your name", kind="text", value=cfg.get("user") or os.environ.get("USERNAME", "")),
        dict(key="zone", label="Your zone (the part you model, e.g. DECK, SHELL, BHD-FR40)", kind="text", value=cfg.get("zone", "")),
        dict(key="auto", label="Sync automatically (when saving + every interval)", kind="bool", value=bool(cfg.get("auto", True))),
        dict(key="interval", label="Check for team updates every [s]", kind="int", value=int(cfg.get("interval", 60) or 60), min=15)],
        image="img_sync",
        intro="Everybody uses the SAME shared folder and his OWN zone. Save (Ctrl+S) publishes your zone; the zones of the "
              "others appear locked on layer ALIEF_SYNC and are refreshed automatically. Zones in the folder: %s"
              % (", ".join(zones) if zones else "none yet"))
    if not r:
        return
    folder = r["folder"].strip()
    if not os.path.isdir(folder):
        try:
            os.makedirs(folder)
        except OSError:
            ui.message("Folder not found: %s" % folder)
            return
    zone = C.safe_zone(r["zone"])
    if not r["zone"].strip():
        ui.message("Enter your zone name (e.g. DECK).")
        return
    new = dict(cfg, folder=folder, user=r["user"].strip() or "user", zone=zone, auto=bool(r["auto"]), interval=int(r["interval"]))
    owner = S.zone_owner(new, zone)
    if owner is not None and not S.is_mine(new, zone):
        if rs.MessageBox("Zone %s belongs to %s (%s) since %s.\n\nTake it over? %s will then only see it as a "
                         "reference." % (zone, owner["user"], owner["computer"], owner["since"], owner["user"]), 4 | 48,
                         "AF_SyncSetup") != 6:
            return
    if zone in S.imported_zones():
        n = S.adopt_zone(zone)
        if n:
            _say("%d members of zone %s are yours now" % (n, zone))
    old_zone = C.safe_zone(cfg.get("zone", "")) if cfg.get("zone") else ""
    if old_zone and old_zone != zone and os.path.normcase(cfg.get("folder", "")) == os.path.normcase(folder):
        if S.retire_zone(dict(cfg, folder=folder), old_zone):
            _say("your previous zone %s was removed from the team folder - its members are published as %s now" % (old_zone, zone))
    S.save_cfg(new)
    S.ensure_project(new)
    S.claim_zone(new)
    msgs, n = _sync_run(S, new)
    _report_sync(new, msgs)
    _done()


def _sync_run(S, cfg):
    """Publish then refresh; file errors of the shared folder are reported, not raised."""
    msgs, n = [], 0
    try:
        msgs.append(S.push(cfg))
    except Exception as ex:
        msgs.append("Publishing failed: %s" % ex)
    try:
        n, m2 = S.pull(cfg)
        msgs += m2
    except Exception as ex:
        msgs.append("Loading the team zones failed: %s" % ex)
    return msgs, n


def _report_sync(cfg, msgs):
    from . import sync as S
    rows = S.status_rows(cfg)
    lines = ["Shared folder: %s" % cfg["folder"], "You: %s  |  zone %s  |  %s" % (cfg.get("user"), C.safe_zone(cfg["zone"]), S.computer()), ""]
    lines += ["%-14s %-26s %-20s rev %-4s %5s members   %s" % r for r in rows]
    lines += [""] + [m for m in msgs if m]
    for m in msgs:
        if m:
            _say(m.replace("\n", " | "))
    ui.report("AF_Sync - team", "\n".join(lines))


def sync_now():
    from . import sync as S
    _start()
    cfg = S.load_cfg()
    if not S.configured(cfg):
        sync_setup()
        return
    msgs, n = _sync_run(S, cfg)
    if not n:
        msgs.append("All other zones are up to date.")
    _report_sync(cfg, msgs)
    _done()
