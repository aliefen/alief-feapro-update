#! python3
# ALIEF FEA MODELER for Rhino 8 - installer
# Run ONCE in Rhino 8:  command  RunPythonScript  -> select this file.
# It remembers the plugin folder, creates the AF_ command aliases and opens the 'ALIEF FEA' toolbar.
# PT. Alief Energy Utama
import json
import os
import sys

import Rhino
import rhinoscriptsyntax as rs


def _here():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except NameError:
        return None


root = _here()
if not root or not os.path.exists(os.path.join(root, "alief_fea", "core.py")):
    root = rs.BrowseForFolder(message="Select the ALIEF_FEA_Rhino folder (the one that contains 'alief_fea' and 'commands')")
if not root or not os.path.exists(os.path.join(root, "alief_fea", "core.py")):
    Rhino.UI.Dialogs.ShowMessage("ALIEF_FEA_Rhino folder not found - installation cancelled.", "ALIEF FEA MODELER")
else:
    cfg = os.path.join(os.environ.get("APPDATA", root), "AliefEnergy", "ALIEF_FEA_Rhino")
    try:
        os.makedirs(cfg, exist_ok=True)
        with open(os.path.join(cfg, "install_path.txt"), "w") as f:
            f.write(root)
    except Exception as ex:
        Rhino.RhinoApp.WriteLine("Could not write the install path: %s" % ex)
    with open(os.path.join(root, "alief_fea", "commands.json")) as f:
        cmds = json.load(f)
    aliases = Rhino.ApplicationSettings.CommandAliasList
    made = []
    for name, desc in cmds:
        script = os.path.join(root, "commands", name + ".py")
        if not os.path.exists(script):
            continue
        macro = '! _-RunPythonScript "%s"' % script
        if aliases.IsAlias(name):
            aliases.SetMacro(name, macro)
        else:
            aliases.Add(name, macro)
        made.append("%-18s %s" % (name, desc))
    if root not in sys.path:
        sys.path.insert(0, root)
    for mod in [m for m in list(sys.modules) if m == "alief_fea" or m.startswith("alief_fea.")]:
        del sys.modules[mod]          # always load the files just installed
    from alief_fea import ui  # noqa: E402
    Rhino.RhinoApp.WriteLine("ALIEF FEA MODELER installed from %s" % root)
    for m in made:
        Rhino.RhinoApp.WriteLine("   " + m)
    from alief_fea import core as C  # noqa: E402
    rui_path, rui_msg, rui_ok = ui.open_rhino_toolbar(root)
    Rhino.RhinoApp.WriteLine(rui_msg)
    if rui_ok:
        tb_text = ("Toolbar 'ALIEF FEA' (tab + deretan ikon) sudah dibuka di bagian atas jendela Rhino, "
                   "seperti tab Standard / Drafting.\n"
                   "Bila Rhino menampilkannya mengambang, seret tab 'ALIEF FEA' ke samping tab 'Drafting' "
                   "satu kali saja - Rhino akan mengingat posisinya.")
    else:
        tb_text = ("Toolbar Rhino tidak bisa dibuka otomatis, jadi icon bar ALIEF FEA mengambang ditampilkan "
                   "(perintah AF_Toolbar).\n" + rui_msg)
    from alief_fea import live  # noqa: E402
    live.ensure()                     # 3D View, property index and team sync run from now on
    start_ok = ui.add_startup_command("AF_Startup")
    Rhino.RhinoApp.WriteLine("AF_Startup %s" % ("added to the commands run when Rhino starts" if start_ok else
                                                "not added automatically - see the guide (Options > General)"))
    Rhino.UI.Dialogs.ShowMessage(
        "ALIEF FEA MODELER %s sudah terpasang.\n\nFolder: %s\n%d perintah AF_... siap dipakai.\n\n%s\n\n"
        "Ikon pertama (logo) membuka Panel ALIEF FEA. 3D View, index properti dan sinkronisasi tim langsung aktif "
        "(setelah Rhino dibuka ulang: aktif begitu ikon ALIEF FEA pertama diklik%s). "
        "Setelah update file plugin cukup jalankan installer ini lagi."
        % (C.VERSION, root, len(made), tb_text,
           "" if start_ok else "; agar aktif sejak Rhino dibuka isi sekali Tools > Options > General > 'Run these "
                               "commands every time Rhino starts' dengan AF_Startup"), "ALIEF FEA MODELER")
    if not rui_ok:
        ui.show_toolbar()
