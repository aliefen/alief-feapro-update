#! python3
# ALIEF FEA MODELER for Rhino 8 - removes the AF_ command aliases (the files stay where they are).
import json
import os

import Rhino

try:
    root = os.path.dirname(os.path.abspath(__file__))
except NameError:
    root = r"C:\RHINO\ALIEF_FEA_Rhino"
names = []
try:
    with open(os.path.join(root, "alief_fea", "commands.json")) as f:
        names = [n for n, d in json.load(f)]
except Exception:
    pass
aliases = Rhino.ApplicationSettings.CommandAliasList
n = 0
for name in names:
    if aliases.IsAlias(name):
        aliases.Delete(name)
        n += 1
Rhino.UI.Dialogs.ShowMessage("%d ALIEF FEA aliases removed." % n, "ALIEF FEA MODELER")
