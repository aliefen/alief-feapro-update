# Verifikasi ALIEF FEA MODELER 1.4.0

Diuji dengan salinan loader proyek dan mesher (gmsh / OpenCASCADE) ALIEF FEAPRO:

| Uji | Hasil |
|---|---|
| Katalog & nama section (semua ukuran FB, L, T, H, C, HP, PIPE, RB) | nama = FEAPRO, properti positif, HP 200x10 A = 25.66 cm2 (tabel EN 10067) |
| Pengenalan lubang | lingkaran D400, slot 600x400, persegi 800x500 r75 diputar 30°, persegi tajam, poligon bebas — semua benar |
| Model pondasi winch (8 pelat, lubang, bracket, diafragma + manhole, balok deck) | lolos model check FEAPRO, 1 komponen mesh, 0 elemen balok lepas |
| Profil yang melewati lubang | otomatis diputus 1 mm dari tepi lubang |
| Mode update file .alfea | support, load dan load case tetap; load ke pelat yang dihapus dilaporkan |
| Kulit bilga lengkung + 2 web + 3 pembujur | 218 facet planar; web menempel kulit (1 komponen mesh); 50 potongan pembujur semua menempel kulit |
| Cek celah antar pelat | celah 2 mm terdeteksi |
| File toolbar ALIEF_FEA.rui | XML valid, 21 macro + 4 spacer (3D View, Index, Team sync baru), tombol ikon saja, grup ter-dock di atas, strip ikon 16/24/32 px (PNG) terbaca |
| Pemasangan toolbar (API Rhino tiruan) | instal pertama: buka + tampilkan; instal ulang tanpa perubahan: tidak dibuka/ditampilkan lagi (tidak ganda); file berubah: tutup + buka ulang; grup tidak terbaca: `-ShowToolbar "ALIEF FEA"` |
| Orientasi profil 3D | dihitung dengan rumus sumbu FEAPRO (ey = ez x ex x flange, offset auto = ez*t/2): L 150x90x9 di bawah deck t10 -> web 2995..2854, flange 2854..2845, flange ke -Y |
| Logika panel (pustaka material / plate property / section, sketsa, ekspor) | uji asap dengan Eto tiruan |
| Bracket dari dua member | profil+pelat (pembujur deck ke sekat): sudut (5000, 500, 3000), kaki -X dan -Z (sisi web); tanpa arah web memakai titik klik; profil+profil; pelat+pelat deck-kulit: sudut di garis potong, kaki +Y / -Z; pelat sejajar ditolak |
| Mesh tampilan 3D | L 150x90x9 (sumbu FEAPRO) z -105..-5 di bawah deck t10, flange ke -Y; PIPE berpusat di garis (centroid); pelat tebal ±t/2 dengan dinding tepi |
| Katalog sendiri | tambah / tolak ukuran standar / hapus / CSV bolak-balik identik / GEN bernama 'Rail 30 kg' / tersimpan di AppData dan di file |
| Penggabungan pustaka tim (3-way) | item baru dua arah, perubahan satu pihak menang, perubahan dua pihak -> versi bersama + laporan |
| Index properti | baris per properti dengan jumlah, luas / panjang, berat (density material), properti aktif ditandai, mode Material / Thickness |
| Sinkronisasi tim (simulasi 2 orang, file .3dm asli via rhino3dm) | publikasi zona, impor terkunci di layer ALIEF_SYNC::zona, ID member tetap antar revisi, simpan tanpa perubahan tidak membuat revisi baru, file setengah tersalin ditunda, edit pustaka lokal tidak tertimpa saat pull lalu sampai ke anggota lain, library.json rusak tidak ditimpa, take-over menolak publikasi pemilik lama, zona yang dipensiunkan hilang dari file anggota lain |
| Kelas tampilan (DisplayConduit) | dicocokkan dengan kode sumber pythonnet Rhino 8 (cabang master-rhino-8.x): kelas turunan .NET wajib punya `__module__` - dipakai pernyataan `class` biasa, tipe .NET dibuat sekali dan dipakai ulang |
| Dialog Select / Assign | alur Select -> pilih di Rhino -> dialog kembali (isian tetap) -> Assign diuji dengan Eto tiruan; path ekspor relatif diarahkan ke folder .3dm / Documents |
| Layanan live, jendela Assign, tab Team | uji asap dengan Rhino / Eto tiruan; review terpisah pemakaian RhinoCommon 8 (perbaikan: hapus objek di layer terkunci/tersembunyi, sorotan seleksi saat 3D View, cache folder bersama) |
| **1.2 ekspor cepat - pemotongan lokal kulit** | bilga tanpa garis grid di web (mesh seperti mesher ringan), 2 web + stringer z=700 dipotong lokal: 543 facet, konform (tiap tepi dipakai 1/2 segitiga), sudut minimum 4.5°, lolos model check FEAPRO, 1 komponen mesh, 0 balok lepas |
| 1.2 penggabungan facet datar / lurus | lambung silinder (sisi datar + bilga + alas): 888 segitiga -> 78 pelat planar, luas sama, tidak melewati garis web; FEAPRO 1 komponen, 0 balok lepas; pelat > 1e-6 mm di luar bidang ditolak OpenCASCADE -> toleransi gabung 2e-7 mm |
| 1.2 salinan ringan bicubic | interpolasi B-spline di ruang parameter face (parameterisasi tidak seragam u², v^1.5): selisih 0.26 mm dari surface asli pada 2000 titik acak; 6 face rapat FORE_PEAK_R0.3dm (rhino3dm): dibuat dalam < 3 s per face |
| 1.2 penyederhanaan kulit | grid meruncing (radius 2000 -> 120 mm): semua titik asli tetap <= 2 mm dari facet, tidak ada facet terbalik; strip datar meruncing 960 -> 345 segitiga, luas sama; 100 000 segitiga dalam 7 s |
| 1.2 skala | 100 000 segitiga dipotong 150 bidang: 4 s; AF_Check 20 000 pelat: 0.8 s (dulu kuadratik) |
| 1.2 collect_model end-to-end (RhinoCommon tiruan) | bilga dengan domain tak ter-trim besar + 2 web + stringer + 3 pembujur + stiffener stringer + hatch 50 mm2: hatch dilewati dan dilaporkan, 217 pelat / 32 balok, lolos FEAPRO, 1 komponen, 0 balok lepas; mesher tiruan sengaja kasar (tanpa toleransi) -> facet tetap dikoreksi ke surface asli |
| 1.2 skala end-to-end (tiruan) | bilga 30 m + 50 web + 20 pembujur + 3000 pelat deck + 3000 stiffener: 11 700 pelat / 7 850 balok dalam 18 s (facet 100 mm) |
| 1.2 perintah AF_Export | isian dialog baru, peringatan jumlah facet (No = batal, tidak ada file), Esc di tengah ekspor (batal, tidak ada file), laporan berisi scope / metode / waktu; AF_Check menampilkan pelat mikro, surface rapat, perkiraan facet |
| **1.3 batas facet otomatis** | bilga + web + stringer, batas 150 facet: facet 150 -> 1600 mm otomatis, 880 -> 197 facet, lolos FEAPRO, 1 komponen, 0 balok lepas |
| 1.3 Limit X / Z | ekspor X 500..2500, Z <= 1400: semua titik pelat / balok di dalam batas, tepi tepat di X = 500 dan 2500, stiffener yang terpotong mendapat node di tepi pelat; FEAPRO 1 komponen, 0 balok lepas |
| 1.3 waktu mesher FEAPRO (salinan) vs jumlah pelat facet | 968 pelat 3 s, 3 872 pelat 26 s (naik lebih cepat dari linear) -> batas standar 5000 |
| **1.4 update otomatis** | salinan terpasang 1.4.0 + rilis tiruan 9.9.9: cek versi, unduh, SHA-256, cadangan, salin (file pengguna di folder tetap ada), alias perintah baru terdaftar, modul dimuat ulang, roll back; ditolak: SHA-256 salah, latest.json produk lain, zip dengan path keluar folder, alamat non-https; cek otomatis: tanya sekali per sesi, Yes memasang, versi yang dilewati tidak ditanya lagi; alamat GitHub asli terbaca dari sini (latest.json FEAPRO 0.5.5) |

Antarmuka Rhino (RhinoCommon / Eto) belum dijalankan di Rhino 8 — laporkan pesan error dari command line jika ada.
