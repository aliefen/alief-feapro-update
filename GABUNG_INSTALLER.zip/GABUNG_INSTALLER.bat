@echo off
title ALIEF FEA PRO 0.5.17 - Gabung installer
color 0A
cd /d "%~dp0"
echo.
echo  ================================================================
echo    ALIEF FEA PRO 0.5.17  -  menggabungkan file installer
echo  ================================================================
echo.
echo  Letakkan file .001 sampai .011 dan file ini di folder yang sama.
echo.
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.001" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.002" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.003" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.004" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.005" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.006" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.007" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.008" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.009" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.010" goto missing
if not exist "ALIEF_FEAPRO_Setup_0.5.17.exe.011" goto missing
echo  [1/3] Menggabungkan 11 bagian ...
copy /b /y "ALIEF_FEAPRO_Setup_0.5.17.exe.001"+"ALIEF_FEAPRO_Setup_0.5.17.exe.002"+"ALIEF_FEAPRO_Setup_0.5.17.exe.003"+"ALIEF_FEAPRO_Setup_0.5.17.exe.004"+"ALIEF_FEAPRO_Setup_0.5.17.exe.005"+"ALIEF_FEAPRO_Setup_0.5.17.exe.006"+"ALIEF_FEAPRO_Setup_0.5.17.exe.007"+"ALIEF_FEAPRO_Setup_0.5.17.exe.008"+"ALIEF_FEAPRO_Setup_0.5.17.exe.009"+"ALIEF_FEAPRO_Setup_0.5.17.exe.010"+"ALIEF_FEAPRO_Setup_0.5.17.exe.011" "ALIEF_FEAPRO_Setup_0.5.17.exe" >nul
if errorlevel 1 goto fail
echo  [2/3] Memeriksa keutuhan file (SHA-256) ...
certutil -hashfile "ALIEF_FEAPRO_Setup_0.5.17.exe" SHA256 | findstr /i /c:"803b735d1c51b41207053cabe82ba9bee0cf83f90cff0bc93e1ae12eafb70073" >nul
if errorlevel 1 goto fail
echo  [3/3] File installer utuh. Menghapus bagian-bagian (.001 ...) ...
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.001"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.002"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.003"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.004"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.005"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.006"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.007"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.008"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.009"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.010"
del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe.011"
if exist latest.json del /f /q latest.json
echo.
echo  Selesai:  ALIEF_FEAPRO_Setup_0.5.17.exe
echo  Installer dibuka sekarang; file gabung ini menghapus dirinya sendiri.
echo.
start "" "ALIEF_FEAPRO_Setup_0.5.17.exe"
timeout /t 2 >nul
(goto) 2>nul & del /f /q "%~f0"
:missing
echo.
echo  Ada bagian yang belum ada di folder ini. Pastikan semua bagian
echo  sudah selesai diunduh ke folder yang sama dengan file ini.
pause
exit /b 1
:fail
echo.
echo  GAGAL: file hasil gabungan rusak atau tidak lengkap (SHA-256 tidak cocok).
echo  Bagian-bagian TIDAK dihapus - unduh ulang bagian yang rusak lalu jalankan lagi.
if exist "ALIEF_FEAPRO_Setup_0.5.17.exe" del /f /q "ALIEF_FEAPRO_Setup_0.5.17.exe"
pause
exit /b 1
